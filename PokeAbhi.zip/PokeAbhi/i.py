import requests
import json

def get_pokemon_evolution_data(pokemon_id):
    url = 'https://graphql-pokeapi.vercel.app/api/graphql'
    query = '''
        query {
            pokemon(number: %d) {
                name
                evolutions {
                    evolved_species {
                        name
                    }
                    evolution_details {
                        trigger {
                            name
                        }
                        min_level
                    }
                }
            }
        }
    ''' % pokemon_id

    response = requests.post(url, json={'query': query})

    if response.status_code == 200:
        pokemon_data = response.json()['data']['pokemon']
        return pokemon_data
    else:
        return None

def extract_evolution_info(pokemon_data):
    evolves_to_name = None
    evolve_method = None
    evolve_at_level = None

    if pokemon_data['evolutions']:
        evolves_to_name = pokemon_data['evolutions'][0]['evolved_species']['name']
        evolve_method = pokemon_data['evolutions'][0]['evolution_details'][0]['trigger']['name']
        evolve_at_level = pokemon_data['evolutions'][0]['evolution_details'][0]['min_level']

    evolution_info = {
        'name': pokemon_data['name'],
        'evolves_to_name': evolves_to_name,
        'evolve_method': evolve_method,
        'evolve_at_level': evolve_at_level
    }
    return evolution_info

def save_evolution_data_to_json(evolution_data):
    with open('pokemon_evolution_data.json', 'a') as json_file:
        json.dump(evolution_data, json_file, indent=2)
        json_file.write('\n')  # Add a newline for better readability

def download_evolution_data_for_all_pokemon():
    total_pokemon = 898  # Adjust this number based on the total number of Pokémon in your dataset

    for pokemon_id in range(1, total_pokemon + 1):
        pokemon_data = get_pokemon_evolution_data(pokemon_id)

        if pokemon_data is not None:
            evolution_info = extract_evolution_info(pokemon_data)
            save_evolution_data_to_json(evolution_info)
        else:
            print(f"Failed to retrieve data for Pokemon {pokemon_id}")

if __name__ == "__main__":
    download_evolution_data_for_all_pokemon()
