import json

# Read the JSON data from the file
with open('pokemon_info55.json', 'r') as file:
    pokemon_data = json.load(file)

# Iterate through each Pokemon entry
for pokemon_name, pokemon_info in pokemon_data.items():
    # Check if front_default_image exists and includes "official-artwork"
    if pokemon_info.get("front_default_image") and "official-artwork" in pokemon_info["front_default_image"]:
        # Append "?v=1" to the end of the URL
        pokemon_info["front_default_image"] += "?v=1"

# Save the modified data back to the file
with open('pokemon_info55_modified.json', 'w') as file:
    json.dump(pokemon_data, file, indent=2)

print("Modification complete. Check 'pokemon_info55_modified.json'.")
