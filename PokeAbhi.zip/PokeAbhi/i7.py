import requests
import json

def get_all_pokemon_data():
    base_url = 'https://pokeapi.co/api/v2/pokemon?limit=1500'
    response = requests.get(base_url)

    pokemon_data_list = []

    if response.status_code == 200:
        data = response.json()
        pokemon_list = data['results']

        for pokemon in pokemon_list:
            pokemon_name = pokemon['name']
            url = pokemon['url']

            # Get Pokemon data by URL
            pokemon_data = requests.get(url).json()

            # Adjust the 'front_shiny' attribute based on the PokeAPI response structure
            shiny_sprite_url = pokemon_data['sprites']['other']['official-artwork']['front_shiny']

            # Add name and shiny image link to the list
            pokemon_data_list.append({'name': pokemon_name, 'shiny_url': shiny_sprite_url})

    return pokemon_data_list

pokemon_data_list = get_all_pokemon_data()

# Save the data to a JSON file
with open('shiny.json', 'w') as json_file:
    json.dump(pokemon_data_list, json_file, indent=2)
