const pokemonData = require('./pokemon_data.json');

const uniqueGrowthRates = [...new Set(Object.values(pokemonData).map(pokemon => pokemon.growth_rate))];

console.log(uniqueGrowthRates);
