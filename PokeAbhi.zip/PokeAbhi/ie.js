const WebSocket = require('websocket').w3cwebsocket;

const showdownURL = 'ws://sim.smogon.com:8000/showdown/websocket';
const ws = new WebSocket(showdownURL);

let battleRoom = ''; // Store battle room name
let myPokemon = ''; // Store user's active Pokémon
let opponentPokemon = ''; // Store opponent's active Pokémon
let telegramChatId = ''; // Store Telegram chat ID

// Helper function to send messages to Telegram
function sendToTelegram(message) {
    // You need to implement your Telegram bot's send message logic here
    console.log(message);
}

// Helper function to send commands to Showdown server
function sendCommand(command) {
    if (battleRoom) {
        ws.send(`${battleRoom}|${command}`);
    }
}

ws.onmessage = (message) => {
    const data = message.data.toString();
    console.log(data);

    // Parse battle updates
    if (data.startsWith('|')) {
        // Extract battle room name
        const roomData = data.split('|')[0];
        if (roomData.startsWith('>')) {
            battleRoom = roomData.slice(1);
        } else if (roomData.startsWith('|player|')) {
            // Extract opponent's username
            const opponentUsername = roomData.split('|')[2];
            sendToTelegram(`Your opponent: ${opponentUsername}`);
        } else if (roomData.startsWith('|poke|')) {
            // Extract Pokémon details
            const [, side, details] = roomData.split('|');
            const [species, level, hp, maxHP] = details.split(',').map(item => item.trim());
            const pokemon = { species, level, hp, maxHP };

            if (side === 'p1') {
                myPokemon = pokemon;
            } else {
                opponentPokemon = pokemon;
            }
        } else if (roomData.startsWith('|move|')) {
            // Extract available moves for user's Pokémon
            const [, side, moves] = roomData.split('|');
            if (side === 'p1') {
                const availableMoves = moves.split(',').map(item => item.trim());
                const movesList = availableMoves.map((move, index) => `${index + 1}. ${move}`).join('\n');
                sendToTelegram(`<b>Your Moves:</b>\n${movesList}`);
            }
        }
    }

    // Send battle information to Telegram
    if (myPokemon && opponentPokemon) {
        sendToTelegram(`<b>Your Pokémon:</b> ${myPokemon.species} (${myPokemon.hp}/${myPokemon.maxHP})\n\n` +
                      `<b>Opponent's Pokémon:</b> ${opponentPokemon.species} (${opponentPokemon.hp}/${opponentPokemon.maxHP})`);
    }
};

// Start a battle
function startBattle(chatId) {
    telegramChatId = chatId;
    ws.send('|/join');
}

// Example usage
startBattle('YOUR_TELEGRAM_CHAT_ID');
