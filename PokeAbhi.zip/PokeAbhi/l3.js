const fs = require('fs')
const c = {}
const pokes = JSON.parse(fs.readFileSync('pokemon_info55_modified2.json', 'utf8'));
const tms = JSON.parse(fs.readFileSync('pokemon_base_exp2.json', 'utf8'));
const tms2 = JSON.parse(fs.readFileSync('moveset_data_updated.json', 'utf8'));
const pokemonData = JSON.parse(fs.readFileSync('pokemon_data_updated.json', 'utf8'));

for(const a in pokemonData){
for(const b of pokemonData[a]){
if(!pokes[b.identifier]){
if(!c[a]){
c[a] = []
}
c[a].push(b.identifier)
}
}
}
console.log(c)
