import requests
import json

def fetch_effects():
    url = "https://pokeapi.co/api/v2/move-learn-method/"
    response = requests.get(url)
    if response.status_code == 200:
        data = response.json()
        effects = {}
        for method in data["results"]:
            method_id = method["name"]
            method_name = method["name"].replace("-", " ").title()
            effects[method_id] = method_name
        return effects
    return None

def main():
    effects = fetch_effects()
    if effects:
        with open("effects.json", "w") as file:
            json.dump(effects, file, indent=2)
        print("Effects saved to effects.json")
    else:
        print("Failed to fetch effects.")

if __name__ == "__main__":
    main()
