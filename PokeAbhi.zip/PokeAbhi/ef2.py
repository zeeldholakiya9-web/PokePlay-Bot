import requests
import json

def fetch_move_effect(move_name):
    url = f"https://pokeapi.co/api/v2/move/{move_name}/"
    response = requests.get(url)
    if response.status_code == 200:
        data = response.json()
        if data.get("effect_entries"):
            effect = data["effect_entries"][0]["effect"]
            effect_chance = data["effect_chance"]
            return effect, effect_chance
    return None, None

def update_moves_info(moves_info):
    updated_moves_info = {}
    for move_id, move_data in moves_info.items():
        move_name = move_data["name"]
        effect, effect_chance = fetch_move_effect(move_name)
        if effect:
            move_data["effect"] = effect
            move_data["effect_chance"] = effect_chance
            updated_moves_info[move_id] = move_data
            print(f"found effect for: ${move_name}")
        else:
            print(f"Effect not found for move: {move_name}")
    return updated_moves_info

def main():
    with open("moves_info.json", "r") as file:
        moves_info = json.load(file)
    
    updated_moves_info = update_moves_info(moves_info)
    
    with open("moves_info_updated.json", "w") as file:
        json.dump(updated_moves_info, file, indent=2)

if __name__ == "__main__":
    main()
