const fs = require('fs');
const lvl = JSON.parse(fs.readFileSync('evolution_chains2.json', 'utf8'));
let y = []
for(const a of lvl.evolution_chains){
if(a.evolution_method!='level-up'){
y.push(a.current_pokemon+' _'+a.evolution_method)
}
}
console.log(y)
