import json

import requests

def download_pokemon_data(start_id, end_id):
    pokemon_data = {}

    for pokemon_id in range(start_id, end_id + 1):
        url = f"https://pokeapi.co/api/v2/pokemon/{pokemon_id}/"
        response = requests.get(url)

        if response.status_code == 200:
            data = response.json()

            name = data['name']
            types = [t['type']['name'] for t in data['types']]
            stats = data['stats']
            base_stats = {stat['stat']['name']: stat['base_stat'] for stat in stats}
            effort_values = {stat['stat']['name']: stat['effort'] for stat in stats if stat['effort'] > 0}
# Calculate min and max stats based on level 10
            level_100_stats = {key: base_stats[key] + 31 * (252 if key in effort_values else 0) for key in base_stats}
            min_stats = {key: str(0) for key in base_stats}
            max_stats = {key: str(0) for key in base_stats}

            species_url = data['species']['url']
            species_response = requests.get(species_url)
            species_data = species_response.json()
            growth_rate = species_data['growth_rate']['name'].replace('-', ' ').title()

            image_url = data['sprites']['other']['official-artwork']['front_default']

            pokemon_data[name] = {
                name: {
                    "name": name.capitalize(),
                    "artwork": image_url,
                    "national": str(data['id']).zfill(3),
                    "type": {"type1": types[0], "type2": types[1] if len(types) > 1 else None},
                    "species": data['species']['name'],
                    "height": {"si": f"{data['height'] / 10} m", "usc": f"{data['height'] * 3.281} ft"},
                    "weight": {"si": f"{data['weight'] / 10} kg", "usc": f"{data['weight'] * 0.2205} lbs"},
                    "abilities": {"ability1": data['abilities'][0]['ability']['name'],
                                  "hidden_ability": data['abilities'][1]['ability']['name'] if len(data['abilities']) > 1 else None},
                    "ev_yield": {stat['stat']['name']: stat['effort'] for stat in stats if stat['effort'] > 0},
                    "growth_rate": growth_rate,
		    "min_stats": min_stats,
                    "max_stats": max_stats,
                    "catch_rate": {"value": str(data['base_experience'] or 0), "percent": f"{(float(data['base_experience'] or 0) / 255) * 100}%"},
                    "base_friendship": {"value": str(data['base_experience']), "rating": "normal"},
                    "base_exp": str(data['base_experience']),
                    "min_stats": {
                        "hp": "0",
                        "atk": "0",
                        "def": "0",
                        "spa": "0",
                        "spd": "0",
                        "spe": "0",
                    },
                    "max_stats": {
                        "hp": "0",
                        "atk": "0",
                        "def": "0",
                        "spa": "0",
                        "spd": "0",
                        "spe": "0",
                    },
                    "base_stats": {
                        "hp": str(next((stat['base_stat'] for stat in stats if stat['stat']['name'] == 'hp'), '0')),
                        "atk": str(next((stat['base_stat'] for stat in stats if stat['stat']['name'] == 'attack'), '0')),
                        "def": str(next((stat['base_stat'] for stat in stats if stat['stat']['name'] == 'defense'), '0')),
                        "spa": str(next((stat['base_stat'] for stat in stats if stat['stat']['name'] == 'special-attack'), '0')),
                        "spd": str(next((stat['base_stat'] for stat in stats if stat['stat']['name'] == 'special-defense'), '0')),
                        "spe": str(next((stat['base_stat'] for stat in stats if stat['stat']['name'] == 'speed'), '0')),
                        "total": str(sum(int(stat['base_stat']) for stat in stats)),
                    },

                    "evolutions": {"from": {"name": None, "method": None},
                                   "into": {"name": None, "method": None}},  # Add evolution details based on the example
                }
            }

    with open("pokemon_data.json", "w") as json_file:
        json.dump(pokemon_data, json_file, indent=4)

# Example usage:
download_pokemon_data(891, 950)
