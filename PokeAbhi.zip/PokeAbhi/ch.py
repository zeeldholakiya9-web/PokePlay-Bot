import json

# Read the original JSON file
with open('data.json') as f:
    original_data = json.load(f)

# Restructure the data
restructured_data = []

for key, value in original_data.items():
    flattened_data = {"name": value.get(key, {}).get("name")}
    flattened_data.update(value.get(key, {}))  # Add other data from the inner dictionary
    restructured_data.append(flattened_data)
# Write the restructured data to a new JSON file
with open('data2.json', 'w') as f:
    json.dump(restructured_data, f, indent=2)

print("Data successfully restructured and saved to restructured_data.json.")
