const pokeballMultipliers = {
  "Poke": 1,
  "Great": 1.5,
  "Ultra": 2,
  "Master": 255,
};

function capturePokemon(maxHP, catchRate, pokeball) {
  const bonusBall = pokeballMultipliers[pokeball];
  const bonusStatus = 2.5;

  const currHP = 10; // Assuming the target is at 1 HP
  const a = Math.floor(((3 * maxHP - 2 * currHP) * catchRate * bonusBall) / (3 * maxHP))

  for (let i = 0; i < 3; i++) {
    const shakeProbability = Math.floor((65536 / Math.pow((255 / a), 0.25)));
    if (Math.random() * 65536 > shakeProbability) {
      if (i === 0) console.log("(First check failed)");
      else if (i === 1) console.log("(Second check failed)\n*shake*");
      else console.log("(Third check failed)\n*shake*\n*shake*\n*shake*");
      return;
    }
    console.log("*shake*");
  }

  console.log("Click!");
}

// Example usage:
capturePokemon(400, 3, "Master");
