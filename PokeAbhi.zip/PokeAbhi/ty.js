const fs = require('fs')
const pokesData = JSON.parse(fs.readFileSync('data.json', 'utf8'))
console.log(pokesData[Object.keys(pokesData)[2]])
