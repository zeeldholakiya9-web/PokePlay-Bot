const fetch = require('fetch')
const fs = require('fs');

const pokeData = [];

const fetchPokemons = async () => {
    for (let i = 906; i <= 1010; i++) {
        const pokemon = await getPokemon(i);
        pokeData.push(pokemon);
    }
    
    // Save data to a file
    fs.writeFileSync('pokemon_data.json', JSON.stringify(pokeData, null, 2));
};

const getPokemon = async id => {
    const url = `https://pokeapi.co/api/v2/pokemon/${id}`;
    const res = await fetch(url);
    const pokemon = await res.json();
    return formatPokemonData(pokemon);
};

function formatPokemonData(pokemon) {
    const name = pokemon.species.name[0].toUpperCase() + pokemon.species.name.slice(1);
    const id = pokemon.id.toString().padStart(3, '0');
    const poke_types = pokemon.types.map(type => type.type.name[0].toUpperCase()+type.type.name.slice(1));
    const ptype = poke_types[0];
    const stype = poke_types[1] ? poke_types[1] : null;
    const height = pokemon.height/10;
    const weight = pokemon.weight/10;
    const moves = pokemon.moves.map(move=> move.move.name[0].toUpperCase()+move.move.name.slice(1)).join(", ");
    const ability = pokemon.abilities.map(ability=> ability.ability.name[0].toUpperCase()+ability.ability.name.slice(1)).join(", ");
    
    return {
        id,
        name,
        ptype,
        stype,
        height,
        weight,
        moves,
        ability
    };
}

fetchPokemons();
