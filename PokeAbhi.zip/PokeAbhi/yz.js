const fs = require('fs');

// Read the content of y.json file
const jsonData = fs.readFileSync('y.json', 'utf8');
const data = JSON.parse(jsonData);

// Iterate through each entry and update Min and Max names
data.forEach(entry => {
    entry['Min HP'] = entry['Min'];
    entry['Max HP'] = entry['Max'];
    delete entry['Min'];
    delete entry['Max'];

    entry['Min Atk'] = entry['Min'];
    entry['Max Atk'] = entry['Max'];
    delete entry['Min'];
    delete entry['Max'];

    entry['Min Def'] = entry['Min'];
    entry['Max Def'] = entry['Max'];
    delete entry['Min'];
    delete entry['Max'];

    entry['Min Sp. Atk'] = entry['Min'];
    entry['Max Sp. Atk'] = entry['Max'];
    delete entry['Min'];
    delete entry['Max'];

    entry['Min Sp. Def'] = entry['Min'];
    entry['Max Sp. Def'] = entry['Max'];
    delete entry['Min'];
    delete entry['Max'];

    entry['Min Speed'] = entry['Min'];
    entry['Max Speed'] = entry['Max'];
    delete entry['Min'];
    delete entry['Max'];
});

// Write the updated data back to y.json file
console.log(data)
