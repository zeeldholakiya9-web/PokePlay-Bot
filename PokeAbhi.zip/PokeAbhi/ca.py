import requests
import json

def fetch_exp_chart():
    url = "https://pokeapi.co/api/v2/growth-rate"
    response = requests.get(url)

    if response.status_code == 200:
        growth_rates = response.json()["results"]

        exp_chart = {}

        for growth_rate in growth_rates:
            rate_name = growth_rate["name"]
            rate_url = growth_rate["url"]

            rate_data = requests.get(rate_url).json()
            levels = rate_data["levels"]

            exp_chart[rate_name] = {str(level["level"]): level["experience"] for level in levels}

        return exp_chart
    else:
        print(f"Failed to fetch data. Status code: {response.status_code}")
        return None

# Example usage:
exp_chart_data = fetch_exp_chart()

if exp_chart_data:
    with open("exp_chart.json", "w") as json_file:
        json.dump(exp_chart_data, json_file, indent=2)
    print("Data saved successfully.")
