const { chooseRandomNumbers, getLevel, stat, calculateTotalEV, calculateTotal,getRandomNature} = require('./func.js')
const fs = require('fs');
const path = require('path');

const dataFolder = './db/'; // Replace with the actual path to your data folder

// Read all files in the data folder
const userFiles = fs.readdirSync(dataFolder);
const us = []
function findNameInSlugs(name) {
  const filesWithMatch = [];

  for (const file of userFiles) {
    const filePath = path.join(dataFolder, file);

    // Check if it's a JSON file
    if (file.endsWith('.json')) {
      try {
        const userData = JSON.parse(fs.readFileSync(filePath, 'utf8'));

        if (userData && userData[0].data && userData[0].data.pokes) {
          for (const slug of userData[0].data.pokes) {
            if (calculateTotal(slug.ivs) > 154) {
              if(!us.includes(userData[0].data.inv.name)){
                  us.push(userData[0].data.inv.name);
              }
               filesWithMatch.push(userData[0].data.inv.name +' '+slug.name);
           }
          }
        }
      } catch (error) {
        console.error(`Error reading or parsing ${file}: ${error}`);
      }
    }
  }

  return filesWithMatch;
}


// Use the 'readline' module to get user input
const readline = require('readline').createInterface({
  input: process.stdin,
  output: process.stdout,
});

// Prompt the user for a name value
readline.question('Enter a name to search: ', (name) => {
  const matchingFiles = findNameInSlugs(name);

  if (matchingFiles.length > 0) {
    console.log(`The name "${name}" was found in the following files:`);
console.log('Total: '+matchingFiles.length+' slugs on '+us.length+' users')
    matchingFiles.forEach((file) => {
      console.log(file);
    });
  } else {
    console.log(`The name "${name}" was not found in any files.`);
  }

  readline.close();
});
