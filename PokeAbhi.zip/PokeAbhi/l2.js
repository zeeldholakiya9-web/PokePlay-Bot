const fs = require('fs');
const lvl = JSON.parse(fs.readFileSync('pokemon_info55_modified2.json', 'utf8'));
const dmoves = JSON.parse(fs.readFileSync('shiny.json', 'utf8'));
for(const a in lvl){
const b = dmoves.filter((o)=>o.name==a)[0]
if(!b){
const y = {
"name":a,
"shiny_url":null
}
console.log(y)
dmoves.push(y)
}
}
fs.writeFileSync('./shiny2.json', JSON.stringify(dmoves,null,2), 'utf8');
