import requests

def get_all_pokemon_data():
    api_url = "https://pokeapi.co/api/v2/pokemon-species/"
    response = requests.get(api_url)

    if response.status_code == 200:
        data = response.json()
        results = data.get('results', [])

        pokemon_data = {}
        for result in results:
            pokemon_name = result['name']
            pokemon_info = get_pokemon_info(pokemon_name)
            pokemon_data[pokemon_name] = pokemon_info

        return pokemon_data
    else:
        print("Failed to retrieve Pokémon data")

def get_pokemon_info(pokemon_name):
    api_url = f"https://pokeapi.co/api/v2/pokemon-species/{pokemon_name.lower()}/"
    response = requests.get(api_url)

    if response.status_code == 200:
        data = response.json()
        base_experience = data.get('base_experience', None)
        growth_rate = data.get('growth_rate', {}).get('name', None)

        return {
            "base_experience": base_experience,
            "growth_rate": growth_rate
        }
    else:
        print(f"Failed to retrieve data for {pokemon_name}")

# Example: Get base experience and growth rate for all Pokémon
all_pokemon_data = get_all_pokemon_data()
for pokemon_name, pokemon_info in all_pokemon_data.items():
    print(f"{pokemon_name}: Base Experience - {pokemon_info['base_experience']}, Growth Rate - {pokemon_info['growth_rate']}")
