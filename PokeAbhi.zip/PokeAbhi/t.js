const pokesData = {
    "Mudsdale": {
        "mudsdale": {
            name: 'Mudsdale',
            gen: '7',
            artwork: 'https://img.pokemondb.net/artwork/large/mudsdale.jpg',
            national: '750',
            type: { type1: 'Ground' },
            species: 'Draft Horse Pokémon',
            height: { si: '2.5 m', usc: '8′02″' },
            weight: { si: '920.0 kg', usc: '2028.3 lbs' },
            abilities: {
                ability1: 'Own Tempo',
                ability2: 'Stamina',
                hidden_ability: 'Inner Focus'
            }
        },
        // Add more Pokémon data as needed
    },
    "Mudsdale2": {
        // Data for Mudsdale2
    }
};

const pokes = Object.keys(pokesData)[0];
const firstPokemonData = pokesData[pokes][Object.keys(pokesData[pokes])[0]];

console.log("First Pokémon Name:", firstPokemonData.name);
console.log("First Pokémon Artwork:", firstPokemonData.artwork);
