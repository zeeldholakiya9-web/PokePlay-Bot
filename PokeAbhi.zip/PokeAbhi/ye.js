function calculateCaptureOutcome(baseCaptureRate, hpModifier, statusModifier, levelModifier, ballModifier) {
  // Calculate capture probability
  const captureProbability = (baseCaptureRate * hpModifier / statusModifier) * levelModifier * ballModifier;

  // Generate a random number between 1 and 255 (master ball modifier)
  const randomValue = Math.floor(Math.random() * 255) + 1;

  // Check if the random value is less than or equal to the capture probability
  return randomValue <= captureProbability;
}

// Example usage:
const baseCaptureRate = 45;  // Replace with the actual base capture rate of the Pokémon
const hpModifier = 0.3;         // Replace with the actual HP modifier
const statusModifier = 1;     // Replace with the actual status modifier
const levelModifier = 1;      // Replace with the actual level modifier

// Different Poké Ball modifiers
const masterBallModifier = 255;
const regularBallModifier = 1;
const ultraBallModifier = 1.5;
const greatBallModifier = 2;

// Choose a Poké Ball (replace ballModifier accordingly)
const ballModifier = greatBallModifier;

// Check if the Pokémon is captured
const isCaptured = calculateCaptureOutcome(baseCaptureRate, hpModifier, statusModifier, levelModifier, ballModifier);

console.log(`Pokemon ${isCaptured ? 'captured!' : 'broke free.'}`);
