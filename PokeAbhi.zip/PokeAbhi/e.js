function findInvalidCharacters(message) {
  // Regular expression to match invalid characters
  var regex = /[^a-zA-Z0-9]/g;
  // Find all invalid characters in the message
  var invalidCharacters = message.match(regex);
  // Return invalid characters found
  return invalidCharacters;
}
const a = (findInvalidCharacters("Hello123") == null) ? 'valid' : 'not'
const b = (findInvalidCharacters("Hello123!") == null) ? 'valid' : 'invalid : '+findInvalidCharacters("Hello123!")+''
// Example usage:
console.log(a,b)
