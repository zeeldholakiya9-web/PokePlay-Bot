function filterUniquePass(arr) {
    const passSet = new Set();
    const uniqueObjects = [];
    
    arr.forEach(obj => {
        if (!passSet.has(obj.pass)) {
            passSet.add(obj.pass);
            uniqueObjects.push(obj);
        }
    });
    
    return uniqueObjects;
}

const data = [{"pass":12}, {"pass":23}, {"pass":12}, {"pass":12},{"pass":23},{"pass":5}];
const uniqueData = filterUniquePass(data);
console.log(uniqueData);
