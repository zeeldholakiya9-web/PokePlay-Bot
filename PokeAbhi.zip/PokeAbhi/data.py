import requests
import json

def download_pokemon_data():
    url = "https://pokeapi.co/api/v2/pokemon?limit=5"  # Set limit to -1 to get all Pokémon
    
    try:
        response = requests.get(url)
        data = response.json()
        
        all_pokemon_data = []
        
        for pokemon in data["results"]:
            pokemon_url = pokemon["url"]
            pokemon_response = requests.get(pokemon_url)
            pokemon_data = pokemon_response.json()
            
            all_pokemon_data.append(pokemon_data)
            
        with open("pokemon_data.json", "w") as file:
            json.dump(all_pokemon_data, file, indent=4)
            
        print("Data downloaded successfully!")
        
    except requests.exceptions.RequestException as e:
        print(f"An error occurred: {e}")

# Call the function to download the data
download_pokemon_data()
