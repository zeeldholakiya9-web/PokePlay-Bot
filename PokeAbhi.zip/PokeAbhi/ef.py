import requests
import json

# Function to fetch effect data from PokeAPI
def fetch_effect_data(effect_id):
    api_endpoint = f"https://pokeapi.co/api/v2/move/{effect_id}"
    response = requests.get(api_endpoint)
    if response.status_code == 200:
        effect_data = response.json()
        return effect_data
    else:
        return None

# Read moves_info.json file
with open('moves_info.json', 'r') as moves_file:
    moves_info = json.load(moves_file)

# Dictionary to store effects
effects_dict = {}

# Function to add effect to moves and store in effects_dict
def add_effect(move_id, move_data):
    if 'effect_id' in move_data:
        effect_id = move_data['effect_id']
        effect_data = fetch_effect_data(effect_id)
        if effect_data:
            move_data['effect'] = effect_data['effect']
            move_data['effect_chance'] = effect_data.get('effect_chance', None)
            effects_dict[effect_id] = effect_data['effect']

# Iterate over moves and add effects
for move_id, move_data in moves_info.items():
    add_effect(move_id, move_data)

# Write effects_dict to effect.json
with open('effect.json', 'w') as effect_file:
    json.dump(effects_dict, effect_file, indent=2)

# Update moves_info.json with effect data
with open('moves_info.json', 'w') as moves_file:
    json.dump(moves_info, moves_file, indent=2)
