const fs = require('fs');

// Read JSON data from a file
const rawData = fs.readFileSync('./y.json');
const jsonData = JSON.parse(rawData);

// Define a function to rename values
function renameValues(obj) {
  const renamedObj = {};

  for (const key in obj) {
    let newKey = key;

    // Replace Min and Max with respective stats names
    newKey = newKey.replace(/^Min/, 'Min ' + obj['Name']);
    newKey = newKey.replace(/^Max/, 'Max ' + obj['Name']);

    renamedObj[newKey] = obj[key];
  }

  return renamedObj;
}

// Apply the renameValues function to each object in the array
const renamedData = jsonData.map(renameValues);

// Print or do something with the renamed data
console.log(renamedData);
