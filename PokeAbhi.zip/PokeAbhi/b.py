import requests
import json

def get_all_pokemon_data():
    api_url = "https://pokeapi.co/api/v2/pokemon/"
    response = requests.get(api_url, params={'limit': 1500})

    if response.status_code == 200:
        data = response.json()
        results = data.get('results', [])

        pokemon_data = {}
        for result in results:
            pokemon_name = result['name']
            pokemon_info = get_pokemon_info(pokemon_name)
            pokemon_data[pokemon_name] = pokemon_info

        return pokemon_data
    else:
        print("Failed to retrieve Pokémon data")

def get_pokemon_info(pokemon_name):
    api_url = f"https://pokeapi.co/api/v2/pokemon/{pokemon_name.lower()}/"
    response = requests.get(api_url)

    if response.status_code == 200:
        data = response.json()
        base_experience = data.get('base_experience', None)
        
        # Fetch growth rate from species endpoint
        species_url = data.get('species', {}).get('url', '')
        growth_rate = get_growth_rate(species_url)

        return {
            "base_experience": base_experience,
            "growth_rate": growth_rate
        }
    else:
        print(f"Failed to retrieve data for {pokemon_name}")

def get_growth_rate(species_url):
    response = requests.get(species_url)

    if response.status_code == 200:
        data = response.json()
        growth_rate = data.get('growth_rate', {}).get('name', None)
        return growth_rate
    else:
        print("Failed to retrieve growth rate")

# Example: Get base experience and growth rate for the first 1000 Pokémon and save to a JSON file
all_pokemon_data = get_all_pokemon_data()

# Save to JSON file
with open('pokemon_data.json', 'w') as json_file:
    json.dump(all_pokemon_data, json_file, indent=2)

print("Data saved to pokemon_data.json")
