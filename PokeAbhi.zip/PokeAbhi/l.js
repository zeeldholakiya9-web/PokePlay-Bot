const ll = "mothim"
let extra = ''
const te = [
520, 803, 338, 805, 519, 307, 799, 814, 815, 518,
  812, 308, 450, 282, 143,
  343, 351, 387,  20,
  401, 804, 798, 800, 802, 807, 797, 324,
  808, 806,   7,   8,   9, 200, 264, 530, 276,
  796, 352, 710, 809, 492, 813, 434,
  340, 547
]
const fs = require('fs');
const lvls = JSON.parse(fs.readFileSync('pokemon_data2.json', 'utf8'));
const lvl = JSON.parse(fs.readFileSync('pokemon_status_info.json', 'utf8'));
const dmoves = JSON.parse(fs.readFileSync('moves_info.json', 'utf8'));
const pokes2 = JSON.parse(fs.readFileSync('pokemon_base_stats_info2.json', 'utf8'));
const pokes = JSON.parse(fs.readFileSync('pokemon_info55_modified2.json', 'utf8'));
const tms = JSON.parse(fs.readFileSync('pokemon_base_exp2.json', 'utf8'));
const tms2 = JSON.parse(fs.readFileSync('moveset_data_updated.json', 'utf8'));
const pokemonData = JSON.parse(fs.readFileSync('pokemon_data_updated.json', 'utf8'));
const c = {};
const u = [];
const evolve = []
const evolved = []

for(const b of pokemonData[ll]){
let a;
try{
a = JSON.parse(fs.readFileSync('/root/pokebot/data/pokemon/'+b.identifier+''+extra+'.json', 'utf8'))
}catch(error){
a = {}
}

if(a.name && !pokes[b.identifier]){
const dg = a
pokes[b.identifier] = {}
pokes[b.identifier].pokedex_number = dg.national_id
pokes[b.identifier].front_default_image = null
const ty = []
for(const w of dg.types){
ty.push(w.toLowerCase())
}
const evy = Object.entries(dg.ev_yield).map(([key, value]) => {
    switch (key) {
        case "hp":
            return ["hp", value];
        case "atk":
            return ["attack", value];
        case "def":
            return ["defense", value];
        case "sp_atk":
            return ["special-attack", value];
        case "sp_def":
            return ["special-defense", value];
        default:
            return [key, value];
    }
});
pokes[b.identifier].types = ty
pokes[b.identifier].ev_yield = evy
const stats = {}
stats.hp = dg.base_stats.hp
stats.attack = dg.base_stats.atk
stats.defense = dg.base_stats.def
stats.special_attack = dg.base_stats.sp_atk
stats.special_defense = dg.base_stats.sp_def
stats.speed = dg.base_stats.speed
pokes2[b.identifier] = stats
const x = {
"name":b.identifier,
"baseExp":dg.base_exp_yield
}
tms.push(x)
const lb = dg.leveling_rate.replace(/ /g,'-').toLowerCase()
const m = {
"base_experience":dg.base_exp_yield,
"growth_rate":lb
}
lvls[b.identifier] = m
console.log(pokes2[b.identifier])
}
}
fs.writeFileSync('./pokemon_data2.json', JSON.stringify(lvls,null,2), 'utf8');
fs.writeFileSync('./pokemon_base_exp2.json', JSON.stringify(tms,null,2), 'utf8');
fs.writeFileSync('./pokemon_base_stats_info2.json', JSON.stringify(pokes2,null,2), 'utf8');
fs.writeFileSync('./pokemon_info55_modified2.json', JSON.stringify(pokes,null,2), 'utf8');
