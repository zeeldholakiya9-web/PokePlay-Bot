import requests
import json

def download_pokemon_names():
    base_url = "https://pokeapi.co/api/v2/pokemon?limit=1500"
    
    response = requests.get(base_url)
    
    if response.status_code == 200:
        pokemon_data = response.json()
        names = [pokemon['name'] for pokemon in pokemon_data['results']]
        
        with open('pokemon_names.json', 'w') as file:
            json.dump(names, file)
            
        print("Pokémon names have been successfully downloaded and saved to 'pokemon_names.json'.")
    else:
        print(f"Failed to retrieve Pokémon data. Status code: {response.status_code}")

if __name__ == "__main__":
    download_pokemon_names()
