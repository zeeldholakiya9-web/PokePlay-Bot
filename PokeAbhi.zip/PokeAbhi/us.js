const ballTypes = ['level','friend','moon','sport','net','nest','luxury','premier','quick','park','beast'];
let msg = '';
let userData2 = {balls:{}};

// Shuffle the ballTypes array
for (let i = ballTypes.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [ballTypes[i], ballTypes[j]] = [ballTypes[j], ballTypes[i]];
}

const numTypesToAdd = Math.floor(Math.random() * 3) + 3;
const selectedTypes = ballTypes.slice(0, numTypesToAdd);

selectedTypes.forEach(type => {
    const randomAmount = Math.floor(Math.random() * 5) + 1;
    userData2.balls[type] = (userData2.balls[type] || 0) + randomAmount;
    msg += `\n<b>+${randomAmount}</b> ${type} Balls`;
});
console.log(msg)
