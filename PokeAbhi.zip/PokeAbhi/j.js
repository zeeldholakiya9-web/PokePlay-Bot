const fs = require('fs');
const axios = require('axios');

async function downloadPokemonBaseExp() {
  try {
    // PokeAPI endpoint for Pokémon details
    const apiUrl = 'https://pokeapi.co/api/v2/pokemon/?limit=1500'

    // Make a request to the PokeAPI to get Pokémon data
    const response = await axios.get(apiUrl);

    // Extract relevant information (name and base_experience) from the response
    const pokemonData = response.data.results.map((pokemon) => ({
      name: pokemon.name,
      baseExp: null, // Placeholder for base experience; additional request needed to fetch this info
    }));

    // Fetch base experience for each Pokémon
    await Promise.all(
      pokemonData.map(async (pokemon) => {
        const pokemonDetails = await axios.get(`https://pokeapi.co/api/v2/pokemon/${pokemon.name}`);
        pokemon.baseExp = pokemonDetails.data.base_experience;
      })
    );

    // Convert the Pokémon data to JSON
    const jsonData = JSON.stringify(pokemonData, null, 2);

    // Write the JSON data to a file
    fs.writeFile('pokemon_base_exp.json', jsonData, 'utf8', (err) => {
      if (err) {
        console.error('Error writing JSON file:', err);
      } else {
        console.log('JSON file has been saved!');
      }
    });
  } catch (error) {
    console.error('Error fetching Pokémon data:', error.message);
  }
}

// Call the function to initiate the process
downloadPokemonBaseExp();
