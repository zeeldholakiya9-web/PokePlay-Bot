const u = []
const fs = require('fs');
const lvl = JSON.parse(fs.readFileSync('poke_level62.json', 'utf8'));
const dmoves = JSON.parse(fs.readFileSync('pokemon_data_updated.json', 'utf8'));
for(const a in dmoves){
for(const b of dmoves[a]){
if(!lvl[b.identifier]){
const y = dmoves[a].filter((o)=>lvl[o.identifier])[0]
if(y){
lvl[b.identifier] = lvl[y.identifier]
console.log(lvl[b.identifier])
}
}
}
}
fs.writeFileSync('./poke_level.json', JSON.stringify(lvl,null,2), 'utf8');
