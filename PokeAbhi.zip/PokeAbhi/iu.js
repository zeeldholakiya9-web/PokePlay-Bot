function generateRandomIVs(rarity) {
  const ivs = {};
  const stats = ['hp', 'atk', 'def', 'spa', 'spd', 'spe']; // Pokémon stats

  // Function to get a random number with chance
  function randomWithChance(min, max, chance) {
    return Math.random() < chance ? Math.floor(Math.random() * (max - min + 1)) + min : 0;
  }

  // Generate IVs based on rarity
  if (rarity === 'legendary' || rarity === 'mythical') {
    let totalIVs = 0;
    for (let stat of stats) {
      ivs[stat] = randomWithChance(20, 31, 0.2);
      totalIVs += ivs[stat];
    }
    // Ensure minimum total IVs
    while (totalIVs < 100) {
      let statToIncrease = stats[Math.floor(Math.random() * stats.length)];
      ivs[statToIncrease] += 1;
      totalIVs += 1;
    }
  } else if (rarity === 'rare') {
    let totalIVs = 0;
    for (let stat of stats) {
      ivs[stat] = randomWithChance(20, 31, 0.2);
      totalIVs += ivs[stat];
    }
    // Ensure minimum total IVs
    while (totalIVs < 70) {
      let statToIncrease = stats[Math.floor(Math.random() * stats.length)];
      ivs[statToIncrease] += 1;
      totalIVs += 1;
    }
  } else { // Normal or medium rarity
    for (let stat of stats) {
      ivs[stat] = Math.floor(Math.random() * 25); // IVs range from 0 to 31
    }
  }

  return ivs;
}

// Example usage:
const normalIVs = generateRandomIVs('normal');
console.log("Normal IVs:", normalIVs);

const rareIVs = generateRandomIVs('rare');
console.log("Rare IVs:", rareIVs);

const legendaryIVs = generateRandomIVs('legendary');
console.log("Legendary IVs:", legendaryIVs);
