const { Telegraf } = require('telegraf');
const WebSocket = require('websocket').w3cwebsocket;

const botToken = '6932944380:AAFNrjmFzMpN2Ejvaaa0QhrnJ2Es9UIH22w';
const showdownURL = 'ws://sim.smogon.com:8000/showdown/websocket';

const bot = new Telegraf(botToken);
const ws = new WebSocket(showdownURL);

let battleRoom = ''; // Store battle room name
let myPokemon = ''; // Store user's active Pokémon
let opponentPokemon = ''; // Store opponent's active Pokémon

// Helper function to send commands to Showdown server
function sendCommand(command) {
    if (battleRoom) {
        ws.send(`${battleRoom}|${command}`);
    }
}

// Handle messages from Telegram
bot.on('text', (ctx) => {
    const message = ctx.message.text;

    if (message.startsWith('/start')) {
        startBattle(ctx);
    } else if (battleRoom) {
        // Forward user message to Showdown server
        sendCommand(message);
    }
});

// Handle inline keyboard buttons
bot.action(/move\d/, (ctx) => {
    const moveIndex = ctx.match[0].slice(-1);
    sendCommand(`/choose move ${ctx.session.moves[moveIndex - 1]}`);
});

bot.action('forfeit', (ctx) => {
    sendCommand('/forfeit');
});

bot.action('switch', (ctx) => {
    ctx.reply('Choose a Pokémon to switch to:', {
        reply_markup: {
            inline_keyboard: ctx.session.team.map((pokemon, index) => (
                [{ text: `${pokemon.species} (${pokemon.hp}/${pokemon.maxHP})`, callback_data: `switch${index}` }]
            ))
        }
    });
});

bot.action(/switch\d/, (ctx) => {
    const index = parseInt(ctx.match[0].slice(-1));
    sendCommand(`/switch ${ctx.session.team[index].species}`);
});

function startBattle(ctx) {
    // Join a random battle room
    ws.send('|/join');
}

ws.onmessage = (message) => {
    const data = message.data.toString();
    console.log(data);

    // Parse battle updates
    if (data.startsWith('|')) {
        // Extract battle room name
        const roomData = data.split('|')[0];
        if (roomData.startsWith('>')) {
            battleRoom = roomData.slice(1);
        }
    } else if (data.startsWith('|player|')) {
        // Extract opponent's username
        const opponentUsername = data.split('|')[2];
        ctx.reply(`Your opponent: ${opponentUsername}`);
    } else if (data.startsWith('|poke|')) {
        // Extract Pokémon details
        const [, side, details] = data.split('|');
        const [species, level, hp, maxHP] = details.split(',').map(item => item.trim());
        const pokemon = { species, level, hp, maxHP };

        if (side === 'p1') {
            myPokemon = pokemon;
        } else {
            opponentPokemon = pokemon;
        }
    } else if (data.startsWith('|move|')) {
        // Extract available moves for user's Pokémon
        const [, side, moves] = data.split('|');
        if (side === 'p1') {
            ctx.session.moves = moves.split(',').map(item => item.trim());
        }
    }

    // Send battle information to Telegram
    ctx.replyWithHTML(`<b>Your Pokémon:</b> ${myPokemon.species} (${myPokemon.hp}/${myPokemon.maxHP})\n\n` +
                      `<b>Opponent's Pokémon:</b> ${opponentPokemon.species} (${opponentPokemon.hp}/${opponentPokemon.maxHP})\n\n` +
                      `<b>Your Moves:</b>\n${ctx.session.moves.map((move, index) => `${index + 1}. ${move}`).join('\n')}`, {
        reply_markup: {
            inline_keyboard: [
                [{ text: 'Forfeit', callback_data: 'forfeit' }],
                [{ text: 'Switch Pokémon', callback_data: 'switch' }]
            ]
        }
    });
};

bot.launch();
