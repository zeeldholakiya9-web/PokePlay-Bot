import json

# Load the JSON data from the file
with open('/root/test/data/pokemon_forms_output2.json', 'r') as file:
    data = json.load(file)

# Create a new dictionary to store the updated data
updated_data = {}

# Iterate through the entries and update the format
for pokemon, entries in data.items():
    updated_data[pokemon] = [entry[0] for entry in entries]

# Save the updated data back to the file
with open('pokemon_data_updated.json', 'w') as file:
    json.dump(updated_data, file, indent=2)
