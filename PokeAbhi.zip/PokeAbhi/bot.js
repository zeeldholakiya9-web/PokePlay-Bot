const path = require('path')
const REQUIRED_ADMIN_ID = 6265981509
const ADMIN_ID = REQUIRED_ADMIN_ID
function requireAdminId(list, listName) {
if(!list.includes(REQUIRED_ADMIN_ID)){
console.error(`${listName} must include admin id ${REQUIRED_ADMIN_ID}`)
process.exit(1)
}
}
const userState = new Map()
const stringSimilarity = require('string-similarity');
const schedule = require('node-schedule');
const NodeCache = require('node-cache');
const timeoutCache = new NodeCache();
const colors = ['red','orange','yellow','green','blue','lightblue','violet','darkviolet','black','grey','white','brown','pink','purple']
const fetch = require('node-fetch');
const { createCanvas, loadImage, registerFont } = require('canvas');
registerFont('./CabalBold-78yP.ttf', { family: 'Arial' });
const moment = require('moment');
const ballsdata = {
"regular":1,
"great":1.3,
"ultra":1.6,
"master":255,
"safari":1
}
const bags = {
"1":"https://te.legra.ph/file/340c9151c246c4262380d.jpg",
"2":"https://te.legra.ph/file/e60ce276626cc8f039ae2.jpg",
"3":"https://te.legra.ph/file/7bf7399dba1158909b3ee.jpg",
"4":"https://te.legra.ph/file/f635600afa470f91058b6.jpg",
"5":"https://te.legra.ph/file/3f97ddbd80bb1ea351191.jpg",
"6":"https://te.legra.ph/file/0ca46b70b24f64b496b5d.jpg",
"7":"https://te.legra.ph/file/e6cff8112d5d5d25ab4f9.jpg",
"8":"https://te.legra.ph/file/5b14ba8ad45e85376cc45.jpg",
"9":"https://te.legra.ph/file/017a600cc62b5af2ec0ec.jpg"
}
const safari =
{
  "kanto": ["articuno", "zapdos", "moltres", "mewtwo", "snorlax", "dragonite", "aerodactyl", "kabutops", "lapras", "tauros"],
  "jhoto": ["unown", "miltank", "skarmory", "heracross", "shuckle", "raikou", "entei", "suicune", "tyranitar", "lugia", "ho-oh"],
  "hoenn": ["tropius", "absol", "beldum", "metang", "metagross", "relicanth", "regirock", "regice", "registeel", "latias", "latios", "kyogre", "groudon", "jirachi", "deoxys"],
  "sinnoh": ["spiritomb", "rotom", "froslass", "uxie", "mesprit", "azelf", "dialga", "palkia", "heatran", "regigigas", "giratina", "cresselia", "phione", "manaphy", "darkrai", "arceus"],
  "unova": ["heatmor", "durant", "bouffalant", "cryogonal", "cinccino", "cobalion", "terrakion", "virizion", "tornadus", "thundurus", "tornadus", "landorus", "reshiram", "zekrom", "kyurem", "keldeo", "meloetta", "genesect"],
  "kalos": ["klefki", "hawlucha", "dedenne", "carbink", "zygarde", "diancie", "hoopa", "volcanion"],
  "alola": ["minior", "type-null", "silvally", "dhelmise", "turtonator", "komala", "mimikyu", "tapu-koko", "tapu-lele", "tapu-bulu", "tapu-fini", "necrozma", "magearna", "marshadow", "nihilego", "xurkitree", "celesteela", "kartana", "guzzlord", "stakataka", "zeraora"],
  "galar": ["dracozolt", "arctozolt", "dracovish", "arctovish", "duraludon", "kubfu", "urshifu", "zarude", "regieleki", "regidrago", "glastrier", "spectrier", "calyrex"],
  "hisui": ["enamorus", "ursaluna", "kleavor", "wyrdeer", "basculegion", "sneasler"],
  "paldea": ["annihilape", "kingambit", "great-tusk", "scream-tail", "brute-bonnet", "flutter-mane", "slither-wing", "sandy-shocks", "iron-treads", "iron-bundle", "iron-hands", "iron-jugulis", "iron-moth", "iron-thorns", "wo-chien","chien-pao", "ting-lu","chi-yu", "roaring-moon", "iron-valiant", "walking-wake", "iron-leaves", "okidogi", "munkidori", "fezandipiti", "ogerpon"]
}
let he = require('he');
const fs = require('fs')
const lvls = JSON.parse(fs.readFileSync('poke_level.json', 'utf8'));
const catch_rates = JSON.parse(fs.readFileSync('pokemon_rarity.json', 'utf8'));
const stones = JSON.parse(fs.readFileSync('stones.json', 'utf8'));
const pokes = JSON.parse(fs.readFileSync('pokemon_info55_modified.json', 'utf8'));
const pokemoves = JSON.parse(fs.readFileSync('moveset_data_updated.json', 'utf8'));
const re = JSON.parse(fs.readFileSync('poke_rarity.json', 'utf8'));
const pokestats = JSON.parse(fs.readFileSync('pokemon_base_stats_info.json', 'utf8'));
const trainerlevel = JSON.parse(fs.readFileSync('levels.json', 'utf8'));
const tmprices = JSON.parse(fs.readFileSync('tm_prices.json', 'utf8'));
const tms = JSON.parse(fs.readFileSync('tms2.json', 'utf8'));
const forms = JSON.parse(fs.readFileSync('pokemon_data_updated.json', 'utf8'));
const shiny = JSON.parse(fs.readFileSync('shiny.json', 'utf8'));
const dmoves = JSON.parse(fs.readFileSync('moves_info.json', 'utf8'));
const spawn = JSON.parse(fs.readFileSync('pokemon_status_info.json', 'utf8'));
const expdata = JSON.parse(fs.readFileSync('pokemon_base_exp.json', 'utf8'));
const pokes2 = JSON.parse(fs.readFileSync('pokemon_info2.json', 'utf8'));
const chart = JSON.parse(fs.readFileSync('exp_chart.json', 'utf8'));
const chains = JSON.parse(fs.readFileSync('evolution_chains2.json', 'utf8'));
const growth_rates = JSON.parse(fs.readFileSync('pokemon_data.json', 'utf8'));
const { Telegraf } = require('telegraf')
const bot = new Telegraf('5940934309:AAGKMg_NXVlDdvJmwruY1DucyCELZIe-zQ0')
const rdata = JSON.parse(fs.readFileSync('pokedex_data.json', 'utf8'));
const LocalSession = require('telegraf-session-local');
const session = new LocalSession({ database: 'hexa_session.json' });
bot.use(session.middleware());
const { chooseRandomNumbers, getLevel, stat, calculateTotalEV, calculateTotal,getRandomNature, saveUserData, getUserData, saveUserData2, check, c, Stats, word, Bar, plevel, calc, calcexp, sleep, eff, findEvolutionLevel, saveMessageData,loadMessageData,pokelist,pokelisthtml,incexp,incexp2,check2,check2q,getAllUserData,getTopUsers} = require('./func.js')
const regions = ['Kanto','Johto','Hoenn','Sinnoh','Unova','Kalos','Alola','Galar','Paldea']
const region = {
"Kanto":1,
"Johto":2,
"Hoenn":3,
"Sinnoh":4,
"Unova":5,
"Kalos":6,
"Alola":7,
"Galar":8,
"Paldea":9
}
const starters = {
  "Kanto": ["Bulbasaur", "Charmander", "Squirtle"],
  "Unova": ["Snivy", "Tepig", "Oshawott"],
  "Sinnoh": ["Turtwig", "Chimchar", "Piplup"],
  "Johto": ["Chikorita", "Cyndaquil", "Totodile"],
  "Hoenn": ["Treecko", "Torchic", "Mudkip"],
  "Paldea": ["Sprigatito", "Fuecoco", "Quaxly"],
  "Galar": ["Grookey", "Scorbunny", "Sobble"],
  "Alola": ["Rowlet", "Litten", "Popplio"],
  "Kalos": ["Chespin", "Fennekin", "Froakie"]
};
const emojis = {
  "normal": "🔘",
  "fire": "🔥",
  "water": "💧",
  "electric": "⚡",
  "grass": "🌱",
  "ice": "❄️",
  "fighting": "🥊",
  "poison": "☠️",
  "ground": "🌍",
  "flying": "🦅",
  "psychic": "🧠",
  "bug": "🐛",
  "rock": "🪨",
  "ghost": "👻",
  "dragon": "🐲",
  "dark": "🌑",
  "steel": "🔩",
  "fairy": "🧚"
}
let botStartTime = new Date().getTime();
let lastClicked = {}
let lastUsed = {}
let lastClicked2 = {}
let globalClicks = [];
let battlec = {}
bot.on('callback_query', async (ctx, next) => {
  try {
    const userId = ctx.from.id;
    const chatId = ctx.chat ? ctx.chat.id : 000;

// Check global click rate
const globalClicksPerSecond = globalClicks.filter(
  (timestamp) => Date.now() - timestamp < 1000
);

if (globalClicksPerSecond.length > 25) {
  const waitTime = Math.ceil((globalClicksPerSecond[0] + 1000 - Date.now()) / 1000);
  ctx.answerCbQuery(`Wait for a second.`);
  return;
}

// Check chat-specific click rate for groups
if (ctx.chat && ctx.chat.type != 'private') {
  if (!lastClicked[chatId]) {
    lastClicked[chatId] = [];
  }

  // Check total clicks in the current minute
  const currentMinuteStart = Date.now() - (Date.now() % 60000);
  const clicksPerMinute = lastClicked[chatId].filter(
    (timestamp) => timestamp >= currentMinuteStart
  );

  if (clicksPerMinute.length >= 19) {
    const waitTime = Math.ceil((clicksPerMinute[0] + 60000 - Date.now()) / 1000);
    ctx.answerCbQuery(`Try after ${waitTime} seconds.`);
    return;
  }
}

// Check if the user has clicked a button within the last 3 seconds
if (lastClicked2[chatId] && Date.now() - lastClicked2[chatId] < 800) {

  ctx.answerCbQuery('Try Again, Dont Spam');
  return;
}

// Update the last clicked timestamp
lastClicked2[chatId] = Date.now();

// Update global and chat-specific timestamps
globalClicks = [...globalClicks, Date.now()];

if (chatId && ctx.chat && ctx.chat.type != 'private') {
  lastClicked[chatId] = [...(lastClicked[chatId] || []), Date.now()];
}
await next();
}catch(error){
console.log(error)
}
})
bot.on('message',async (ctx,next) => {
try{
const updateTimestamp = ctx.message.date * 1000; // Convert to milliseconds
  if (updateTimestamp < botStartTime) {
    return;
  }
const chatId = ctx.from.id
if (lastClicked2[chatId] && Date.now() - lastClicked2[chatId] < 1000) {
    return;
  }
lastClicked2[chatId] = Date.now();
const data = await getUserData(ctx.from.id)
if(data.inv && !data.inv.exp){
data.inv.exp = 0
await saveUserData(ctx.from.id,data)
}
if (userState.has(ctx.from.id)) {
    const userData2 = userState.get(ctx.from.id);

    // Check if the user's message is a reply to the waiting message
    if (ctx.message.reply_to_message && ctx.message.reply_to_message.message_id === userData2.messageId) {
userState.delete(ctx.from.id);
var regex = /[^a-zA-Z0-9 ]/g;
  // Find all invalid characters in the message
  var invalidCharacters = ctx.message.text.match(regex);
if(invalidCharacters!=null){
const message = await ctx.replyWithMarkdown('Invalid Character: *'+invalidCharacters+'*',{reply_markup:{force_reply:true}})
const userData3 = {
      messageId: message.message_id,
      teamn: userData2.teamn // You can set the name to whatever you like
    };
    userState.set(ctx.from.id, userData3);
return
}
if(ctx.message.text.length > 12){
const message = await ctx.replyWithMarkdown('Maximum Length: *12*',{reply_markup:{force_reply:true}})
const userData3 = {
      messageId: message.message_id,
      teamn: userData2.teamn // You can set the name to whatever you like
    };
    userState.set(ctx.from.id, userData3);
return
}

if(ctx.message.text == ','){
delete data.inv[userData2.teamn]
ctx.replyWithMarkdown('Successfully Removed Name Of *Team '+userData2.teamn+'*',{reply_to_message_id:ctx.message.message_id})
}else{
data.inv[userData2.teamn] = ctx.message.text
ctx.replyWithMarkdown('Renamed *Team '+userData2.teamn+'* As *'+ctx.message.text+'*',{reply_to_message_id:ctx.message.message_id})
}
await saveUserData(ctx.from.id, data);
return
}
}
if(data.inv && data.inv.team && data.teams){
const team = data.teams[data.inv.team]
for(const a of team){
const pk = data.pokes.filter((pk)=> pk.pass==a)[0]
if(!pk){
data.teams[data.inv.team] = data.teams[data.inv.team].filter((p)=> p!=a)
await saveUserData(ctx.from.id,data)
}
}
}
if(data.inv && !data.inv.name){
data.inv.name = he.encode(ctx.from.first_name)
await saveUserData(ctx.from.id,data)
}
if(data.inv && !data.extra){
data.extra = {}
await saveUserData(ctx.from.id,data)
}
if(data.inv && !data.extra.megas){
data.extra.megas = {}
await saveUserData(ctx.from.id,data)
}
if(data.inv && Object.keys(data.extra.megas).length > 0){
const messageData = await loadMessageData();
const userIdToFind = String(ctx.from.id)
const result = Object.keys(messageData).find(key => {
  const value = messageData[key];
  return typeof value === 'object' && (value.turn === userIdToFind || value.oppo === userIdToFind);
});
console.log(result)
if(result){
let battleData = {};
    try {
      battleData = JSON.parse(fs.readFileSync('./battle/'+result+'.json', 'utf8'));
    } catch (error) {
      battleData = {};
    }
if(!battleData.megas){
battleData.megas = {}
}
if(!Object.keys(battleData.megas).includes(Object.keys(data.extra.megas)[0])){
const p = data.pokes.filter((pk)=> pk.pass == Object.keys(data.extra.megas)[0])[0]
if(p){
p.name = data.extra.megas[Object.keys(data.extra.megas)[0]]
}
data.extra.megas = {}
console.log(',kkkk')
await saveUserData(ctx.from.id,data)
}
}else{
const p = data.pokes.filter((pk)=> pk.pass == Object.keys(data.extra.megas)[0])[0]
console.log(',pppp')
if(p){
p.name = data.extra.megas[Object.keys(data.extra.megas)[0]]
}
data.extra.megas = {}
await saveUserData(ctx.from.id,data)
}
}
//        if (chatMember.status === "member" || chatMember.status === "administrator" || chatMember.status === "creator") {
await next();
//      } else {
//if(ctx.chat.type=='private'){
//          ctx.replyWithMarkdown('*This Bot is Not Available For Everybody To Use*');
//}
//      }
}catch(error){
console.log(error,ctx.from.id)
}
})
bot.command('start',async ctx => {
const data = await getUserData(ctx.from.id)
	if (!data.pokes) {
    const key = [[]];
    for (let i = 0; i < regions.length; i++) {
        if (i % 4 === 0) {
            key.push([]);
        }
        key[key.length - 1].push({ text: regions[i], callback_data: 'staut_' + regions[i] + '' });
  }
if(ctx.chat.type!='private'){
ctx.replyWithMarkdown('*Message me in private *',{reply_to_message_id:ctx.message.message_id,reply_markup:{inline_keyboard:[[{text:'Go',url:'t.me/PokePlayBot?start=start'}]]}})
return
}
ctx.replyWithMarkdown('*From Which Region You Wanna Start Your Journey?*',{reply_markup:{inline_keyboard:key}})
}else{
ctx.replyWithMarkdown('*You Have Already Started Your Journey*',{reply_to_message_id:ctx.message.message_id})
}
})
bot.action(/staut_/,async ctx => {
const data = await getUserData(ctx.from.id)
if(data.pokes){
ctx.deleteMessage();
return
}
if(ctx.callbackQuery.data.split('_')[1]=='back'){

const key = [[]];
    for (let i = 0; i < regions.length; i++) {
        if (i % 4 === 0) {
            key.push([]);
        }
        key[key.length - 1].push({ text: regions[i], callback_data: 'staut_' + regions[i] + '' });
  }
ctx.editMessageText('*From Which Region You Wanna Start Your Journey?*',{reply_markup:{inline_keyboard:key},parse_mode:'markdown'})
return
}
const pokes = starters[ctx.callbackQuery.data.split('_')[1]]
const key = [[]]
for(let i = 0; i < pokes.length; i++){
key[0].push({text:pokes[i],callback_data:'choose_'+pokes[i]+'_'+ctx.callbackQuery.data.split('_')[1]+''})
}
key.push([{text:'Back ⬅️',callback_data:'staut_back'}])
ctx.editMessageText('*Which Poke You Wanna Choose As Your Starter*',{parse_mode:'markdown',reply_markup:{inline_keyboard:key}})
})
bot.action(/choose_/, async (ctx) => {
  const poke = ctx.callbackQuery.data.split('_')[1];
  const pokeName = poke.toLowerCase()
  const poked = pokes[pokeName]
const region = ctx.callbackQuery.data.split('_')[2];
const data = await getUserData(ctx.from.id)
if(data.pokes){
ctx.deleteMessage();
return
}
  if (!poked) {
    ctx.answerCbQuery('n/a');
    return;
  }

const moves = pokemoves[pokeName]
if(!moves){
ctx.answerCbQuery('*This Poke Not Available*')
return
}
const moves2 = moves.moves_info.filter((move)=> move.learn_method == 'level-up' && move.level_learned_at < 6 && dmoves[move.id].power &&
dmoves[move.id].accuracy && dmoves[move.id].category != 'status')
const amoves = Math.floor(Math.random() * moves2.length)
  const randomMove = moves2[amoves];

  const iv = {
"hp":stat(pokeName),
"attack":stat(pokeName),
"defense":stat(pokeName),
"special_attack":stat(pokeName),
"special_defense":stat(pokeName),
"speed":stat(pokeName)
}

  const ev = {
"hp":0,
"attack":0,
"defense":0,
"special_attack":0,
"special_defense":0,
"speed":0
};
const pass2 = word(8)
const nat = getRandomNature()
const g = growth_rates[pokeName]
const exp = chart[g.growth_rate]["5"]
  const da = {
    name:pokeName,
    id: poked.pokedex_number,
    nature:nat,
    exp:exp,
    pass:pass2,
    ivs: iv,
    symbol: '',
    evs: ev,
    moves: [randomMove.id], // Push the randomly selected move ID
  };
if(!data.pokes){
data.pokes = []
}
data.inv = {
"pc":5000,
"region":"kanto",
"exp":0,
"avtar":"1",
"template":"1",
"id":"grey",
"data":"black"
}
data.balls = {
"regular":10,
"great":7,
"ultra":3
}
data.pokes.push(da)
const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
data.extra = {}
data.extra.date = `${day}/${month}/${year}`;
data.inv.hometown = region
await saveUserData2(ctx.from.id,data)
ctx.editMessageText('You Have Successfully Started Your Journey With *'+c(pokeName)+'*',{parse_mode:'markdown'})

});
bot.command('mypokemons',async ctx => {
const data = await getUserData(ctx.from.id)
if(!data.inv){
ctx.replyWithMarkdown('*Start your journey now*',{reply_to_message_id:ctx.message.message_id,
reply_markup:{inline_keyboard:[[
{text:'Start My Journey',url:'t.me/PokePlayBot?start=start',}]]}})
return
}
let msg = '*✦ Your Pokemon List*\n'
const page = 1
const pageSize = 25
const startIdx = (page - 1) * pageSize;
const endIdx = startIdx + pageSize;
const pokemon = data.pokes.slice(startIdx,endIdx)
msg += await pokelist(pokemon.map(item => item.pass),ctx,startIdx)
const key = []
const row = []
row.push({text:'<',callback_data:'pkege_'+(page-1)+'_'+ctx.from.id+''})
row.push({text:'>',callback_data:'pkege_'+(page+1)+'_'+ctx.from.id+''})
key.push(row)
const totalPages = Math.ceil(data.pokes.length / pageSize);
if(totalPages > 10){
const row = []
row.push({text:'(-5) <<',callback_data:'pkege_'+(page-5)+'_'+ctx.from.id+''})
row.push({text:'>> (+5)',callback_data:'pkege_'+(page+5)+'_'+ctx.from.id+''})
key.push(row)
}
if(totalPages > 40){
const row = []
row.push({text:'(-10) <<<',callback_data:'pkege_'+(page-10)+'_'+ctx.from.id+''})
row.push({text:'>>> (+10)',callback_data:'pkege_'+(page+10)+'_'+ctx.from.id+''})
key.push(row)
}
if(totalPages > 100){
const row = []
row.push({text:'(-25) <<<<',callback_data:'pkege_'+(page-25)+'_'+ctx.from.id+''})
row.push({text:'>>>> (+25)',callback_data:'pkege_'+(page+25)+'_'+ctx.from.id+''})
key.push(row)
}
ctx.replyWithMarkdown(msg,{reply_to_message_id:ctx.message.message_id,reply_markup:{inline_keyboard:key}})
})
bot.action(/pkege_/,async ctx => {
const data = await getUserData(ctx.from.id)
const id = ctx.callbackQuery.data.split('_')[2]
if(ctx.from.id!=id){
ctx.answerCbQuery('You Cant Use')
return
}
if(!data.inv){
ctx.replyWithMarkdown('*Start your journey now*',{reply_to_message_id:ctx.message.message_id,
reply_markup:{inline_keyboard:[[
{text:'Start My Journey',url:'t.me/PokePlayBot?start=start',}]]}})
return
}
const pageSize = 25
const totalPages = Math.ceil(data.pokes.length / pageSize);
const page = ctx.callbackQuery.data.split('_')[1]*1
if(page < 1 || page > totalPages){
return
}
let msg = '*✦ Your Pokemon List*\n'
const startIdx = (page - 1) * pageSize;
const endIdx = startIdx + pageSize;
const pokemon = data.pokes.slice(startIdx,endIdx)
msg += await pokelist(pokemon.map(item => item.pass),ctx,startIdx)
const key = []
const row = []
row.push({text:'<',callback_data:'pkege_'+(page-1)+'_'+ctx.from.id+''})
row.push({text:'>',callback_data:'pkege_'+(page+1)+'_'+ctx.from.id+''})
key.push(row)
if(totalPages > 10){
const row = []
row.push({text:'(-5) <<',callback_data:'pkege_'+(page-5)+'_'+ctx.from.id+''})
row.push({text:'>> (+5)',callback_data:'pkege_'+(page+5)+'_'+ctx.from.id+''})
key.push(row)
}
if(totalPages > 40){
const row = []
row.push({text:'(-10) <<<',callback_data:'pkege_'+(page-10)+'_'+ctx.from.id+''})
row.push({text:'>>> (+10)',callback_data:'pkege_'+(page+10)+'_'+ctx.from.id+''})
key.push(row)
}
if(totalPages > 100){
const row = []
row.push({text:'(-25) <<<<',callback_data:'pkege_'+(page-25)+'_'+ctx.from.id+''})
row.push({text:'>>>> (+25)',callback_data:'pkege_'+(page+25)+'_'+ctx.from.id+''})
key.push(row)
}


ctx.editMessageText(msg,{parse_mode:'markdown',reply_markup:{inline_keyboard:key}})
})
bot.action(/suger_/,async ctx => {
const id = ctx.callbackQuery.data.split('_')[1]
if(ctx.from.id!=id){
ctx.answerCbQuery()
return
}
const name = ctx.callbackQuery.data.split('_')[2]
const query = ctx.callbackQuery.data.split('_')[3]
const msgid = ctx.callbackQuery.data.split('_')[4]
const data = await getUserData(ctx.from.id)
const page = ctx.callbackQuery.data.split('_')[5]*1 || 1
const matches = data.pokes.filter((poke)=> (poke.name==name.toLowerCase()) || (poke.nickname && poke.nickname.toLowerCase() == name.toLowerCase()))
if(matches.length < 1){
ctx.editMessageText('You don\'t have *'+c(name)+'*',{parse_mode:'markdown'})
return
}
let msg = ''
const ore = []
const passes = []
const pageSize = 25
const startIdx = (page - 1) * pageSize;
let b = startIdx+1
const endIdx = startIdx + pageSize;
const pokemon = matches.slice(startIdx,endIdx)
msg += await pokelist(pokemon.map(item => item.pass),ctx,startIdx)
for(const p of pokemon){
ore.push({text:b,callback_data:''+query+'_'+p.pass+'_'+ctx.from.id+'_'+msgid+''})
b++;
}
  const rows = [];
  for (let i = 0; i < ore.length; i += 5) {
    rows.push(ore.slice(i, i + 5));
  }
const rows2 = []
if(page > 1){
rows2.push({text:'<',callback_data:'suger_'+id+'_'+name+'_'+query+'_'+msgid+'_'+(page-1)+''})
}
if(endIdx<matches.length){
rows2.push({text:'>',callback_data:'suger_'+id+'_'+name+'_'+query+'_'+msgid+'_'+(page+1)+''})
}
rows.push(rows2)
msg += '\n\nWhich Pokemon You Mean?'
ctx.editMessageText(msg,{parse_mode:'markdown',reply_markup:{inline_keyboard:rows}})
})
bot.action(/delete_/,async ctx => {
const id = ctx.callbackQuery.data.split('_')[1]
if(ctx.from.id==id){
ctx.deleteMessage()
}
})
bot.command('stats',async ctx => {
const data = await getUserData(ctx.from.id)
if(!data.inv){
ctx.replyWithMarkdown('*Start your journey now*',{reply_to_message_id:ctx.message.message_id,
reply_markup:{inline_keyboard:[[
{text:'Start My Journey',url:'t.me/PokePlayBot?start=start',}]]}})
return
}
const name = ctx.message.text.split(' ').slice(1).join(' ')
if(!name){
ctx.replyWithMarkdown('*Please tell whose poke stats you want.*',{reply_to_message_id:ctx.message.message_id})
return
}
const name2 = name.replace(/ /g,'-')
const p = pokes[name2.toLowerCase()]
if(!p){
const matches = stringSimilarity.findBestMatch(name2, data.pokes.map(poke => poke.name));
        const bestMatch = matches.bestMatch.target;
        const similarity = matches.bestMatch.rating;
if(similarity > 0.4 && name2.length > 3){
ctx.replyWithMarkdown('Did you mean : *'+c(bestMatch)+'*?',{reply_to_message_id:ctx.message.message_id,reply_markup:{inline_keyboard:[[{text:'Yes',callback_data:'suger_'+ctx.from.id+'_'+bestMatch+'_stats_'+ctx.message.message_id+''},{text:'No',callback_data:'delete_'+ctx.from.id+''}]]}})
}else{
ctx.replyWithMarkdown('*Wrong Name*',{reply_to_message_id:ctx.message.message_id})
}
return
}
const p22 = data.pokes.filter((poke)=> (poke.name==name2.toLowerCase()) || (poke.nickname && poke.nickname.toLowerCase() == name2.toLowerCase()))
if(!p22 || p22.length < 1){
ctx.replyWithMarkdown('You Does Not Have *'+name+'*',{reply_to_message_id:ctx.message.message_id})
return
}
if(p22.length == 1){
const p2 = p22[0]
const g = growth_rates[p2.name]
const exp = chart[g.growth_rate]
const matchingLevels = Object.keys(exp).filter(level => p2.exp >= exp[level]);
    const currentLevel = matchingLevels.length > 0 ? parseInt(matchingLevels[matchingLevels.length - 1]) : undefined;
const n = exp[currentLevel+1] || p2.exp
let n2 = n-p2.exp
let b7 = n2
if(n2==0){
b7 = p2.exp
}
let msg = '➤ *'+c(p2.nickname || p2.name)+' '+p2.symbol+'*'
msg += '\n*Level:* '+currentLevel+' | *Nature:* '+c(p2.nature)+''
msg += '\n*Types:* '+c(p.types.join(' / '))+''
msg += '\n*EXP:* '+p2.exp.toLocaleString()+''
msg += '\n*Need To Next Level:* '+n2.toLocaleString()+''
msg += '\n`'+Bar(p2.exp,b7)+'`'
const ivs = p2.ivs
const evs = p2.evs
let ivsText = 'IVs/EVs'
    ivsText += '\nStats                IV |  EV\n';
    ivsText += '—————————————————————————————\n';
    ivsText += `HP                   ${ivs.hp.toString().padStart(2)} |  ${evs.hp}\n`;
    ivsText += `Attack               ${ivs.attack.toString().padStart(2)} |  ${evs.attack}\n`;
    ivsText += `Defense              ${ivs.defense.toString().padStart(2)} |  ${evs.defense}\n`;
    ivsText += `Sp. Attack           ${ivs.special_attack.toString().padStart(2)} |  ${evs.special_attack}\n`;
    ivsText += `Sp. Defense          ${ivs.special_defense.toString().padStart(2)} |  ${evs.special_defense}\n`;
    ivsText += `Speed                ${ivs.speed.toString().padStart(2)} |  ${evs.speed}\n`;
    ivsText += '—————————————————————————————\n';
    ivsText += `Total               ${calculateTotal(ivs)} |  ${calculateTotal(evs)}\n`;
let img = p.front_default_image
const im = shiny.filter((poke)=>poke.name==name2)[0]
if(im && p2.symbol=='✨'){
img=im.shiny_url
}
if(!img){
bot.telegram.sendMessage(ADMIN_ID,'No image for '+name+'')

return}
ctx.replyWithPhoto(img,{caption:msg,parse_mode:'markdown',reply_to_message_id:ctx.message.message_id,
reply_markup:{inline_keyboard:[[
{text:'Stats',callback_data:'ste_'+p2.pass+'_'+ctx.from.id+''},{text:'IVs/EVs',callback_data:'pkisvs_'+p2.pass+'_'+ctx.from.id+''},{text:'Moveset',callback_data:'moves_'+p2.pass+'_'+ctx.from.id+''}]]}})
}else if(p22.length > 1){
const ore = []
let message = ''
const page = 1
const pageSize = 25
const startIdx = (page - 1) * pageSize;
let b = startIdx+1
const endIdx = startIdx + pageSize;
const pokemon = p22.slice(startIdx,endIdx)
message += await pokelist(pokemon.map(item => item.pass),ctx,startIdx)
for(const p of pokemon){
ore.push({text:b,callback_data:'stats_'+p.pass+'_'+ctx.from.id+'_'+ctx.message.message_id+''})
b++;
}
  const rows = [];
  for (let i = 0; i < ore.length; i += 5) {
    rows.push(ore.slice(i, i + 5));
  }
const rows2 = []
if(page > 1){
rows2.push({text:'<',callback_data:'suger_'+ctx.from.id+'_'+name2+'_stats_'+ctx.message.message_id+'_'+(page-1)+''})
}
if((endIdx+1)<p22.length){
rows2.push({text:'>',callback_data:'suger_'+ctx.from.id+'_'+name2+'_stats_'+ctx.message.message_id+'_'+(page+1)+''})
}
rows.push(rows2)
ctx.replyWithMarkdown(message+'\n\n_Check Stats Of Which Pokemon?_',{reply_to_message_id:ctx.message.message_id,reply_markup:{inline_keyboard:rows}})
}
})
bot.action(/stats_/,async ctx => {
const pass = ctx.callbackQuery.data.split('_')[1]
const id = ctx.callbackQuery.data.split('_')[2]
const mid = ctx.callbackQuery.data.split('_')[3]
if(id!=ctx.from.id){
return
}
const data = await getUserData(ctx.from.id)
const p2 = data.pokes.filter((poke)=> poke.pass == pass)[0]
if(!p2){
ctx.answerCbQuery('Poke Not Found')
return
}
const p = pokes[p2.name]
const g = growth_rates[p2.name]
const exp = chart[g.growth_rate]
const matchingLevels = Object.keys(exp).filter(level => p2.exp >= exp[level]);
    const currentLevel = matchingLevels.length > 0 ? parseInt(matchingLevels[matchingLevels.length - 1]) : undefined;
const n = exp[currentLevel+1] || p2.exp
let n2 = n-p2.exp
let b7 = n2
if(n2==0){
b7 = p2.exp
}
let msg = '➤ *'+c(p2.nickname || p2.name)+' '+p2.symbol+'*'
msg += '\n*Level:* '+currentLevel+' | *Nature:* '+c(p2.nature)+''
msg += '\n*Types:* '+c(p.types.join(' / '))+''
msg += '\n*EXP:* '+p2.exp.toLocaleString()+''
msg += '\n*Need To Next Level:* '+n2.toLocaleString()+''
msg += '\n`'+Bar(p2.exp,b7)+'`'
let img = p.front_default_image
const im = shiny.filter((poke)=>poke.name==p2.name)[0]
if(p2.symbol=='✨'){
img=im.shiny_url
}
if(!img){
bot.telegram.sendMessage(ADMIN_ID,'No image for '+p2.name+'')

return}
ctx.deleteMessage()
ctx.replyWithPhoto(img,{caption:msg,parse_mode:'markdown',reply_to_message_id:mid,
reply_markup:{inline_keyboard:[[
{text:'Stats',callback_data:'ste_'+p2.pass+'_'+ctx.from.id+''},{text:'IVs/EVs',callback_data:'pkisvs_'+pass+'_'+id+''},{text:'Moveset',callback_data:'moves_'+p2.pass+'_'+ctx.from.id+''}]]}})
})

bot.action(/moves_/,async ctx => {
const pass = ctx.callbackQuery.data.split('_')[1]
const id = ctx.callbackQuery.data.split('_')[2]
if(id!=ctx.from.id){
return
}
const data = await getUserData(ctx.from.id)
const poke = data.pokes.filter((poke)=> poke.pass == pass)[0]
let msg = ''
for(const move2 of poke.moves){
let move = dmoves[move2]
msg += '• <b>'+c(move.name)+'</b> ['+c(move.type)+' '+emojis[move.type]+']\n<b>Power:</b> '+move.power+', <b>Accuracy:</b> '+move.accuracy+'% <i>('+c(move.category.charAt(0))+')</i>\n'
}
ctx.editMessageCaption(msg,{parse_mode:'HTML',reply_markup:{
inline_keyboard:[[{text:'Info',callback_data:'info_'+pass+'_'+id+''},{text:'IVs/EVs',callback_data:'pkisvs_'+pass+'_'+id+''},
{text:'Stats',callback_data:'ste_'+pass+'_'+id+''}]]}})
})
bot.action(/info_/,async ctx => {
const pass = ctx.callbackQuery.data.split('_')[1]
const id = ctx.callbackQuery.data.split('_')[2]
if(id!=ctx.from.id){
return
}
const data = await getUserData(ctx.from.id)
const p2 = data.pokes.filter((poke)=> poke.pass == pass)[0]
const p = pokes[p2.name]
const g = growth_rates[p2.name]
const exp = chart[g.growth_rate]
const matchingLevels = Object.keys(exp).filter(level => p2.exp >= exp[level]);
const currentLevel = matchingLevels.length > 0 ? parseInt(matchingLevels[matchingLevels.length - 1]) : undefined;
const n = exp[currentLevel+1] || p2.exp
let n2 = n-p2.exp
let b7 = n2
if(n2==0){
b7 = p2.exp
}
let msg = '➤ *'+c(p2.nickname || p2.name)+' '+p2.symbol+'*'
msg += '\n*Level:* '+currentLevel+' | *Nature:* '+c(p2.nature)+''
msg += '\n*Types:* '+c(p.types.join(' / '))+''
msg += '\n*EXP:* '+p2.exp.toLocaleString()+''
msg += '\n*Need To Next Level:* '+n2.toLocaleString()+''
msg += '\n`'+Bar(p2.exp,b7)+'`'
const ivs = p2.ivs
const evs = p2.evs
let ivsText = 'IVs/EVs'
    ivsText += '\nStats                IV |  EV\n';
    ivsText += '—————————————————————————————\n';
    ivsText += `HP                   ${ivs.hp.toString().padStart(2)} |  ${evs.hp}\n`;
    ivsText += `Attack               ${ivs.attack.toString().padStart(2)} |  ${evs.attack}\n`;
    ivsText += `Defense              ${ivs.defense.toString().padStart(2)} |  ${evs.defense}\n`;
    ivsText += `Sp. Attack           ${ivs.special_attack.toString().padStart(2)} |  ${evs.special_attack}\n`;
    ivsText += `Sp. Defense          ${ivs.special_defense.toString().padStart(2)} |  ${evs.special_defense}\n`;
    ivsText += `Speed                ${ivs.speed.toString().padStart(2)} |  ${evs.speed}\n`;
    ivsText += '—————————————————————————————\n';
    ivsText += `Total               ${calculateTotal(ivs)} |  ${calculateTotal(evs)}\n`;
ctx.editMessageCaption(msg,{parse_mode:'markdown',
reply_markup:{inline_keyboard:[[
{text:'Stats',callback_data:'ste_'+p2.pass+'_'+ctx.from.id+''},{text:'IVs/EVs',callback_data:'pkisvs_'+pass+'_'+id+''},{text:'Moveset',callback_data:'moves_'+p2.pass+'_'+ctx.from.id+''}]]}})
})
bot.action(/ste_/,async ctx => {
const pass = ctx.callbackQuery.data.split('_')[1]
const id = ctx.callbackQuery.data.split('_')[2]
if(id!=ctx.from.id){
return
}
const data = await getUserData(ctx.from.id)
const p2 = data.pokes.filter((poke)=> poke.pass == pass)[0]
const g = growth_rates[p2.name]
const exp = chart[g.growth_rate]
const matchingLevels = Object.keys(exp).filter(level => p2.exp >= exp[level]);
const level = matchingLevels.length > 0 ? parseInt(matchingLevels[matchingLevels.length - 1]) : undefined;
const base = pokestats[p2.name]
const stats = await Stats(base,p2.ivs,p2.evs,c(p2.nature),level)
let statsText = 'Stats_Points'
statsText += '\nStats              Points\n';
statsText += '———————————————————————————\n';
statsText += `HP                   ${stats.hp.toString().padStart(2)}\n`;
    statsText += `Attack               ${stats.attack.toString().padStart(2)}\n`;
    statsText += `Defense              ${stats.defense.toString().padStart(2)}\n`;
    statsText += `Sp. Attack           ${stats.special_attack.toString().padStart(2)}\n`;
    statsText += `Sp. Defense          ${stats.special_defense.toString().padStart(2)}\n`;
    statsText += `Speed                ${stats.speed.toString().padStart(2)}\n`;
 ctx.editMessageCaption('```'+statsText+'```',{parse_mode:'markdownv2',reply_markup:{inline_keyboard:[[{text:'Info',callback_data:'info_'+pass+'_'+id+''},{text:'IVs/EVs',callback_data:'pkisvs_'+pass+'_'+id+''},{text:'Moveset',callback_data:'moves_'+pass+'_'+id+''}]]}})
})
bot.action(/pkisvs_/,async ctx => {
const pass = ctx.callbackQuery.data.split('_')[1]
const id = ctx.callbackQuery.data.split('_')[2]
if(id!=ctx.from.id){
return
}
const data = await getUserData(ctx.from.id)
const p2 = data.pokes.filter((poke)=> poke.pass == pass)[0]
const ivs = p2.ivs
const evs = p2.evs
let ivsText = ''
    ivsText += '\nStats          IV |  EV\n';
    ivsText += '————————————————————————\n';
    ivsText += `HP              ${ivs.hp.toString().padStart(2)} |  ${evs.hp}\n`;
    ivsText += `Attack          ${ivs.attack.toString().padStart(2)} |  ${evs.attack}\n`;
    ivsText += `Defense         ${ivs.defense.toString().padStart(2)} |  ${evs.defense}\n`;
    ivsText += `Sp. Attack      ${ivs.special_attack.toString().padStart(2)} |  ${evs.special_attack}\n`;
    ivsText += `Sp. Defense     ${ivs.special_defense.toString().padStart(2)} |  ${evs.special_defense}\n`;
    ivsText += `Speed           ${ivs.speed.toString().padStart(2)} |  ${evs.speed}\n`;
    ivsText += '————————————————————————\n';
    ivsText += `Total           ${calculateTotal(ivs)} |  ${calculateTotal(evs)}\n`;
 ctx.editMessageCaption('`'+ivsText+'`',{parse_mode:'markdownv2',reply_markup:{inline_keyboard:[[{text:'Info',callback_data:'info_'+pass+'_'+id+''},{text:'Moveset',callback_data:'moves_'+pass+'_'+id+''},{text:'Stats',callback_data:'ste_'+pass+'_'+id+''}]]}})
})


bot.command('hunt', async (ctx) => {
const data = await getUserData(ctx.from.id)
if(!data.inv){
ctx.replyWithMarkdown('*Start your journey now*',{reply_to_message_id:ctx.message.message_id,
reply_markup:{inline_keyboard:[[
{text:'Start My Journey',url:'t.me/PokePlayBot?start=start',}]]}})
return
}
if(ctx.chat.type!='private'){
ctx.replyWithMarkdown('*Use in private to hunt poke*',{reply_to_message_id:ctx.message.message_id})
return
}
if(!ctx.session.key){
ctx.replyWithMarkdown('*Opening Keyboard.....*',{reply_markup:{keyboard:[['/hunt','/close']],resize_keyboard:true}})
ctx.session.key = true
}
  const region = data.inv.region
if(!region || !rdata[region]){
 ctx.replyWithMarkdown('*Use /travel and go any region*',{reply_to_message_id:ctx.message.message_id})
return
}
if(!data.inv.team){
ctx.replyWithMarkdown('*Use /myteams and set-up your team*',{reply_to_message_id:ctx.message.message_id})
return
}
const currentDate = moment().format('YYYY-MM-DD');
if(!data.extra.huntd || data.extra.huntd != currentDate){
data.extra.huntd = currentDate
data.extra.hunts = 0
}
if(data.extra.hunts > 2000){
ctx.replyWithMarkdown('You have reached the *Max* amount of hunt *Per Day*',{reply_to_message_id:ctx.message.message_id})
return
}
data.extra.hunts += 1
await saveUserData(ctx.from.id,data)
const mdata = await loadMessageData();
if(mdata.battle.includes(ctx.from.id)){
ctx.replyWithMarkdown('You are in a *battle*',{reply_to_message_id:ctx.message.message_id})
return
}
if(Math.random() < 0.0003){
const n5 = Object.keys(tms.tmnumber)
const num = n5[Math.floor(Math.random()*n5.length)]
if(!data.tms){
data.tms = {}
}
if(!data.tms[String(num)]){
data.tms[String(num)] = 0
}
data.tms[String(num)] += 1
await saveUserData(ctx.from.id,data)
ctx.replyWithMarkdown('You Found A *TM'+num+'* ⚙')
return
}

if(Math.random()<0.00005){
const st = Object.keys(stones)
const stone = st[Math.floor(Math.random()*st.length)]
ctx.replyWithPhoto(stones[stone].image,{caption:'You found a *'+c(stone)+'*',parse_mode:'markdown'})
if(!data.inv.stones){
data.inv.stones = []
}
data.inv.stones.push(stone)
await saveUserData(ctx.from.id,data)
return}

let ar = ['common','medium']
const rt = Math.random()
if(rt<0.05){
ar.push('rare')
}
if(rt<0.0003){
ar.push('legendry')
ar.push('legendary')
}
if(rt<0.00004){
ar.push('mythical')
}
if(data.balls.safari && data.balls.safari > 0){
ar = ['legendry','legendary']
if(Math.random()<0.4){
ar.push('rare')
}
}
const list2 = rdata[region]
let rg = data.inv.region
if(['alola', 'melmele', 'akala', 'ulaula', 'poni'].includes(data.inv.region.toLowerCase())){
rg = 'alola'
}
if(['galar', 'isle-of-armor', 'crown-tundra'].includes(data.inv.region.toLowerCase())){
rg = 'galar'
}
if(data.inv.region.toLowerCase()=='hisui'){
rg = 'hisui'
}
if(['paldea', 'kitakami', 'blueberry'].includes(data.inv.region.toLowerCase())){
rg = 'paldea'
}
if(data.balls.safari && data.balls.safari > 0){
var list = safari[data.extra.saf.toLowerCase()]
}else{
var list = Object.keys(spawn).filter(pk=>ar.includes(spawn[pk].toLowerCase()) && list2.includes(pk))
}
const name5 = list[Math.floor(Math.random()*list.length)]
const nut = ['gmax','mega','origin','primal']
if(data.balls.safari && data.balls.safari > 0){
var fr = forms[name5].filter(pk=> !nut.some((pk2)=> pk.identifier.includes(pk2)))
}else{
var fr = forms[name5].filter(pk=> !nut.some((pk2)=> pk.identifier.includes(pk2)) && ar.includes(spawn[pk].toLowerCase()))
}
const fr2 = fr.filter(pk=>pk.identifier.includes(rg))
const fr3 = fr.filter(pk=> !pk.identifier.includes('alola') && !pk.identifier.includes('galar') && !pk.identifier.includes('hisui') && !pk.identifier.includes('paldea'))
const name = fr2.length > 0 ? fr2[Math.floor(Math.random()*fr2.length)].identifier : fr3[Math.floor(Math.random()*fr3.length)].identifier
const ul = lvls[name]
let m = Math.max(ul.split('-')[0]*1,5)
let m2 = ul.split('-')[1]*1
const evo2 = chains.evolution_chains.filter((chain)=>chain.evolved_pokemon==name.toLowerCase() && chain.evolution_level && chain.evolution_method == 'level-up')[0]
const evo = chains.evolution_chains.filter((chain)=>chain.current_pokemon==name.toLowerCase() && chain.evolution_level && chain.evolution_method == 'level-up')[0]

if(evo){
m2 = evo.evolution_level
}
if(evo2){
m=evo2.evolution_level
}
if(!m){
m=20
}
if(!m2){
m2 = Math.min((m+30),60)
}

const level = Math.floor(Math.random()*(m2-m))+m
const pdata = pokes[name]
const im = shiny.filter((poke)=>poke.name==name)[0]
if(!pdata){
return
}
let p = pdata.front_default_image
let s = ''
const l = Math.random()
if(im && l<0.0001){
p=im.shiny_url
console.log(im)
s='✨'
}
if(!p){
bot.telegram.sendMessage(ADMIN_ID,'No image for '+name+'')

return}
if(s=='✨'){
ctx.replyWithMarkdown('You Found A *Shiny* ✨ Pokemon',{reply_markup:{remove_keyboard:true}})
ctx.session.key = false
}
if(!data.pokeseen){
data.pokeseen = []
}
if(!data.pokeseen.includes(name)){
data.pokeseen.push(name)
await saveUserData(ctx.from.id,data)
}
const msg = 'A wild *'+c(name)+'* (*Lv.* '+level+') '+s+' has appeared'
const m62 = await ctx.replyWithPhoto(p,{caption:msg,parse_mode:'markdown',reply_to_message_id:ctx.message.message_id,reply_markup:{inline_keyboard:[[{text:'Capture',callback_data:'catch_'+name+'_'+level+'_'+s+''},{text:'EV yield',callback_data:'ev_'+name+''}]]}})
ctx.session.name = m62.message_id
});
bot.action(/run_/,async ctx => {
const messageData = await loadMessageData();
if(messageData[ctx.from.id]) {
messageData.battle = messageData.battle.filter((chats)=> chats !==ctx.from.id)
delete messageData[ctx.from.id];
await saveMessageData(messageData)
}
ctx.editMessageText('Successfully Escaped')
})
bot.action(/catch_/,async ctx => {
if (battlec[ctx.chat.id] && Date.now() - battlec[ctx.chat.id] < 1600) {

  ctx.answerCbQuery('Try Again');
  return;
}
battlec[ctx.chat.id] = Date.now();
const name = ctx.callbackQuery.data.split('_')[1]
if(ctx.session.name!=ctx.callbackQuery.message.message_id){
ctx.answerCbQuery(''+c(name)+' Has been fled')
return
}
const mdata = await loadMessageData();
if(mdata.battle.includes(ctx.from.id)){
ctx.answerCbQuery('You Are In A Battle')
return
}

const level = ctx.callbackQuery.data.split('_')[2]*1
const f = ctx.callbackQuery.data.split('_')[3]
let msg = '<b>✦ The Pokomon battle commences!</b>'
const op = pokes[name]
const data = await getUserData(ctx.from.id)
if(data.teams[data.inv.team].length < 1){
ctx.replyWithMarkdown(' Add Some *Pokes* In Main Team.')
return
}
const ss = data.teams[data.inv.team][0]
const p = data.pokes.filter((poke)=>poke.pass==ss)[0]
const p2 = pokes[p.name]
k = 0
if(spawn[name].toLowerCase() == 'legendry' || spawn[name].toLowerCase()== 'legendary'){
k = 15
}
const iv = {
"hp":stat(name),
"attack":stat(name),
"defense":stat(name),
"special_attack":stat(name),
"special_defense":stat(name),
"speed":stat(name)
}

  const ev = {
"hp":0,
"attack":0,
"defense":0,
"special_attack":0,
"special_defense":0,
"speed":0
};
const nat = getRandomNature()
const base = pokestats[name]
const base2 = pokestats[p.name]
const uname = he.encode(ctx.from.first_name)
const stats2 = await Stats(base,iv,ev,c(nat),level)
const hp2 = stats2.hp
const clevel = plevel(p.name,p.exp)
const stats = await Stats(base2,p.ivs,p.evs,c(p.nature),clevel)
const hp = stats.hp
const moves5 = pokemoves[name]
const moves2 = moves5.moves_info.filter((move)=> move.learn_method == 'level-up' && 
move.level_learned_at < level && dmoves[move.id].power && dmoves[move.id].accuracy)
const am = Math.min(Math.max(moves2.length,1),4)
const omoves = moves2.slice(-am)

msg += '\n\n<b>wild</b> '+c(name)+' ['+c(op.types.join(' / '))+']'
msg += '\n<b>Level :</b> '+level+' | <b>HP :</b> '+hp2+'/'+hp2+''
msg += '\n<code>'+Bar(hp2,hp2)+'</code>'
msg += '\n\n<b>Turn :</b> <code>'+uname+'</code>'
msg += '\n<b>'+c(p.name)+'</b> ['+c(p2.types.join(' / '))+']'
msg += '\n<b>Level :</b> '+clevel+' | <b>HP :</b> '+hp+'/'+hp+''
msg += '\n<code>'+Bar(hp,hp)+'</code>'
msg += '\n\n<b>Moves :</b>'
const moves = []
const bword = word(10)
let battleData = {};
    try {
      battleData = JSON.parse(fs.readFileSync('./battle/'+bword+'.json', 'utf8'));
    } catch (error) {
      battleData = {};
    }
for(const move2 of p.moves){
let move = dmoves[move2]
msg += '\n• <b>'+c(move.name)+'</b> ['+c(move.type)+' '+emojis[move.type]+']\n<b>Power:</b> '+move.power+'<b>, Accuracy:</b> '+move.accuracy+' ('+c(move.category.charAt(0))+')'
moves.push(''+move2+'')
}
const buttons = moves.map((word) => ({ text: c(dmoves[word].name), callback_data: 'atk_'+word+'_'+bword+'' }));
while(buttons.length < 4){
buttons.push({text:'  ',callback_data:'empty'})
}
  const rows = [];
  for (let i = 0; i < buttons.length; i += 2) {
    rows.push(buttons.slice(i, i + 2));
  }
const key2 = [{text:'Bag',callback_data:'bag_'+bword+''},{text:'Escape',callback_data:'run_'+bword+''},{text:'Pokemon',callback_data:'pokemon_'+bword+''}]
rows.push(key2)
  const keyboard = {
    inline_keyboard: rows,key2
  };
battleData.c = p.pass
battleData.chp = hp
battleData.ochp = hp2
battleData.ohp = hp2
battleData.ivs = iv
battleData.evs = ev
battleData.nat = nat
battleData.level = level
battleData.name = name
battleData.omoves = omoves
battleData.ded = []
battleData.symbol = ''
if(omoves.length < 1){
ctx.answerCbQuery('Unable To Catch This Poke, Admins Trying To Fix It. Till Please Hunt Another Pokemon',{show_alert:true})
return
}
if(f && f=='✨'){
battleData.symbol = '✨'
}
var la = {}
var tem = {}
for(const p of data.teams[data.inv.team]){
const pk = data.pokes.filter((poke)=> poke.pass == p)
if(pk){
const base = pokestats[pk[0].name]
const clevel = plevel(pk[0].name,pk[0].exp)
const stats = await Stats(base,pk[0].ivs,pk[0].evs,c(pk[0].nature),clevel)
la[pk[0].pass] = clevel
tem[pk[0].pass] = stats.hp
}
}
battleData.team = tem
battleData.la = la
await fs.writeFileSync('./battle/' +bword+ '.json', JSON.stringify(battleData, null, 2));
ctx.session.name = ''
if(data.balls.safari && data.balls.safari > 0){
var mg = await ctx.replyWithHTML('<b>wild</b> '+c(name)+' ['+c(op.types.join(' / '))+'] - <b>Level :</b> '+level+'\n\n<b>Safari Balls:</b> '+data.balls.safari+'',{
reply_markup:{
inline_keyboard:[[{text:'Use Safari Ball',callback_data:'ball_safari_'+bword+''},
{text:'Escape',callback_data:'run_'+bword+''}]]}})
}else{
var mg = await ctx.replyWithHTML(msg,{reply_markup:keyboard})
}
const messageData = await loadMessageData();
messageData.battle.push(ctx.from.id)
    messageData[ctx.chat.id] = { mid: mg.message_id, timestamp: Date.now(),id:ctx.from.id };
await saveMessageData(messageData);
})
bot.action(/atk_/,async ctx => {
if (battlec[ctx.chat.id] && Date.now() - battlec[ctx.chat.id] < 1600) {

  ctx.answerCbQuery('Try Again');
  return;
}
battlec[ctx.chat.id] = Date.now();
const move = ctx.callbackQuery.data.split('_')[1]
const bword = ctx.callbackQuery.data.split('_')[2]
let battleData = {};
    try {
      battleData = JSON.parse(fs.readFileSync('./battle/'+bword+'.json', 'utf8'));
    } catch (error) {
      battleData = {};
    }
const data = await getUserData(ctx.from.id)
const move1 = dmoves[move]
const move2 = dmoves[battleData.omoves[Math.floor(Math.random()*battleData.omoves.length)].id]
const p = data.pokes.filter((poke)=>poke.pass==battleData.c)[0]
const base = pokestats[battleData.name]
const base2 = pokestats[p.name]
const uname = he.encode(ctx.from.first_name)
const stats2 = await Stats(base,battleData.ivs,battleData.evs,c(battleData.nat),battleData.level)
const clevel = plevel(p.name,p.exp)
const stats = await Stats(base2,p.ivs,p.evs,c(p.nature),clevel)
let a = stats.attack
let d = stats2.defense
let a2 = stats2.attack
let d2 = stats.defense
const t1 = pokes[battleData.name].types[0]
const t2 = pokes[battleData.name].types[1] ? c(pokes[battleData.name].types[1]) : null
const eff1 = await eff(c(move1.type),c(t1),t2)
const t3 = pokes[p.name].types[0]
const t4 = pokes[p.name].types[1] ? c(pokes[p.name].types[1]) : null
const eff2 = await eff(c(move2.type),c(t3),t4)
if(move1.category=='special' || move2.category == 'special'){
a = stats.special_attack
d = stats2.special_defense
a2 = stats2.special_attack
d2 = stats.special_defense
}
const damage = calc(a,d,clevel,move1.power,eff1)
const damage2 = calc(a2,d2,battleData.level,move2.power,eff2)
battleData.chp = Math.max((battleData.chp-damage2),0)
battleData.team[battleData.c] = Math.max((battleData.team[battleData.c]-damage2),0)
battleData.ochp -= damage
await fs.writeFileSync('./battle/' +bword+ '.json', JSON.stringify(battleData, null, 2));
if(battleData.ochp < 1){
const ai = Math.floor(battleData.level/10)+1
if(!data.inv.pc){
data.inv.pc = 0
}
data.inv.pc += ai
if(!data.inv.exp){
data.inv.exp = 0
}
const ei = Math.floor(Math.random()*700)+200
data.inv.exp += ei
await saveUserData(ctx.from.id,data)
const baseexp = expdata.filter((poke)=> poke.name == battleData.name)[0]
const g = growth_rates[p.name]
const exp69 = chart[g.growth_rate]["100"]
const clevel = battleData.la[p.pass]
if(baseexp && clevel!=100){
const ee = await calcexp(baseexp.baseExp,battleData.level,clevel)
p.exp = Math.min((p.exp+ee),exp69)
var l2 = await plevel(p.name,p.exp)
const evo = chains.evolution_chains.filter((chain)=>chain.current_pokemon==p.name)[0]
if(evo && evo.evolution_level && evo.evolution_method == 'level-up' && evo.evolution_level <= l2 &&  evo.evolution_level > clevel){
if(ctx.chat.type!='private'){
ctx.replyWithHTML('<a href="tg://user?id='+ctx.from.id+'"><b>'+uname+'</b></a> Your Pokemon <b>'+c(p.name)+'</b> Is Ready To Evolve',{reply_markup:{inline_keyboard:[[{text:'Evolve',url:'t.me/pokeplaybot'}]]}})
}
bot.telegram.sendMessage(ctx.from.id,'*'+c(p.name)+'* Is Ready To Evolve',{parse_mode:'markdown',reply_markup:{inline_keyboard:[[{text:'Evolve',callback_data:'evy_'+p.name+'_'+p.pass+''}]]}})
}
if((l2-clevel)!= 0){
const moves = pokemoves[p.name]
const moves2 = moves.moves_info.filter((move)=> move.learn_method == 'level-up' && move.level_learned_at > clevel && move.level_learned_at <= l2 && dmoves[move.id].power && dmoves[move.id].accuracy && dmoves[move.id].category != 'status')
if(moves2.length > 0){
for(const m of moves2){
if(!p.moves.includes(m.id)){
if(p.moves.length < 4){
p.moves.push(m.id)
await saveUserData(ctx.from.id,data)
bot.telegram.sendMessage(ctx.from.id,'<b>'+c(p.name)+'</b> (<b>Lv.</b> '+l2+') Has Learnt A New Move <b>'+c(dmoves[m.id].name)+'</b> ['+c(dmoves[m.id].type)+' '+emojis[dmoves[m.id].type]+'].',{parse_mode:'HTML'})
}else{
const options = {
  timeZone: 'Asia/Kolkata',
  month: 'numeric',
  day: 'numeric',
  hour: 'numeric',
  minute: 'numeric',
  hour12: true,
};
if(ctx.chat.type!='private'){
ctx.replyWithHTML('<a href="tg://user?id='+ctx.from.id+'"><b>'+data.inv.name+'</b></a>, <b>'+c(p2.name)+'</b> (<b>Lv.</b> '+(currentLevel+1)+') Wants To Learn A New Move',{reply_markup:{inline_keyboard:[[{text:'Go',url:'t.me/pokeplaybot'}]]}})
}
const d = new Date().toLocaleString('en-US', options)
const mdata = await loadMessageData();
const m77 = await bot.telegram.sendMessage(ctx.from.id,'<b>'+c(p.name)+'</b> (<b>Lv.</b> '+l2+') Wants To Learn A New Move <b>'+c(dmoves[m.id].name)+'</b> ['+c(dmoves[m.id].type)+' '+emojis[dmoves[m.id].type]+'].\n\nBut <b>'+c(p.name)+'</b> Already Knows 4 Moves He Have To Forget One Move To Learn <b>'+c(dmoves[m.id].name)+'</b>\n<i>You Have 15 Min To Choose.</i>',{reply_markup:{inline_keyboard:[[{text:'Go Next',callback_data:'lrn_'+p.pass+'_'+m.id+'_'+d+''}]]},parse_mode:'HTML'})
if(!mdata.moves){
mdata.moves = {}
}
mdata.moves[m77.message_id] = {chat:ctx.from.id,td:d,poke:p.name,move:dmoves[m.id].name}
await saveMessageData(mdata)
}
}
}
}
}
await saveUserData(ctx.from.id,data)
}
const data99 = pokes[battleData.name]
let highestEv = { stat: "", value: 0 };

    const evYield = data99.ev_yield;
    evYield.forEach(([stat, value]) => {
      if (value > highestEv.value) {
        highestEv = { stat, value };
      }
    });
if(highestEv.stat=='special-attack'){
highestEv.stat = 'special_attack'
}
if(highestEv.stat=='special-defense'){
highestEv.stat = 'special_defense'
}
const t2 = calculateTotal(p.evs)
console.log(l2)
if((p.evs[highestEv.stat]+highestEv.value) < 252 && (t2+highestEv.value) < 510 && clevel*1!=100){
p.evs[highestEv.stat] = Math.min((highestEv.value+p.evs[highestEv.stat]),252)
await saveUserData(ctx.from.id,data)
}
const messageData = await loadMessageData();
if(messageData[ctx.from.id]) {
delete messageData[ctx.from.id];
}
messageData.battle = messageData.battle.filter((chats)=> chats != ctx.from.id)
await saveMessageData(messageData) 
ctx.editMessageText('*'+c(battleData.name)+'* Has Been Fainted\n+'+ai+' 💷',{parse_mode:'markdown'})
return
}
if(battleData.chp < 1){
let av2 = []
for(const p in battleData.team){
if(battleData.team[p] > 0){
av2.push(p)
}
}
if(av2.length > 0){
const av = [];
for (const p in battleData.team) {
  const al = data.pokes.filter((poke) => poke.pass == p)[0];
  if (al) {
    av.push({ name: p, displayText: '' + c(al.name) + ' (' + battleData.team[p] + ' HP)' });
  }
}

const buttons = av.map((poke) => ({ text: poke.displayText, callback_data: 'snd_' + poke.name + '_' + bword + '' }));
while (buttons.length < 6) {
  buttons.push({ text: 'empty', callback_data: 'empty' });
}

const rows = [];
for (let i = 0; i < buttons.length; i += 2) {
  rows.push(buttons.slice(i, i + 2));
}
const base2 = pokestats[p.name]
const stats = await Stats(base2,p.ivs,p.evs,c(p.nature),clevel)
const key = [{text:'⬅️ Back',callback_data:'btl_'+bword+''}]
rows.push(key)
const op = pokes[battleData.name]
const uname = he.encode(ctx.from.first_name)
let msg = '\n\n<b>wild</b> '+c(battleData.name)+' ['+c(op.types.join(' / '))+']'
msg += '\n<b>Level :</b> '+battleData.level+' | <b>HP :</b> '+battleData.ochp+'/'+battleData.ohp+''
msg += '\n<code>'+Bar(battleData.ohp,battleData.ochp)+'</code>'
msg += '\n\n<b>Turn :</b> <code>'+uname+'</code>'
const p2 = pokes[p.name]
msg += '\n<b>'+c(p.name)+'</b> ['+c(p2.types.join(' / '))+']'
msg += '\n<b>Level :</b> '+clevel+' | <b>HP :</b> '+battleData.chp+'/'+stats.hp+''
msg += '\n<code>'+Bar(stats.hp,battleData.chp)+'</code>'
msg += '\n\n<b>Moves :</b>'
const moves = []
for(const move2 of p.moves){
const move = dmoves[move2]
msg += '\n<b>'+c(move.name)+'</b>['+c(move.type)+' '+emojis[move.type]+']\n<b>Power:</b> '+move.power+'<b>, Accuracy:</b> '+move.accuracy+' ('+c(move.category.charAt(0))+')'
moves.push(''+move2+'')
}
msg += '\n\n<i>Choose Which Poke Send For Battle:</i>'
ctx.editMessageText(msg,{parse_mode:'HTML',reply_markup:{inline_keyboard:rows}})
return
}else{
const messageData = await loadMessageData();
if(messageData[ctx.from.id]) {
messageData.battle = messageData.battle.filter((chats)=> chats!== ctx.from.id)
delete messageData[ctx.from.id];
await saveMessageData(messageData) 
}
ctx.editMessageText('Your *Full Team* Has Been Fainted.',{parse_mode:'markdown'})
return
}
}

const op = pokes[battleData.name]
let msg = '➩ <i>'+c(battleData.name)+' Used '+c(move2.name)+' And Dealt '+c(p.name)+'</i> <code>'+damage2+'</code> <i>HP & '+c(p.name)+' Used '+c(move1.name)+' And Dealt '+c(battleData.name)+'</i> <code>'+damage+'</code> <i>HP.</i>'
if(eff1 == 0){
msg += '\n<b>✶ It Have No Effect</b>'
}else if(eff1 == 0.5){
msg += '\n<b>✶ It Have Low Effect</b>'
}else if(eff1 == 2){
msg += '\n<b>✶ It\' Very Effective</b>'
}
msg += '\n\n<b>wild</b> '+c(battleData.name)+' ['+c(op.types.join(' / '))+']'
msg += '\n<b>Level :</b> '+battleData.level+' | <b>HP :</b> '+battleData.ochp+'/'+battleData.ohp+''
msg += '\n<code>'+Bar(battleData.ohp,battleData.ochp)+'</code>'
msg += '\n\n<b>Turn :</b> <code>'+uname+'</code>'
const p2 = pokes[p.name]
msg += '\n<b>'+c(p.name)+'</b> ['+c(p2.types.join(' / '))+']'
msg += '\n<b>Level :</b> '+clevel+' | <b>HP :</b> '+battleData.chp+'/'+stats.hp+''
msg += '\n<code>'+Bar(stats.hp,battleData.chp)+'</code>'
msg += '\n\n<b>Moves :</b>'
const moves = []
for(const move2 of p.moves){
let move = dmoves[move2]
msg += '\n• <b>'+c(move.name)+'</b> ['+c(move.type)+' '+emojis[move.type]+']\n<b>Power:</b> '+move.power+'<b>, Accuracy:</b> '+move.accuracy+' ('+c(move.category.charAt(0))+')'
moves.push(''+move2+'')
}
msg += '\n\n<i>Choose Your Next Move:</i>'
const buttons = moves.map((word) => ({ text: c(dmoves[word].name), callback_data: 'atk_'+word+'_'+bword+'' }));
while(buttons.length < 4){
buttons.push({text:'  ',callback_data:'empty'})
}
  const rows = [];
  for (let i = 0; i < buttons.length; i += 2) {
    rows.push(buttons.slice(i, i + 2));
  }
const key2 = [{text:'Bag',callback_data:'bag_'+bword+''},{text:'Escape',callback_data:'run_'+bword+''},{text:'Pokemon',callback_data:'pokemon_'+bword+''}]
const isstone = [...new Set(data.inv.stones)].filter(stone => stones[stone]?.pokemon === p.name)
rows.push(key2)
  const keyboard = {
    inline_keyboard: rows,key2
  };

ctx.editMessageText('_'+battleData.name+' Is Attacking...._',{parse_mode:'markdown'})
setTimeout(()=> {
ctx.editMessageText(msg,{parse_mode:'HTML',reply_markup:keyboard})
},700)
const messageData = await loadMessageData();
    messageData[ctx.chat.id] = { mid: ctx.callbackQuery.message.message_id, timestamp: Date.now(),id:ctx.from.id };
    await saveMessageData(messageData);
})
bot.action(/bag_/,async ctx => {
if (battlec[ctx.chat.id] && Date.now() - battlec[ctx.chat.id] < 1600) {

  ctx.answerCbQuery('Try Again');
  return;
}
battlec[ctx.chat.id] = Date.now();
const bword = ctx.callbackQuery.data.split('_')[1]
let battleData = {};
    try {
      battleData = JSON.parse(fs.readFileSync('./battle/'+bword+'.json', 'utf8'));
    } catch (error) {
      battleData = {};
    }
const data = await getUserData(ctx.from.id)
const p = data.pokes.filter((poke)=>poke.pass==battleData.c)[0]
const clevel = plevel(p.name,p.exp)
const base2 = pokestats[p.name]
const stats = await Stats(base2,p.ivs,p.evs,c(p.nature),clevel)
const key = [[{text:'Balls',callback_data:'ballpks_'+bword+''}],
//{text:'Potions',callback_data:'potion_'+bword+''}],
[{text:'⬅️ Back',callback_data:'btl_'+bword+''}]]
const op = pokes[battleData.name]
const uname = he.encode(ctx.from.first_name)
let msg = '\n\n<b>wild</b> '+c(battleData.name)+' ['+c(op.types.join(' / '))+']'
msg += '\n<b>Level :</b> '+battleData.level+' | <b>HP :</b> '+battleData.ochp+'/'+battleData.ohp+''
msg += '\n<code>'+Bar(battleData.ohp,battleData.ochp)+'</code>'
msg += '\n\n<b>Turn :</b> <code>'+uname+'</code>'
const p2 = pokes[p.name]
msg += '\n<b>'+c(p.name)+'</b> ['+c(p2.types.join(' / '))+']'
msg += '\n<b>Level :</b> '+clevel+' | <b>HP :</b> '+battleData.chp+'/'+stats.hp+''
msg += '\n<code>'+Bar(stats.hp,battleData.chp)+'</code>'
msg += '\n\n<b>Moves :</b>'
const moves = []
for(const move2 of p.moves){
let move = dmoves[move2]
msg += '\n• <b>'+c(move.name)+'</b> ['+c(move.type)+' '+emojis[move.type]+']\n<b>Power:</b> '+move.power+'<b>, Accuracy:</b> '+move.accuracy+' ('+c(move.category.charAt(0))+')'
moves.push(''+move2+'')
}
msg += '\n\n<i>Choose Option In Your Bag:</i>'
ctx.editMessageText(msg,{parse_mode:'HTML',reply_markup:{inline_keyboard:key}})
})
bot.action(/ballpks_/,async ctx => {
if (battlec[ctx.chat.id] && Date.now() - battlec[ctx.chat.id] < 1600) {

  ctx.answerCbQuery('Try Again');
  return;
}
battlec[ctx.chat.id] = Date.now();
const bword = ctx.callbackQuery.data.split('_')[1]
let battleData = {};
    try {
      battleData = JSON.parse(fs.readFileSync('./battle/'+bword+'.json', 'utf8'));
    } catch (error) {
      battleData = {};
    }
const data = await getUserData(ctx.from.id)
const p = data.pokes.filter((poke)=>poke.pass==battleData.c)[0]
const clevel = plevel(p.name,p.exp)
const balls = []
for(const ball in data.balls){
if(data.balls[ball] > 0){
balls.push(ball)
}
}
const base2 = pokestats[p.name]
const stats = await Stats(base2,p.ivs,p.evs,c(p.nature),clevel)
const buttons = balls.map((word) => ({ text: c(word), callback_data: 'ball_'+word+'_'+bword+'' }));
  const rows = [];
  for (let i = 0; i < buttons.length; i += 4) {
    rows.push(buttons.slice(i, i + 4));
}
const key = [{text:'⬅️ Back',callback_data:'btl_'+bword+''}]
rows.push(key)
const op = pokes[battleData.name]
const uname = he.encode(ctx.from.first_name)
let msg = '\n\n<b>wild</b> '+c(battleData.name)+' ['+c(op.types.join(' / '))+']'
msg += '\n<b>Level :</b> '+battleData.level+' | <b>HP :</b> '+battleData.ochp+'/'+battleData.ohp+''
msg += '\n<code>'+Bar(battleData.ohp,battleData.ochp)+'</code>'
msg += '\n\n<b>Turn :</b> <code>'+uname+'</code>'
const p2 = pokes[p.name]
msg += '\n<b>'+c(p.name)+'</b> ['+c(p2.types.join(' / '))+']'
msg += '\n<b>Level :</b> '+clevel+' | <b>HP :</b> '+battleData.chp+'/'+stats.hp+''
msg += '\n<code>'+Bar(stats.hp,battleData.chp)+'</code>'
msg += '\n\n<b>Moves :</b>'
const moves = []
for(const move2 of p.moves){
let move = dmoves[move2]
msg += '\n• <b>'+c(move.name)+'</b> ['+c(move.type)+' '+emojis[move.type]+']\n<b>Power:</b> '+move.power+'<b>, Accuracy:</b> '+move.accuracy+' ('+c(move.category.charAt(0))+')'
moves.push(''+move2+'')
}
msg += '\n\n<i>Choose Which Ball To Use:</i>'
ctx.editMessageText(msg,{parse_mode:'HTML',reply_markup:{inline_keyboard:rows}})
})
bot.action(/ball_/,async ctx => {
if (battlec[ctx.chat.id] && Date.now() - battlec[ctx.chat.id] < 1600) {

  ctx.answerCbQuery('Try Again');
  return;
}
battlec[ctx.chat.id] = Date.now();
const ball = ctx.callbackQuery.data.split('_')[1]
const bword = ctx.callbackQuery.data.split('_')[2]
ctx.editMessageText('You Thrown A '+c(ball)+' Ball')
const data = await getUserData(ctx.from.id)
data.balls[ball] -= 1
await saveUserData(ctx.from.id,data)
await sleep(600)
let battleData = {};
    try {
      battleData = JSON.parse(fs.readFileSync('./battle/'+bword+'.json', 'utf8'));
    } catch (error) {
      battleData = {};
    }
const p = data.pokes.filter((poke)=>poke.pass==battleData.c)[0]
const uname = he.encode(ctx.from.first_name)
const clevel = plevel(p.name,p.exp)
const op = pokes[battleData.name]
const base2 = pokestats[p.name]
const stats = await Stats(base2,p.ivs,p.evs,c(p.nature),clevel)
let msg = '<i>Your <b>'+c(ball)+'</b> Failed.</i>'
msg += '\n\n<b>wild</b> '+c(battleData.name)+' ['+c(op.types.join(' / '))+']'
msg += '\n<b>Level :</b> '+battleData.level+' | <b>HP :</b> '+battleData.ochp+'/'+battleData.ohp+''
msg += '\n<code>'+Bar(battleData.ohp,battleData.ochp)+'</code>'
msg += '\n\n<b>Turn :</b> <code>'+uname+'</code>'
const p2 = pokes[p.name]
msg += '\n<b>'+c(p.name)+'</b> ['+c(p2.types.join(' / '))+']'
msg += '\n<b>Level :</b> '+clevel+' | <b>HP :</b> '+battleData.chp+'/'+stats.hp+''
msg += '\n<code>'+Bar(stats.hp,battleData.chp)+'</code>'
msg += '\n\n<b>Moves :</b>'
const moves = []
for(const move2 of p.moves){
let move = dmoves[move2]
msg += '\n• <b>'+c(move.name)+'</b> ['+c(move.type)+' '+emojis[move.type]+']\n<b>Power:</b> '+move.power+'<b>, Accuracy:</b> '+move.accuracy+' ('+c(move.category.charAt(0))+')'
moves.push(''+move2+'')
}
msg += '\n\n<i>Choose Your Next Move:</i>'
const buttons = moves.map((word) => ({ text: c(dmoves[word].name), callback_data: 'atk_'+word+'_'+bword+'' }));
while(buttons.length < 4){
buttons.push({text:'  ',callback_data:'empty'})
}
  const rows = [];
  for (let i = 0; i < buttons.length; i += 2) {
    rows.push(buttons.slice(i, i + 2));
  }
const key2 = [{text:'Bag',callback_data:'bag_'+bword+''},{text:'Escape',callback_data:'run_'+bword+''},{text:'Pokemon',callback_data:'pokemon_'+bword+''}]
const isstone = [...new Set(data.inv.stones)].filter(stone => stones[stone]?.pokemon === p.name)
rows.push(key2)
  const keyboard = {
    inline_keyboard: rows,key2
  };
const bonusBall = ballsdata[ball];
const catchRate = catch_rates[battleData.name]
  const a = Math.floor(((3 * battleData.ohp - 2 * battleData.ochp) * catchRate * bonusBall) / (3 * battleData.ohp))

  for (let i = 0; i < 3; i++) {
    const shakeProbability = Math.floor((65536 / Math.pow((255 / a), 0.25)));
    if (Math.random() * 65536 > shakeProbability) {
if(Math.random()< 0.4){
ctx.editMessageText('Your *'+c(ball)+'* Failed And wild *'+c(battleData.name)+'* Has fled.',{parse_mode:'markdown'})
const messageData = await loadMessageData();
if(messageData[ctx.from.id]) {
messageData.battle = messageData.battle.filter((chats)=> chats!== ctx.from.id)
delete messageData[ctx.from.id];
await saveMessageData(messageData)
}
return
}
const messageData = await loadMessageData();
    messageData[ctx.chat.id] = { mid: ctx.callbackQuery.message.message_id, timestamp: Date.now(),id:ctx.from.id };
    await saveMessageData(messageData);
if(ball=='safari'){
if(data.balls.safari && data.balls.safari > 0){
ctx.editMessageText('<i>Your Safari Ball Failed.</i>\n\n<b>wild</b> '+c(battleData.name)+' ['+c(op.types.join(' / '))+'] - <b>Level :</b> '+battleData.level+'\n\n<b>Safari Balls:</b> '+data.balls.safari+'',{
parse_mode:'HTML',
reply_markup:{
inline_keyboard:[[{text:'Use Safari Ball',callback_data:'ball_safari_'+bword+''},
{text:'Escape',callback_data:'run_'+bword+''}]]}})
return
}else{
ctx.editMessageText('*You are out of safari balls*',{parse_mode:'markdown'})
const messageData = await loadMessageData();
if(messageData[ctx.from.id]) {
messageData.battle = messageData.battle.filter((chats)=> chats!== ctx.from.id)
delete messageData[ctx.from.id];
await saveMessageData(messageData)
}
return
}
return
}
      ctx.editMessageText(msg,{parse_mode:'HTML',reply_markup:keyboard})
await sleep(800)
      return;
    }
if(i==0){
var a2 = '★'
}else if(i==1){
var a2 = '★ ★'
}else if(i==2){
var a2 = '★ ★ ★'
}
ctx.editMessageText(a2)
await sleep(800)
  }
const g = growth_rates[battleData.name]
const exp = chart[g.growth_rate][String(battleData.level)]
const de = pokes[battleData.name]
const ms = []
for(const m of battleData.omoves){
ms.push(m.id)
}
const pass2 = word(8)
data.pokes.push({
name:battleData.name,
nature:battleData.nat,
ivs:battleData.ivs,
evs:battleData.evs,
moves:ms,
exp:exp,
id:de.pokedex_number,
pass:pass2,
symbol:battleData.symbol
})
if(!data.pokecaught){
data.pokecaught = []
}
if(!data.pokecaught.includes(battleData.name)){
data.pokecaught.push(battleData.name)
}
await saveUserData(ctx.from.id,data)
const messageData = await loadMessageData();
if(messageData[ctx.from.id]) {
messageData.battle = messageData.battle.filter((chats)=> chats !== ctx.from.id)
delete messageData[ctx.from.id];
await saveMessageData(messageData) 
}
bot.telegram.sendMessage(5432006093,'#caught\n\n<b>'+he.encode(ctx.from.first_name)+'</b> (<code>'+ctx.from.id+'</code>) caught <code>'+c(battleData.name)+'</code>',{parse_mode:'HTML'})
ctx.editMessageText('Successfully Caught *'+c(battleData.name)+'*',{parse_mode:'markdown',reply_markup:{inline_keyboard:[[{text:'Check Stats',callback_data:'stats_'+pass2+'_'+ctx.from.id+'_0'}]]}})
})
bot.action(/btl_/,async ctx => {
if (battlec[ctx.chat.id] && Date.now() - battlec[ctx.chat.id] < 1600) {

  ctx.answerCbQuery('Try Again');
  return;
}
battlec[ctx.chat.id] = Date.now();
const bword = ctx.callbackQuery.data.split('_')[1]
let battleData = {};
    try {
      battleData = JSON.parse(fs.readFileSync('./battle/'+bword+'.json', 'utf8'));
    } catch (error) {
      battleData = {};
    }
const data = await getUserData(ctx.from.id)
const p = data.pokes.filter((poke)=>poke.pass==battleData.c)[0]
const uname = he.encode(ctx.from.first_name)
const clevel = plevel(p.name,p.exp)
const op = pokes[battleData.name]
const base2 = pokestats[p.name]
const stats = await Stats(base2,p.ivs,p.evs,c(p.nature),clevel)
let msg = '\n\n<b>wild</b> '+c(battleData.name)+' ['+c(op.types.join(' / '))+']'
msg += '\n<b>Level :</b> '+battleData.level+' | <b>HP :</b> '+battleData.ochp+'/'+battleData.ohp+''
msg += '\n<code>'+Bar(battleData.ohp,battleData.ochp)+'</code>'
msg += '\n\n<b>Turn :</b> <code>'+uname+'</code>'
const p2 = pokes[p.name]
msg += '\n<b>'+c(p.name)+'</b> ['+c(p2.types.join(' / '))+']'
msg += '\n<b>Level :</b> '+clevel+' | <b>HP :</b> '+battleData.chp+'/'+stats.hp+''
msg += '\n<code>'+Bar(stats.hp,battleData.chp)+'</code>'
msg += '\n\n<b>Moves :</b>'
const moves = []
for(const move2 of p.moves){
let move = dmoves[move2]
msg += '\n• <b>'+c(move.name)+'</b> ['+c(move.type)+' '+emojis[move.type]+']\n<b>Power:</b> '+move.power+'<b>, Accuracy:</b> '+move.accuracy+' ('+c(move.category.charAt(0))+')'
moves.push(''+move2+'')
}
msg += '\n\n<i>Choose Your Next Move:</i>'
const buttons = moves.map((word) => ({ text: c(dmoves[word].name), callback_data: 'atk_'+word+'_'+bword+'' }));
while(buttons.length < 4){
buttons.push({text:'  ',callback_data:'empty'})
}
  const rows = [];
  for (let i = 0; i < buttons.length; i += 2) {
    rows.push(buttons.slice(i, i + 2));
  }
const key2 = [{text:'Bag',callback_data:'bag_'+bword+''},{text:'Escape',callback_data:'run_'+bword+''},{text:'Pokemon',callback_data:'pokemon_'+bword+''}]
rows.push(key2)
  const keyboard = {
    inline_keyboard: rows,key2
  };
ctx.editMessageText(msg,{parse_mode:'HTML',reply_markup:keyboard})
})
bot.action(/pokemon_/,async ctx => {
if (battlec[ctx.chat.id] && Date.now() - battlec[ctx.chat.id] < 1600) {

  ctx.answerCbQuery('Try Again');
  return;
}
battlec[ctx.chat.id] = Date.now();
const bword = ctx.callbackQuery.data.split('_')[1]
let battleData = {};
    try {
      battleData = JSON.parse(fs.readFileSync('./battle/'+bword+'.json', 'utf8'));
    } catch (error) {
      battleData = {};
    }
const data = await getUserData(ctx.from.id)
const p = data.pokes.filter((poke)=>poke.pass==battleData.c)[0]
const clevel = plevel(p.name,p.exp)
const av = [];
for (const p in battleData.team) {
  const al = data.pokes.filter((poke) => poke.pass == p)[0];
  if (al) {
    av.push({ name: p, displayText: '' + c(al.name) + ' (' + battleData.team[p] + ' HP)' });
  }
}

const buttons = av.map((poke) => ({ text: poke.displayText, callback_data: 'snd_' + poke.name + '_' + bword + '' }));
while (buttons.length < 6) {
  buttons.push({ text: 'empty', callback_data: 'empty' });
}

const rows = [];
for (let i = 0; i < buttons.length; i += 2) {
  rows.push(buttons.slice(i, i + 2));
}
const base2 = pokestats[p.name]
const stats = await Stats(base2,p.ivs,p.evs,c(p.nature),clevel)
const key = [{text:'⬅️ Back',callback_data:'btl_'+bword+''}]
rows.push(key)
const op = pokes[battleData.name]
const uname = he.encode(ctx.from.first_name)
let msg = '\n\n<b>wild</b> '+c(battleData.name)+' ['+c(op.types.join(' / '))+']'
msg += '\n<b>Level :</b> '+battleData.level+' | <b>HP :</b> '+battleData.ochp+'/'+battleData.ohp+''
msg += '\n<code>'+Bar(battleData.ohp,battleData.ochp)+'</code>'
msg += '\n\n<b>Turn :</b> <code>'+uname+'</code>'
const p2 = pokes[p.name]
msg += '\n<b>'+c(p.name)+'</b> ['+c(p2.types.join(' / '))+']'
msg += '\n<b>Level :</b> '+clevel+' | <b>HP :</b> '+battleData.chp+'/'+stats.hp+''
msg += '\n<code>'+Bar(stats.hp,battleData.chp)+'</code>'
msg += '\n\n<b>Moves :</b>'
const moves = []
for(const move2 of p.moves){
let move = dmoves[move2]
msg += '\n<b>'+c(move.name)+'</b>['+c(move.type)+' '+emojis[move.type]+']\n<b>Power:</b> '+move.power+'<b>, Accuracy:</b> '+move.accuracy+' ('+c(move.category.charAt(0))+')'
moves.push(''+move2+'')
}
msg += '\n\n<i>Choose Which Poke Send For Battle:</i>'
ctx.editMessageText(msg,{parse_mode:'HTML',reply_markup:{inline_keyboard:rows}})
})
bot.action(/snd_/,async ctx => {
if (battlec[ctx.chat.id] && Date.now() - battlec[ctx.chat.id] < 1600) {

  ctx.answerCbQuery('Try Again');
  return;
}
battlec[ctx.chat.id] = Date.now();
const bword = ctx.callbackQuery.data.split('_')[2]
let battleData = {};
    try {
      battleData = JSON.parse(fs.readFileSync('./battle/'+bword+'.json', 'utf8'));
    } catch (error) {
      battleData = {};
    }
const data = await getUserData(ctx.from.id)
const ps = ctx.callbackQuery.data.split('_')[1]
if(battleData.team[ps] < 1){
ctx.answerCbQuery('This Poke Has Died')
return
}
const p = data.pokes.filter((poke)=>poke.pass==ps)[0]
if(!p){
ctx.answerCbQuery('Poke Not Found In Database')
return
}

battleData.c = ps
battleData.chp = battleData.team[ps]
await fs.writeFileSync('./battle/' +bword+ '.json', JSON.stringify(battleData, null, 2));
const uname = he.encode(ctx.from.first_name)
const clevel = plevel(p.name,p.exp)
const op = pokes[battleData.name]
const base2 = pokestats[p.name]
const stats = await Stats(base2,p.ivs,p.evs,c(p.nature),clevel)
let msg = '<i> Sent '+p.name+' For Battle</i>'
msg += '\n\n<b>wild</b> '+c(battleData.name)+' ['+c(op.types.join(' / '))+']'
msg += '\n<b>Level :</b> '+battleData.level+' | <b>HP :</b> '+battleData.ochp+'/'+battleData.ohp+''
msg += '\n<code>'+Bar(battleData.ohp,battleData.ochp)+'</code>'
msg += '\n\n<b>Turn :</b> <code>'+uname+'</code>'
const p2 = pokes[p.name]
msg += '\n<b>'+c(p.name)+'</b> ['+c(p2.types.join(' / '))+']'
msg += '\n<b>Level :</b> '+clevel+' | <b>HP :</b> '+battleData.chp+'/'+stats.hp+''
msg += '\n<code>'+Bar(stats.hp,battleData.chp)+'</code>'
msg += '\n\n<b>Moves :</b>'
const moves = []
for(const move2 of p.moves){
let move = dmoves[move2]
msg += '\n<b>'+c(move.name)+'</b>['+c(move.type)+' '+emojis[move.type]+']\n<b>Power:</b> '+move.power+'<b>, Accuracy:</b> '+move.accuracy+' ('+c(move.category.charAt(0))+')'
moves.push(''+move2+'')
}
msg += '\n\n<i>Choose Your Next Move:</i>'
const buttons = moves.map((word) => ({ text: c(dmoves[word].name), callback_data: 'atk_'+word+'_'+bword+'' }));
while(buttons.length < 4){
buttons.push({text:'  ',callback_data:'empty'})
}
  const rows = [];
  for (let i = 0; i < buttons.length; i += 2) {
    rows.push(buttons.slice(i, i + 2));
  }
const key2 = [{text:'Bag',callback_data:'bag_'+bword+''},{text:'Escape',callback_data:'run_'+bword+''},{text:'Pokemon',callback_data:'pokemon_'+bword+''}]
rows.push(key2)
  const keyboard = {
    inline_keyboard: rows,key2
  };
ctx.editMessageText(msg,{parse_mode:'HTML',reply_markup:keyboard})
})
bot.action(/ev_/,async ctx => {
const name = ctx.callbackQuery.data.split('_')[1]
const data = pokes[name]
let highestEV = { stat: "", value: 0 };

    const evYield = data.ev_yield;
    evYield.forEach(([stat, value]) => {
      if (value > highestEV.value) {
        highestEV = { stat, value };
      }
    });
ctx.answerCbQuery('For Defeating '+c(name)+' You Poke Will Gain :\n\n'+highestEV.value+' '+highestEV.stat+' EV',{show_alert:true})
})
bot.command('travel',check,check2,async (ctx,next) => {
const data = await getUserData(ctx.from.id)
if(!data.inv){
ctx.replyWithMarkdown('*Start your journey now*',{reply_to_message_id:ctx.message.message_id,
reply_markup:{inline_keyboard:[[
{text:'Start My Journey',url:'t.me/PokePlayBot?start=start',}]]}})
return
}
if(data.balls.safari && data.balls.safari > 0){
ctx.replyWithMarkdown('You Are In *'+c(data.extra.saf)+' Safari Zone*',{reply_to_message_id:ctx.message.message_id})
return
}
const matchingLevels = Object.keys(trainerlevel).filter(level => data.inv.exp >= trainerlevel[level]);
const userLevel = matchingLevels.length > 0 ? parseInt(matchingLevels[matchingLevels.length - 1]) : undefined
const key = [
  [{ text: userLevel >= 75 ? 'National' : '  ',  callback_data: userLevel >= 75 ? 'travel_national_'+ctx.from.id+'' : 'locked' },],
  [
    { text: 'Kanto', callback_data: 'travel_kanto2_'+ctx.from.id+'' },
    { text: userLevel >= 5 ? 'Johto' : '  ', callback_data: userLevel >= 5 ? 'travel_johto_'+ctx.from.id+'' : 'locked' },
    { text: userLevel >= 10 ? 'Hoenn' : '  ', callback_data: userLevel >= 10 ? 'travel_hoenn_'+ctx.from.id+'' : 'locked' }
  ],
  [
    { text: userLevel >= 15 ? 'Sinnoh' : '  ',  callback_data: userLevel >= 15 ? 'travel_sinnoh_'+ctx.from.id+'' : 'locked' },
    { text: userLevel >= 40 ? 'Hisui' : '  ', callback_data: userLevel >= 40 ? 'travel_hisui_'+ctx.from.id+'' : 'locked' },
    { text: userLevel >= 20 ? 'Unova' : '  ', callback_data: userLevel >= 20 ? 'travel_unova_'+ctx.from.id+'' : 'locked' },
    { text: userLevel >= 25 ? 'Kalos' : '  ',  callback_data: userLevel >= 25 ? 'travel_kalos_'+ctx.from.id+'' : 'locked' }
  ],
  [
    { text: userLevel >= 30 ? 'Alola' : '  ', callback_data: userLevel >= 30 ? 'travel_alola2_'+ctx.from.id+'' : 'locked' },
    { text: userLevel >= 50 ? 'Galar' : '  ',  callback_data: userLevel >= 50 ? 'travel_galar2_'+ctx.from.id+'' : 'locked' },
    { text: userLevel >= 60 ? 'Paldea' : '  ',  callback_data: userLevel >= 60 ? 'travel_paldea2_'+ctx.from.id+'' : 'locked' }
  ],
  [
    { text: userLevel >= 65 ? 'Conquest Gallery' : '  ', callback_data: userLevel >= 65 ? 'travel_conquest-gallery_'+ctx.from.id+'' : 'locked' }
  ]
];

ctx.replyWithMarkdown('*Which Region You Wanna Travel?*\n\n*Currently :* _'+c(data.inv.region || 'N/A')+'_',{reply_markup:{inline_keyboard:key}})
})
bot.action('locked',async ctx => {
ctx.answerCbQuery();
})
bot.action(/travel_/,check2q,async ctx => {
const region = ctx.callbackQuery.data.split('_')[1]
let place = false
const id = ctx.callbackQuery.data.split('_')[2]
if(ctx.from.id!=id){
ctx.answerCbQuery()
return
}
const data = await getUserData(ctx.from.id)
const matchingLevels = Object.keys(trainerlevel).filter(level => data.inv.exp >= trainerlevel[level]);
const userLevel = matchingLevels.length > 0 ? parseInt(matchingLevels[matchingLevels.length - 1]) : undefined;
if(region=='back'){
place = true
var key = [
  [{ text: userLevel >= 75 ? 'National' : '  ',  callback_data: userLevel >= 75 ? 'travel_national_'+ctx.from.id+'' : 'locked' },],
  [
    { text: 'Kanto', callback_data: 'travel_kanto2_'+ctx.from.id+'' },
    { text: userLevel >= 5 ? 'Johto' : '  ', callback_data: userLevel >= 5 ? 'travel_johto_'+ctx.from.id+'' : 'locked' },
    { text: userLevel >= 10 ? 'Hoenn' : '  ', callback_data: userLevel >= 10 ? 'travel_hoenn_'+ctx.from.id+'' : 'locked' }
  ],
  [
    { text: userLevel >= 15 ? 'Sinnoh' : '  ',  callback_data: userLevel >= 15 ? 'travel_sinnoh_'+ctx.from.id+'' : 'locked' },
    { text: userLevel >= 40 ? 'Hisui' : '  ', callback_data: userLevel >= 40 ? 'travel_hisui_'+ctx.from.id+'' : 'locked' },
    { text: userLevel >= 20 ? 'Unova' : '  ', callback_data: userLevel >= 20 ? 'travel_unova_'+ctx.from.id+'' : 'locked' },
    { text: userLevel >= 25 ? 'Kalos' : '  ',  callback_data: userLevel >= 25 ? 'travel_kalos_'+ctx.from.id+'' : 'locked' }
  ],
  [
    { text: userLevel >= 30 ? 'Alola' : '  ', callback_data: userLevel >= 30 ? 'travel_alola2_'+ctx.from.id+'' : 'locked' },
    { text: userLevel >= 50 ? 'Galar' : '  ',  callback_data: userLevel >= 50 ? 'travel_galar2_'+ctx.from.id+'' : 'locked' },
    { text: userLevel >= 60 ? 'Paldea' : '  ',  callback_data: userLevel >= 60 ? 'travel_paldea2_'+ctx.from.id+'' : 'locked' }
  ],
  [
    { text: userLevel >= 65 ? 'Conquest Gallery' : '  ', callback_data: userLevel >= 65 ? 'travel_conquest-gallery_'+ctx.from.id+'' : 'locked' }
  ]
];
var msg = '*Which Region You Wanna Travel?*'
}else if(region=='kanto2'){
place = true
var key = [
[{text:'Kanto',callback_data:'travel_kanto_'+ctx.from.id+''},{text:'LetsGo-Kanto',callback_data:'travel_letsgo-kanto_'+ctx.from.id+''}],
[{text:'⬅️ Back',callback_data:'travel_back_'+ctx.from.id+''}]
]
var msg = 'Which Place Wanna Go In *Kanto*?'
}else if(region=='kalos'){
place = true
var key = [
[{text:'Central',callback_data:'travel_kalos-central_'+ctx.from.id+''},{text:'Coastal',callback_data:'travel_kalos-coastal_'+ctx.from.id+''},{text:'Mountain',callback_data:'travel_kalos-mountain_'+ctx.from.id+''}],
[{text:'⬅️ Back',callback_data:'travel_back_'+ctx.from.id+''}]
]
var msg = 'Which Place In *Kalos* You Wanna Travel?'
}else if(region=='galar2'){
place = true
var key = [
[{text:'Galar',callback_data:'travel_galar_'+ctx.from.id+''},{text:'Isle Of Armour',callback_data:'travel_isle-of-armor_'+ctx.from.id+''}],
[{text:'Crown Tundra',callback_data:'travel_crown-tundra_'+ctx.from.id+''},{text:'⬅️ Back',callback_data:'travel_back_'+ctx.from.id+''}]
]
var msg = 'Which Place In *Galar* You Wanna Travel?'
}else if(region=='paldea2'){
place = true
var key = [
[{text:'Paldea',callback_data:'travel_paldea_'+ctx.from.id+''},{text:'KitaKami',callback_data:'travel_kitakami_'+ctx.from.id+''},{text:'Blueberry',callback_data:'travel_blueberry_'+ctx.from.id+''}],
[{text:'⬅️ Back',callback_data:'travel_back_'+ctx.from.id+''}]
] 
var msg = 'Which Place In *Paldea* You Wanna Travel?'
}else if(region=='alola2'){
place = true
var key = [
[{text:'Alola',callback_data:'travel_alola_'+ctx.from.id+''},{text:'Melemele',callback_data:'travel_melemele_'+ctx.from.id+''},{text:'Akala',callback_data:'travel_akala_'+ctx.from.id+''}],
[{text:'Ulaula',callback_data:'travel_ulaula_'+ctx.from.id+''},{text:'Poni',callback_data:'travel_poni_'+ctx.from.id+''}],
[{text:'⬅️ Back',callback_data:'travel_back_'+ctx.from.id+''}]
]
var msg = 'Which Place In *Aloka* You Wanna Travel?'
}

if(place){
ctx.editMessageText(msg,{parse_mode:'markdown',reply_markup:{inline_keyboard:key}})
return
}

if(data.balls.safari && data.balls.safari > 0){
ctx.answerCbQuery('You Are In *'+c(data.extra.saf)+' Safari Zone*')
return
}
data.inv.region = ctx.callbackQuery.data.split('_')[1]
await saveUserData(ctx.from.id,data)
ctx.editMessageText('Successfully Arrived To *'+c(ctx.callbackQuery.data.split('_')[1])+'*',{parse_mode:'markdown'})
})
bot.command('open',async ctx => {
if(ctx.chat.type!='private'){
return
}
ctx.replyWithMarkdown('*Opening Keyboard.....*',{reply_markup:{keyboard:[['/hunt','/close']],resize_keyboard:true}})
})
bot.command('close',async ctx => {
ctx.session.key = false
ctx.replyWithMarkdown('*Closing Keyboard...*',{reply_markup:{remove_keyboard:true}})
})
bot.command('myteams',async ctx => {
const userData = await getUserData(ctx.from.id)
if(!userData.inv){
ctx.replyWithMarkdown('*Start your journey now*',{reply_to_message_id:ctx.message.message_id,
reply_markup:{inline_keyboard:[[
{text:'Start My Journey',url:'t.me/PokePlayBot?start=start',}]]}})
return
}
if (!userData.teams) {
        userData.teams = {};
userData.inv.team = "1"
    }
    for (let i = 1; i <= 6; i++) {
        if (!userData.teams[i]) {
            userData.teams[i] = [];
        }
    }

    await saveUserData(ctx.from.id, userData);
const team = userData.inv.team*1 || 1
const teampokes = userData.teams[team];
var matching = [];
let b = 1
    for (const pass of teampokes) {
        const matchings = userData.pokes.find((poke) => poke.pass === pass);
        if (matchings) {
            matching.push(pass);
         b++;
}
}
    const list = matching.join('\n');

    if (!userData.inv || userData.inv.team !== team) {
        var main = '❌';
    } else {
        var main = '✅';
    }
const tea = userData.inv[team] ?userData.inv[team] : team
    let messageText = '❖ *Main Team : '+tea+'*\n\n'
 messageText += await pokelist(matching,ctx,0)
if(ctx.chat.type=='private'){
messageText+='\n\n_Which Team Want To Edit?_'
}else{
messageText+='\n\n_Which Team You Wanna Set As Main?_'
}
if(ctx.message.chat.type=='private'){
var key = [
  [{text:userData.inv["1"] ? userData.inv["1"] : 'Team 1',callback_data:'set_1'},
   {text:userData.inv["2"] ? userData.inv["2"] : 'Team 2',callback_data:'set_2'}],
  [{text:userData.inv["3"] ? userData.inv["3"] : 'Team 3',callback_data:'set_3'},
   {text:userData.inv["4"] ? userData.inv["4"] : 'Team 4',callback_data:'set_4'}],
  [{text:userData.inv["5"] ? userData.inv["5"] : 'Team 5',callback_data:'set_5'},
   {text:userData.inv["6"] ? userData.inv["6"] : 'Team 6',callback_data:'set_6'}]
];
}else{
var key = [
  [{text:userData.inv["1"] ? userData.inv["1"] : 'Team 1',callback_data:'main_1_'+ctx.from.id+''},
   {text:userData.inv["2"] ? userData.inv["2"] : 'Team 2',callback_data:'main_2_'+ctx.from.id+''}],
  [{text:userData.inv["3"] ? userData.inv["3"] : 'Team 3',callback_data:'main_3_'+ctx.from.id+''},
   {text:userData.inv["4"] ? userData.inv["4"] : 'Team 4',callback_data:'main_4_'+ctx.from.id+''}],
  [{text:userData.inv["5"] ? userData.inv["5"] : 'Team 5',callback_data:'main_5_'+ctx.from.id+''},
   {text:userData.inv["6"] ? userData.inv["6"] : 'Team 6',callback_data:'main_6_'+ctx.from.id+''}]
];
}
ctx.replyWithMarkdown(messageText,{reply_markup:{inline_keyboard:key}})
})
bot.action(/set_/, check2q,async (ctx) => {
const userData = await getUserData(ctx.from.id);
    const team = ctx.callbackQuery.data.split('_')[1];

    if (!userData.teams || !userData.teams[team]) {
        ctx.answerCbQuery('Team not found or has no pokes.', { show_alert: true });
        return;
    }

    const pokes = userData.teams[team];
    const matchings = [];
let b = 1
    for (const pass of pokes) {
        const matching = userData.pokes.find((poke) => poke.pass === pass);
        if (matching) {
            matchings.push(pass);
         b++;
}
    }

    const list = matchings.join('\n');

    if (!userData.inv || userData.inv.team !== team) {
        var main = '❌';
    } else {
        var main = '✅';
    }
let messageText = '*Main :* `' + main + '`\n';
messageText += await pokelist(matchings,ctx,0)
messageText += '\n\n_Choose Any Option Below_'
ctx.answerCbQuery('Edit Your Team '+team+'')
ctx.editMessageText(messageText,{parse_mode:'Markdown',reply_markup:{inline_keyboard:[[{text:'Add Poke',callback_data:'add_'+team+''},{text:'Remove Poke',callback_data:'remove_'+team+''}],[{text:'Change Order',callback_data:'change_order_'+team+''},{text:'Randomize',callback_data:'randomize_'+team+''}],[{text:'Reset Team',callback_data:'rest_'+team+''},{text:'Main',callback_data:'main_'+team+''}],[{text:'Rename',callback_data:'rename_'+team+''},{text:'🔙Back',callback_data:'teams'}]]}})
})
bot.action(/rename_/,async ctx => {
const team = ctx.callbackQuery.data.split('_')[1]
ctx.deleteMessage();
const message = await ctx.reply('Tell A New Name For *Team '+team+'*',{parse_mode:'markdown',reply_markup:{force_reply:true}})
const userData = {
      messageId: message.message_id,
      teamn: team // You can set the name to whatever you like
    };
    userState.set(ctx.from.id, userData);
  });
bot.action(/randomize_/,check2q,async ctx => {
const data = await getUserData(ctx.from.id)
const team = ctx.callbackQuery.data.split('_')[1]
const pk5 = []
for(let i = 1; i <=6; i++){
const pk = data.pokes.filter((pk2)=> !pk5.includes(pk2.pass))
if(pk.length > 0){
const ran = pk[Math.floor(Math.random()*pk.length)]
pk5.push(ran.pass)
}
}
if(data.teams[team] == pk5){
return
}
data.teams[team] = pk5
await saveUserData(ctx.from.id, data);
const userData = data
const pokes = userData.teams[team];
    const matchings = [];
let b = 1
    for (const pass of pokes) {
        const matching = userData.pokes.find((poke) => poke.pass === pass);
        if (matching) {
            matchings.push(pass)
         b++;
}
    }

    const list = matchings.join('\n');

    if (!userData.inv || userData.inv.team !== team) {
        var main = '❌';
    } else {
        var main = '✅';
    }
let messageText = '*Main :* `' + main + '`\n';
messageText += await pokelist(matchings,ctx,0)
messageText += '\n\n_Choose Any Option Below_'
ctx.answerCbQuery('Created Random Team')
ctx.editMessageText(messageText,{parse_mode:'Markdown',reply_markup:{inline_keyboard:
[[{text:'Add Poke',callback_data:'add_'+team+''},{text:'Remove Poke',callback_data:'remove_'+team+''}],
[{text:'Change Order',callback_data:'change_order_'+team+''},{text:'Randomize',callback_data:'randomize_'+team+''}],
[{text:'Reset Team',callback_data:'rest_'+team+''},{text:'Main',callback_data:'main_'+team+''}],
[{text:'Rename',callback_data:'rename_'+team+''},{text:'🔙Back',callback_data:'teams'}]]}})
})

bot.action('teams',check2q,async ctx => {
const userData = await getUserData(ctx.from.id);
const team = userData.inv.team*1 || 1
const pokes = userData.teams[team];
    const matchings = [];
let b = 1
    for (const pass of pokes) {
        const matching = userData.pokes.find((poke) => poke.pass === pass);
        if (matching) {
            matchings.push(pass);
         b++;
}
    }
    const list = matchings.join('\n');

    if (!userData.inv || userData.inv.team !== team) {
        var main = '❌';
    } else {                                                                                            
var main = '✅';
    }
const tea = userData.inv[team] ?userData.inv[team] : team
    let messageText = '❖ *Main Team : '+tea+'*\n\n'
 messageText += await pokelist(matchings,ctx,0)

messageText+='\n\n_Which Team Want To Edit?_'

ctx.editMessageText(messageText,{parse_mode:'markdown',reply_markup:{inline_keyboard: [
  [{text:userData.inv["1"] ? userData.inv["1"] : 'Team 1',callback_data:'set_1'},
   {text:userData.inv["2"] ? userData.inv["2"] : 'Team 2',callback_data:'set_2'}],
  [{text:userData.inv["3"] ? userData.inv["3"] : 'Team 3',callback_data:'set_3'},
   {text:userData.inv["4"] ? userData.inv["4"] : 'Team 4',callback_data:'set_4'}],
  [{text:userData.inv["5"] ? userData.inv["5"] : 'Team 5',callback_data:'set_5'},
   {text:userData.inv["6"] ? userData.inv["6"] : 'Team 6',callback_data:'set_6'}]
]}})
})
bot.action(/rest_/,check2q,async ctx => {
let userData = {};
  try {
    userData = await getUserData(ctx.from.id);
    } catch (error) {
 userData = {};
  }
 const team = ctx.callbackQuery.data.split('_')[1]
const count = userData.teams[team].length
if(count<1){
ctx.answerCbQuery('Add Some Pokes First')
return
}
userData.teams[team] = []
await saveUserData(ctx.from.id, userData);;
if (!userData.teams || !userData.teams[team]) {
        ctx.answerCbQuery('Team not found or has no pokes.', { show_alert: true });
        return;
    }

    const pokes = userData.teams[team];
    const matchings = [];
let b = 1
    for (const pass of pokes) {
        const matching = userData.pokes.find((poke) => poke.pass === pass);
        if (matching) {
            matchings.push(pass)
         b++;
}
    }

    const list = matchings.join('\n');

    if (!userData.inv || userData.inv.team !== team) {
        var main = '❌';
    } else {
        var main = '✅';
    }

let messageText = '*Main :* `' + main + '`\n';
messageText += await pokelist(matchings,ctx,0)
messageText += '\n\n_Choose Any Option Below_'
ctx.answerCbQuery('Reseted Team '+team+'')
ctx.editMessageText(messageText,{parse_mode:'Markdown',reply_markup:{inline_keyboard:[[{text:'Add Poke',callback_data:'add_'+team+''},{text:'Remove Poke',callback_data:'remove_'+team+''}],[{text:'Change Order',callback_data:'change_order_'+team+''},{text:'Randomize',callback_data:'randomize_'+team+''}],[{text:'Reset Team',callback_data:'rest_'+team+''},{text:'Main',callback_data:'main_'+team+''}],[{text:'Rename',callback_data:'rename_'+team+''},{text:'🔙Back',callback_data:'teams'}]]}})
})
bot.action(/main_/,check2q,async ctx => {
const userData = await getUserData(ctx.from.id);
 const team = ctx.callbackQuery.data.split('_')[1]
const id = ctx.callbackQuery.data.split('_')[2] || false
if(id && ctx.from.id!=id){
ctx.answerCbQuery()
return
}
const count = userData.teams[team].length
if(userData.inv.team && userData.inv.team==team){
ctx.answerCbQuery('Already Main')
return
}
if(count<1){
ctx.answerCbQuery('Add Some Pokes First')
return
}
userData.inv.team = team
await saveUserData(ctx.from.id, userData);;
if (!userData.teams || !userData.teams[team]) {
        ctx.answerCbQuery('Team not found or has no pokes.', { show_alert: true });
        return;
    }

    const pokes = userData.teams[team];
    const matchings = [];
let b = 1
    for (const pass of pokes) {
        const matching = userData.pokes.find((poke) => poke.pass === pass);
        if (matching) {
            matchings.push(pass)
         b++;
}
    }

    const list = matchings.join('\n');

    if (!userData.inv || userData.inv.team !== team) {
        var main = '❌';
    } else {
        var main = '✅';
    }
const tea = userData.inv[team] ?userData.inv[team] : team
    let messageText = '❖ *Main Team : '+tea+'*\n'
 messageText += await pokelist(matchings,ctx,0)
if(ctx.chat.type=='private'){
messageText+='\n\n_Which Team Want To Edit?_'
}else{
messageText+='\n\n_Which Team You Wanna Set As Main?_'
}
if(ctx.chat.type=='private'){
var key = [
  [{text:userData.inv["1"] ? userData.inv["1"] : 'Team 1',callback_data:'set_1'},
   {text:userData.inv["2"] ? userData.inv["2"] : 'Team 2',callback_data:'set_2'}],
  [{text:userData.inv["3"] ? userData.inv["3"] : 'Team 3',callback_data:'set_3'},
   {text:userData.inv["4"] ? userData.inv["4"] : 'Team 4',callback_data:'set_4'}],
  [{text:userData.inv["5"] ? userData.inv["5"] : 'Team 5',callback_data:'set_5'},
   {text:userData.inv["6"] ? userData.inv["6"] : 'Team 6',callback_data:'set_6'}]
];
}else{
var key = [
  [{text:userData.inv["1"] ? userData.inv["1"] : 'Team 1',callback_data:'main_1_'+ctx.from.id+''},
   {text:userData.inv["2"] ? userData.inv["2"] : 'Team 2',callback_data:'main_2_'+ctx.from.id+''}],
  [{text:userData.inv["3"] ? userData.inv["3"] : 'Team 3',callback_data:'main_3_'+ctx.from.id+''},
   {text:userData.inv["4"] ? userData.inv["4"] : 'Team 4',callback_data:'main_4_'+ctx.from.id+''}],
  [{text:userData.inv["5"] ? userData.inv["5"] : 'Team 5',callback_data:'main_5_'+ctx.from.id+''},
   {text:userData.inv["6"] ? userData.inv["6"] : 'Team 6',callback_data:'main_6_'+ctx.from.id+''}]
];
}
ctx.editMessageText(messageText,{reply_markup:{inline_keyboard:key},parse_mode:'markdown'})
})
bot.action(/add_/, check2q,async ctx => {
const userData = await getUserData(ctx.from.id);
  const team = ctx.callbackQuery.data.split('_')[1];
let pokes = userData.pokes;
if(userData.inv.sort){
pokes = await sort(userData.pokes,userData.inv.sort)
}
  const buttonsPerRow = 5;
  let page = parseInt(ctx.callbackQuery.data.split('_')[2]) || 1
  const itemsPerPage = 20;
const totalPages = Math.ceil(userData.pokes.length / itemsPerPage);
if(page<1 || page > totalPages){
return
}
  const startIndex = (page - 1) * itemsPerPage;
  const endIndex = Math.min(startIndex + itemsPerPage, pokes.length);
  const inlineKeyboard = [];
  let row = [];

for (let i = startIndex; i < endIndex; i++) {
  const sortedIndex = userData.pokes.indexOf(pokes[i]);
  row.push({
    text: `${sortedIndex + 1}`,
    callback_data: `select_${userData.pokes[i].pass}_${team}`,
  });

  if ((sortedIndex + 1) % buttonsPerRow === 0 || sortedIndex === endIndex - 1) {
    inlineKeyboard.push(row);
    row = [];
  }
}
if(page>1 || endIndex<pokes.length){
const row2 = []
row2.push({text:'<',callback_data:'add_'+team+'_'+(page-1)+''})
row2.push({text:'>',callback_data:'add_'+team+'_'+(page+1)+''})
inlineKeyboard.push(row2)
}
if(totalPages > 10){
const row = []
row.push({text:'(-5) <<',callback_data:'add_'+team+'_'+(page-5)+'_'+ctx.from.id+''})
row.push({text:'>> (+5)',callback_data:'add_'+team+'_'+(page+5)+'_'+ctx.from.id+''})
inlineKeyboard.push(row)
}
if(totalPages > 40){
const row = []
row.push({text:'(-10) <<<',callback_data:'add_'+team+'_'+(page-10)+'_'+ctx.from.id+''})
row.push({text:'>>> (+10)',callback_data:'add_'+team+'_'+(page+10)+'_'+ctx.from.id+''})
inlineKeyboard.push(row)
}
if(totalPages > 100){
const row = []
row.push({text:'(-25) <<<<',callback_data:'add_'+team+'_'+(page-25)+'_'+ctx.from.id+''})
row.push({text:'>>>> (+25)',callback_data:'add_'+team+'_'+(page+25)+'_'+ctx.from.id+''})
inlineKeyboard.push(row)
}


inlineKeyboard.push([{text:'⬅️ Back',callback_data:'set_'+team+''}])
const pk = pokes.slice(startIndex,endIndex)
  let messageText = `*List Of Your Pokes (Page ${page}):*\n`;
messageText += await pokelist(pk.map(item => item.pass),ctx,startIndex)
  messageText += '\n\n_Select Poke To Add In Team ' + team + '_';

  const keyboard = {
    inline_keyboard: inlineKeyboard,
  };
  ctx.editMessageText(messageText, { parse_mode: 'markdown', reply_markup: keyboard });
});
bot.action(/select_/,check2q, async (ctx) => {
    const pass = ctx.callbackQuery.data.split('_')[1];
    const team = ctx.callbackQuery.data.split('_')[2];

    const userId = ctx.from.id;
    const userData = await getUserData(ctx.from.id);

    if (!userData.pokes) {
        userData.pokes = [];
    }

    if (!userData.teams) {
        userData.teams = {};
    }

    if (!userData.teams[team]) {
        userData.teams[team] = [];
    }

    let io = [];
    for (const t of userData.teams[team]) {
        for (const poke of userData.pokes) {
            if (poke.pass == t) {
                io.push(poke);
            }
        }
    }

    if (io.length >= 6) {
        ctx.answerCbQuery(userData.inv[team] ? userData.inv[team] : 'Team ' + team + ' already has 6 pokes.', { show_alert: true });
        return;
    }

    const pok = userData.pokes.find((poke) => poke.pass === pass);

    if (!pok) {
        ctx.answerCbQuery('Poke not found.', { show_alert: true });
        return;
    }

    if (userData.teams[team].includes(pass)) {
        ctx.answerCbQuery('Poke is already in Team ' + team, { show_alert: true });
return
}
userData.teams[team].push(pass);
            await saveUserData(userId, userData);
if (!userData.teams || !userData.teams[team]) {
        ctx.answerCbQuery('Team not found or has no pokes.', { show_alert: true });
        return;
    }

    const pokes = userData.teams[team];
    const matchings = [];
let b = 1
    for (const pass of pokes) {
        const matching = userData.pokes.find((poke) => poke.pass === pass);
        if (matching) {
            matchings.push(pass)
         b++;
}
    }

    const list = matchings.join('\n');

    if (!userData.inv || userData.inv.team !== team) {
        var main = '❌';
    } else {
        var main = '✅';
    }
let messageText = '*Main :* `' + main + '`\n';
messageText += await pokelist(matchings,ctx,0)
messageText += '\n\n_Choose Any Option Below_'
ctx.answerCbQuery('Added Pokemon To Team')
ctx.editMessageText(messageText,{parse_mode:'Markdown',reply_markup:{inline_keyboard:[[{text:'Add Poke',callback_data:'add_'+team+''},{text:'Remove Poke',callback_data:'remove_'+team+''}],[{text:'Change Order',callback_data:'change_order_'+team+''},{text:'Randomize',callback_data:'randomize_'+team+''}],[{text:'Reset Team',callback_data:'rest_'+team+''},{text:'Main',callback_data:'main_'+team+''}],[{text:'Rename',callback_data:'rename_'+team+''},{text:'🔙Back',callback_data:'teams'}]]}})
})
bot.action(/remove_/,check2q,async ctx => {
const userData = await getUserData(ctx.from.id);
const team = ctx.callbackQuery.data.split('_')[1]
let pokes = userData.pokes
const buttonsPerRow = 2;
let inlineKeyboard = [];
let row = [];
let buttonNumber = 1; // Initialize the button number
const pok = userData.teams[team]
for(const sl of pok){
for(const sl2 of pokes){
if(sl==sl2.pass){
row.push({
      text: `${buttonNumber}. ${sl2.name}`,
      callback_data: `rjem_${sl2.pass}_${team}`,
    });
    if (row.length === buttonsPerRow || buttonNumber === pokes.length - 1) {
      inlineKeyboard.push(row);
      row = [];
    }
    buttonNumber++; // Increment the button number
  }
}
}
if (row.length > 0 && row.length < buttonsPerRow) {
  while (row.length < buttonsPerRow) {
    row.push({ text: ' ', callback_data: 'empty' });
  }
  inlineKeyboard.push(row);
}
inlineKeyboard.push([{ text: '🔙Back', callback_data: 'set_'+team+'' }]);
let messageText = '';
messageText += '\n*Select Poke To Remove From Team ' + team + '*';
const keyboard = {
  inline_keyboard: inlineKeyboard,
};
ctx.editMessageText(messageText,{parse_mode:'markdown',reply_markup:keyboard})
})
bot.action(/rjem_/,check2q, async (ctx) => {
    const pass = ctx.callbackQuery.data.split('_')[1];
    const team = ctx.callbackQuery.data.split('_')[2];
    const userId = ctx.from.id;
    const userData = await getUserData(ctx.from.id);


    if (!userData.teams) {
        userData.teams = {};
    }

    if (!userData.teams[team]) {
        userData.teams[team] = [];
    }
        userData.teams[team] = userData.teams[team].filter(p => p !== pass);
        await saveUserData(userId, userData);
const pokes = userData.teams[team];
    const matchings = [];
let b = 1
    for (const pass of pokes) {
        const matching = userData.pokes.find((poke) => poke.pass === pass);
        if (matching) {
            matchings.push(pass)
         b++;
}
    }

    const list = matchings.join('\n');

    if (!userData.inv || userData.inv.team !== team) {
        var main = '❌';
    } else {
        var main = '✅';
    }
let messageText = '*Main :* `' + main + '`\n';
messageText += await pokelist(matchings,ctx,0)
messageText += '\n\n_Choose Any Option Below_'
ctx.answerCbQuery('Removed Pokemon From Team')
ctx.editMessageText(messageText,{parse_mode:'Markdown',reply_markup:{inline_keyboard:
[[{text:'Add Poke',callback_data:'add_'+team+''},{text:'Remove Poke',callback_data:'remove_'+team+''}],
[{text:'Change Order',callback_data:'change_order_'+team+''},{text:'Randomize',callback_data:'randomize_'+team+''}],
[{text:'Reset Team',callback_data:'rest_'+team+''},{text:'Main',callback_data:'main_'+team+''}],
[{text:'Rename',callback_data:'rename_'+team+''},{text:'🔙Back',callback_data:'teams'}]]}})
})
bot.action(/change_order_/, check2q,async (ctx) => {
    const userData = await getUserData(ctx.from.id);
    const team = ctx.callbackQuery.data.split('_')[2];
    let slugsInTeam = [];

    if (userData && userData.teams && userData.teams[team]) {
        slugsInTeam = userData.teams[team];
    } else {
        ctx.answerCbQuery('Team Is Invalid Or Empty.', { show_alert: true });
        return;
    }

    const slugPasses = slugsInTeam.map((pass) => {
        const matchingSlug = userData.pokes.find((slug) => slug.pass === pass);
        return matchingSlug ? matchingSlug.pass : '';
    });

    // Filter out empty passes
    const validSlugPasses = slugPasses

    // Initial message to select two slugs to swap
    let messageText = '';
    messageText += '\n\nWhich Pokemon You Wanna Swap?';

    const inlineKeyboard = validSlugPasses.map((pass) => {
for(const slug of userData.pokes){
        if (slug.pass == pass) {
            return {
                text: c(slug.name),
                callback_data: `fswc_${team}_${slug.pass}`,
            };
        }
}
        return null;
    }).filter((button) => button !== null);

    inlineKeyboard.push({ text: '🔙Back', callback_data: 'set_' + team });

    const buttonsPerRow = 2;
    const keyboardChunks = [];
    for (let i = 0; i < inlineKeyboard.length; i += buttonsPerRow) {
        keyboardChunks.push(inlineKeyboard.slice(i, i + buttonsPerRow));
    }

    const keyboard = {
        inline_keyboard: keyboardChunks,
    };

    ctx.editMessageText(messageText, { parse_mode: 'markdown', reply_markup: keyboard });
});

bot.action(/fswc_/, check2q,async (ctx) => {
    const userData = await getUserData(ctx.from.id);


    const team = ctx.callbackQuery.data.split('_')[1];
    const selectedSlugPass = ctx.callbackQuery.data.split('_')[2];
let slugsInTeam = [];                                                                       
    if (userData && userData.teams && userData.teams[team]) {                                           
slugsInTeam = userData.teams[team];
    } else {                                                                                            
ctx.answerCbQuery('Team Is Invalid Or Empty.', { show_alert: true });
        return;                                                                                     }                                                                                                                                                                                               // Ensure that the user has the slugs with these passes                                         
const slugPasses = slugsInTeam.map((pass) => {
        const matchingSlug = userData.pokes.find((slug) => slug.pass === pass);                          
return matchingSlug ? matchingSlug.pass : '';
    });                                                                                                                                                                                             
// Filter out empty passes
    const validSlugPasses = slugPasses



    // Check if the user has a slug with the selected pass
    const selectedSlugIndex = validSlugPasses.findIndex((pass) => pass === selectedSlugPass);

    if (selectedSlugIndex === -1) {
        ctx.answerCbQuery('You not have the choosen pokemon anymore.', { show_alert: true });
        return;
    }
const p6 = userData.pokes.filter((p7) =>p7.pass==selectedSlugPass)[0]
    // Edit the message to ask for the second slug to swap
    let messageText = 'Which Pokemon You Wanna Replace With *'+c(p6.name)+'*';

    const inlineKeyboard = validSlugPasses.map((pass) => {
for(const slug of userData.pokes){
if (pass == slug.pass) {
            return {
                text: (pass==selectedSlugPass) ? ' ' : c(slug.name),
                callback_data: `swap_confirm_${team}_${selectedSlugPass}_${slug.pass}`,
            };
        }
}
        return null;
    }).filter((button) => button !== null);

    inlineKeyboard.push({ text: '🔙Back', callback_data: 'set_' + team });

    const buttonsPerRow = 2;
    const keyboardChunks = [];
    for (let i = 0; i < inlineKeyboard.length; i += buttonsPerRow) {
        keyboardChunks.push(inlineKeyboard.slice(i, i + buttonsPerRow));
    }

    const keyboard = {
        inline_keyboard: keyboardChunks,
    };

    ctx.editMessageText(messageText, { parse_mode: 'markdown', reply_markup: keyboard });
});

bot.action(/swap_confirm_/, check2q,async (ctx) => {
    const userData = await getUserData(ctx.from.id);

    const team = ctx.callbackQuery.data.split('_')[2];
    const pass1 = ctx.callbackQuery.data.split('_')[3];
    const pass2 = ctx.callbackQuery.data.split('_')[4];
    const slugsInTeam = userData.teams[team];

    // Find the indices of the slugs with pass1 and pass2
    const index1 = slugsInTeam.findIndex((pass) => pass === pass1);
    const index2 = slugsInTeam.findIndex((pass) => pass === pass2);

    // Swap the passes
    if (index1 !== -1 && index2 !== -1) {
        slugsInTeam[index1] = pass2;
        slugsInTeam[index2] = pass1;
    }

    // Save the updated data
    await saveUserData(ctx.from.id, userData);

    // Edit the message to show the updated order
    const matchings = [];
    let b = 1;

    for (const pass of slugsInTeam) {
        const matchingSlug = userData.pokes.find((slug) => slug.pass === pass);
        if (matchingSlug) {
            matchings.push(pass);
            b++;
        }
    }

    const list = matchings.join('\n');

    if (!userData.inv || userData.inv.team !== team) {
        var main = '❌';
    } else {
        var main = '✅';
    }
let messageText = '*Main :* `' + main + '`\n';
messageText += await pokelist(matchings,ctx,0)
messageText += '\n\n_Choose Any Option Below_'
ctx.answerCbQuery('Swapped Both Pokemons')

ctx.editMessageText(messageText,{parse_mode:'Markdown',reply_markup:{inline_keyboard:
[[{text:'Add Poke',callback_data:'add_'+team+''},{text:'Remove Poke',callback_data:'remove_'+team+''}],
[{text:'Change Order',callback_data:'change_order_'+team+''},{text:'Randomize',callback_data:'randomize_'+team+''}],
[{text:'Reset Team',callback_data:'rest_'+team+''},{text:'Main',callback_data:'main_'+team+''}],
[{text:'Rename',callback_data:'rename_'+team+''},{text:'🔙Back',callback_data:'teams'}]]}})
})

bot.command('mybag',async ctx => {
const data = await getUserData(ctx.from.id)
if(!data.inv){
ctx.replyWithMarkdown('*Start your journey now*',{reply_to_message_id:ctx.message.message_id,
reply_markup:{inline_keyboard:[[
{text:'Start My Journey',url:'t.me/PokePlayBot?start=start',}]]}})
return
}
if(!data.inv.pc){
data.inv.pc = 0
}
let msg = '*💷 PokeCoins:* '+data.inv.pc+'\n\n'
for(const ball in data.balls){
if(data.balls[ball]>0){
msg += '• *'+c(ball)+' Balls:* '+data.balls[ball]+'\n'
}
}
if(data.inv.candy && data.inv.candy > 0){
msg += '\n• *🍬 Candies:* '+data.inv.candy+''
}
if(data.inv.vitamin && data.inv.vitamin > 0){
msg += '\n• *💉 Vitamins:* '+data.inv.vitamin+''
}
if(data.inv.berry && data.inv.berry > 0){
msg += '\n• *🍒 Berries:* '+data.inv.berry+''
}
if(data.inv.ring){
msg += '\n\n• *Mega Ring:* Equipped'
}
ctx.replyWithMarkdown(msg,{reply_to_message_id:ctx.message.message_id,reply_markup:{inline_keyboard:[[{text:'Potions',callback_data:'poag_potions_'+ctx.from.id+''},{text:'TMs',callback_data:'poag_tms_'+ctx.from.id+''}],[{text:'Stones',callback_data:'poag_stones_'+ctx.from.id+''}]]}})
})
bot.action(/poag_/,async ctx => {
const id = ctx.callbackQuery.data.split('_')[2]
if(ctx.from.id!=id){
return
}
const item = ctx.callbackQuery.data.split('_')[1]
const items = ['potions','tms','stones','inventory']
const data = await getUserData(ctx.from.id)
const store = items.filter((storeitem)=>storeitem!=item)
const buttons = store.map((word) => ({ text: c(word), callback_data: 'poag_'+word+'_'+ctx.from.id+'' }));
  const rows = [];
  for (let i = 0; i < buttons.length; i += 2) {
    rows.push(buttons.slice(i, i + 2));
  }
if(item=='potions'){
let msg = '*Coming Soon*'
ctx.editMessageText(msg,{parse_mode:'markdown',reply_markup:{inline_keyboard:rows}})
return
}
if(item=='tms'){
let msg = '*TMs ⚙*\n\n'
if(!data.tms){
data.tms = {}
}
for(const tm in data.tms){
if(data.tms[tm] >0){
let h = ''
if(data.tms[tm] > 1){
h = '('+data.tms[tm]+')'
}
const t = tms.tmnumber[String(tm)]
msg += '• */TM'+tm+' -* '+c(dmoves[t].name)+' '+h+'\n'
}
}
ctx.editMessageText(msg,{parse_mode:'markdown',reply_markup:{inline_keyboard:rows}})
return
}
if(item=='stones'){
let msg = '*Mega Stones :-\n\n*'
if(!data.inv.stones){
data.inv.stones = []
}
for(const stone of data.inv.stones){
msg += '• '+c(stone)+'\n'
}
ctx.editMessageText(msg,{parse_mode:'markdown',reply_markup:{inline_keyboard:rows}})
return
}
if(item=='inventory'){
if(!data.inv.pc){
data.inv.pc = 0
}
let msg = '*💷 PokeCoins:* '+data.inv.pc+'\n\n'
for(const ball in data.balls){
if(data.balls[ball]>0){
msg += '*'+c(ball)+' Balls:* '+data.balls[ball]+'\n'
}
}
if(data.inv.candy && data.inv.candy > 0){
msg += '\n• *🍬 Candies:* '+data.inv.candy+''
}
if(data.inv.vitamin && data.inv.vitamin > 0){
msg += '\n• *💉 Vitamins:* '+data.inv.vitamin+''
}
if(data.inv.berry && data.inv.berry > 0){
msg += '\n• *🍒 Berries:* '+data.inv.berry+''
}
if(data.inv.ring){
msg += '\n\n• *Mega Ring:* Equipped'
}
ctx.editMessageText(msg,{parse_mode:'markdown',reply_markup:{inline_keyboard:rows}})
return
}
})



bot.action(/lrn_/,check2q,async ctx => {
const pass = ctx.callbackQuery.data.split('_')[1]
const mid = ctx.callbackQuery.data.split('_')[2]
const time = ctx.callbackQuery.data.split('_')[3]
const data = await getUserData(ctx.from.id)
const poke = data.pokes.filter((poke)=> poke.pass == pass)[0]
if(!poke){
ctx.answerCbQuery('You Not Have This Poke AnyMore')
return
}
const queryTime = new Date(time)
const options = {
  timeZone: 'Asia/Kolkata',
  month: 'numeric',
  day: 'numeric',
  hour: 'numeric',
  minute: 'numeric',
  hour12: true,
};
const currentTime = new Date().toLocaleString('en-US', options)
const timeDifference = new Date(currentTime) - queryTime;
console.log(timeDifference)
if(timeDifference > 900000){
ctx.editMessageText('Unfortunately, Timeout For *15 Min* Has Over & *'+c(poke.name)+'* Did Not Learnt *'+c(dmoves[mid].name)+'*',{parse_mode:'markdown'})
return
}
let msg = '<b>Pokemon :</b> '+c(poke.name)+' (Lv. '+plevel(poke.name,poke.exp)+')\n\n'
const moves = []
for(const move2 of poke.moves){
let move = dmoves[move2]
msg += '• <b>'+c(move.name)+'</b> ['+c(move.type)+' '+emojis[move.type]+']\n<b>Power:</b> '+move.power+', <b>Accuracy:</b> '+move.accuracy+'% <i>('+c(move.category.charAt(0))+')</i>\n'
moves.push(move2)
}
msg += '\n<i>Which Move Should Be Forgotten?</i>'

const buttons = moves.map((word) => ({ text: c(dmoves[word].name), callback_data: 'elr_'+word+'_'+pass+'_'+mid+'_'+time+'' }));
  const rows = [];
  for (let i = 0; i < buttons.length; i += 2) {
    rows.push(buttons.slice(i, i + 2));
  }
ctx.editMessageText(msg,{parse_mode:'HTML',reply_markup:{inline_keyboard:rows}})
})
bot.action(/elr_/,check2q,async ctx => {
const move9 = ctx.callbackQuery.data.split('_')[1]
const pass = ctx.callbackQuery.data.split('_')[2]
const mid = ctx.callbackQuery.data.split('_')[3]
const time = ctx.callbackQuery.data.split('_')[4]
const data = await getUserData(ctx.from.id)
const poke = data.pokes.filter((poke)=> poke.pass == pass)[0]
if(!poke){
ctx.answerCbQuery('You Not Have This Poke AnyMore')
return
}
const queryTime = new Date(time)
const options = {
  timeZone: 'Asia/Kolkata',
  month: 'numeric',
  day: 'numeric',
  hour: 'numeric',
  minute: 'numeric',
  hour12: true,
};
const currentTime = new Date().toLocaleString('en-US', options)
const timeDifference = new Date(currentTime) - queryTime;
console.log(timeDifference)
if(timeDifference > 900000){
ctx.editMessageText('Unfortunately, Timeout For *15 Min* Has Over & *'+c(poke.name)+'* Did Not Learnt *'+c(dmoves[mid].name)+'*',{parse_mode:'markdown'})
return
}
let msg = 'Are You Sure To Your <b>'+c(poke.name)+'</b> (<b>Lv.</b> '+plevel(poke.name,poke.exp)+')\n\n'
msg += '<b>Forget The Move:</b>'
const move = dmoves[String(move9)]
const move2 = dmoves[String(mid)]
msg += '\n• <b>'+c(move.name)+'</b> ['+c(move.type)+' '+emojis[move.type]+']\n<b>Power:</b> '+move.power+'<b>, Accuracy:</b> '+move.accuracy+' ('+c(move.category.charAt(0))+')'
msg += '\n\n<b>And Learn The Move:</b>'
msg += '\n• <b>'+c(move2.name)+'</b> ['+c(move2.type)+' '+emojis[move2.type]+']\n<b>Power:</b> '+move2.power+'<b>, Accuracy:</b> '+move2.accuracy+' ('+c(move2.category.charAt(0))+')'
ctx.editMessageText(msg,{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'Confirm',callback_data:'mhusz_'+move9+'_'+mid+'_'+pass+'_'+time+''},{text:'Cancel',callback_data:'lrn_'+pass+'_'+mid+'_'+time+''}]]}})
})
bot.action('crncl',async ctx => {
ctx.editMessageText('Cancelled')
})
bot.action(/mhusz_/,check2q,async ctx => {
const move = ctx.callbackQuery.data.split('_')[1]
const pass = ctx.callbackQuery.data.split('_')[3]
const mid = ctx.callbackQuery.data.split('_')[2]
const time = ctx.callbackQuery.data.split('_')[4]
const data = await getUserData(ctx.from.id)
console.log(pass)
const poke = data.pokes.filter((poke)=> poke.pass == pass)[0]
if(!poke){
ctx.answerCbQuery('You Not Have This Poke AnyMore')
return
}
const queryTime = new Date(time)
const options = {
  timeZone: 'Asia/Kolkata',
  month: 'numeric',
  day: 'numeric',
  hour: 'numeric',
  minute: 'numeric',
  hour12: true,
};
const currentTime = new Date().toLocaleString('en-US', options)
const timeDifference = new Date(currentTime) - queryTime;
console.log(timeDifference)
if(timeDifference > 900000){
ctx.editMessageText('Unfortunately, Timeout For *15 Min* Has Over & *'+c(poke.name)+'* Did Not Learnt *'+c(dmoves[mid].name)+'*',{parse_mode:'markdown'})
return
}
if(!poke.moves.includes(parseInt(move))){
ctx.answerCbQuery('Your Poke Does Not Know This Move')
return
}
const index = poke.moves.indexOf(parseInt(move));

if (index !== -1) {
  poke.moves[index] = parseInt(mid);
await saveUserData(ctx.from.id,data)
ctx.editMessageText('*'+c(poke.name)+'* Has Learnt *'+c(dmoves[mid].name)+'*',{parse_mode:'markdown'})
const mdata = await loadMessageData();
if(mdata.moves[ctx.callbackQuery.message.message_id]){
delete mdata.moves[ctx.callbackQuery.message.message_id]
await saveMessageData(mdata)
}
}
})

bot.command('pokestore',async ctx => {
const store2 = ['balls','tms']
const store = store2.filter((storeitem)=>storeitem!='balls')
const buttons = store.map((word) => ({ text: c(word), callback_data: 'store_'+word+'_'+ctx.from.id+'' }));
  const rows = [];
  for (let i = 0; i < buttons.length; i += 3) {
    rows.push(buttons.slice(i, i + 3));
  }

ctx.replyWithMarkdown(`*Welcome To Poke Store 🏦 :-

• Regular Ball -* 15 💷
*• Great Ball -* 25 💷
*• Ultra Ball -* 40 💷
*• Master Ball -* Not In Stock
*• Candy -* 100 💷
*• Berry -* 70 💷
*• Vitamin -* 100 💷
*• Mega Ring -* 5000 💷`,{reply_to_message_id:ctx.message.message_id,reply_markup:{inline_keyboard:rows}})
})
bot.action(/store_/,async ctx => {
const item = ctx.callbackQuery.data.split('_')[1]
const id = ctx.callbackQuery.data.split('_')[2]
if(ctx.from.id!=id){
return
}
if(item=='balls'){
const store2 = ['balls','tms']
const store = store2.filter((storeitem)=>storeitem!=item)
const buttons = store.map((word) => ({ text: c(word), callback_data: 'store_'+word+'_'+ctx.from.id+'' }));
  const rows = [];
  for (let i = 0; i < buttons.length; i += 3) {
    rows.push(buttons.slice(i, i + 3));
  }
ctx.editMessageText(`*Welcome To Poke Store 🏦 :-             
• Regular Ball -* 15 💷
*• Great Ball -* 25 💷
*• Ultra Ball -* 40 💷
*• Master Ball -* Not In Stock
*• Candy -* 100 💷
*• Berry -* 70 💷
*• Vitamin -* 100 💷
*• Mega Ring -* 5000 💷`,{parse_mode:'markdown',
reply_markup:{inline_keyboard:rows}})
}
if(item=='tms'){
const page = ctx.callbackQuery.data.split('_')[3]*1 || 1
const startIdx = (page - 1) * 10;
const endIdx = startIdx + 10;
if(page<1 || startIdx > Object.keys(tms.tmnumber).length){
return
}
const userData = await getUserData(ctx.from.id)
const matchingLevels = Object.keys(trainerlevel).filter(level => userData.inv.exp >= trainerlevel[level]);
const level = matchingLevels.length > 0 ? parseInt(matchingLevels[matchingLevels.length - 1]) : undefined;
if(level < 35){
ctx.answerCbQuery('Reach Level 35 To Unlock TMs Store')
return
}

let msg = '*Welcome To Poke Store TMs Section 🏦 :-*\n\n'
const tm = tms.tmnumber
let b = 1
for(const t in tm){
const m = tms.tmnumber[String(t)]
if(tmprices.buy[String(t)]){
if(startIdx <= b && b<= endIdx){
msg += '*'+b+'.* *TM'+t+'* ('+c(dmoves[m].name)+' '+emojis[dmoves[m].type]+')\n*• Buy:* '+tmprices.buy[String(t)]+' PokeCoins 💷\n*• Sell:* '+tmprices.sell[String(t)]+' PokeCoins 💷\n\n'
}
b++;
}
}
const store2 = ['balls','tms']
const store = store2.filter((storeitem)=>storeitem!=item)
const buttons = store.map((word) => ({ text: c(word), callback_data: 'store_'+word+'_'+ctx.from.id+'' }));
  const rows = [];
  for (let i = 0; i < buttons.length; i += 3) {
    rows.push(buttons.slice(i, i + 3));
  }
let key2 = [[{text:'<',callback_data:'store_tms_'+ctx.from.id+'_'+(page-1)+''},{text:'>',callback_data:'store_tms_'+ctx.from.id+'_'+(page+1)+''}]]
var key = key2.concat(rows)
ctx.editMessageText(msg,{parse_mode:'markdown',reply_markup:{inline_keyboard:key}})
}
})



bot.command('buy',check,check2,async ctx => {
const messageData = await loadMessageData();
if(messageData.battle.includes(ctx.from.id)) {
ctx.replyWithMarkdown('You Are In A *Battle*',{reply_to_message_id:ctx.message.message_id})
return
}

const item2 = ctx.message.text.split(' ')[1]
if(!item2){
ctx.replyWithMarkdown('*Usage:* /buy <item>',{reply_to_message_id:ctx.message.message_id})
return
}
const data = await getUserData(ctx.from.id)
if(item2.toLowerCase()=='ring' || ctx.message.text.split(' ').slice(1).join(' ').toLowerCase()== 'mega ring'){
const matchingLevels = Object.keys(trainerlevel).filter(level => data.inv.exp >= trainerlevel[level]);
const level = matchingLevels.length > 0 ? parseInt(matchingLevels[matchingLevels.length - 1]) : undefined;
if(level<25){
ctx.replyWithMarkdown('You Have To Reach *25 Level* To Unlock TMs Store',{parse_mode:'markdown',reply_to_message_id:ctx.message.message_id})
return
}
if(data.inv.pc < 5000){
ctx.replyWithMarkdown('*You not have enough PokeCoins💷*',{reply_to_message_id:ctx.message.message_id})
return
}
if(data.inv.ring){
ctx.replyWithMarkdown('You already have bought *Mega Ring*',{reply_to_message_id:ctx.message.message_id})
return
}
data.inv.ring = true
data.inv.pc -= 5000
await saveUserData(ctx.from.id,data)
ctx.replyWithMarkdown('Bought *Mega Ring* For *5000* PokeCoins 💷',{reply_to_message_id:ctx.message.message_id})
bot.telegram.sendMessage(5432006093,'#buy\n\n<b>'+he.encode(ctx.from.first_name)+'</b> (<code>'+ctx.from.id+'</code>) bought <code>Mega Ring</code>',{parse_mode:'HTML'})
return
}
if(item2.toLowerCase().includes('tm')){
const num = item2.toLowerCase().replace('tm','')
const matchingLevels = Object.keys(trainerlevel).filter(level => data.inv.exp >= trainerlevel[level]);
const level = matchingLevels.length > 0 ? parseInt(matchingLevels[matchingLevels.length - 1]) : undefined;
if(level < 35){
ctx.replyWithMarkdown('You Have To Reach *35 Level* To Unlock TMs Store',{parse_mode:'markdown',reply_to_message_id:ctx.message.message_id})
return
}
if(!tms.tmnumber[String(num)] || !tmprices.buy[String(num)]){
ctx.replyWithMarkdown('*Invalid TM*',{reply_to_message_id:ctx.message.message_id})
return
}
if(!data.tms){
data.tms = {}
}
if(!data.tms[String(num)]){
data.tms[String(num)] = 0
}
const price = tmprices.buy[String(num)]
if(data.inv.pc < price){
ctx.replyWithMarkdown('*You not have enough PokeCoins💷*',{reply_to_message_id:ctx.message.message_id})
return
}
data.tms[String(num)] += 1
data.inv.pc -= price
await saveUserData(ctx.from.id,data)
ctx.replyWithMarkdown('Bought *TM'+num+'* For *'+price+'* PokeCoins 💷',{reply_to_message_id:ctx.message.message_id})
bot.telegram.sendMessage(5432006093,'#buy\n\n<b>'+he.encode(ctx.from.first_name)+'</b> (<code>'+ctx.from.id+'</code>) bought <code>TM'+num+'</code>',{parse_mode:'HTML'})
return
}
const Store2 = {
"vitamin":100,
"candy":100,
"berry":75
}
const amount = Math.max(Math.floor(ctx.message.text.split(' ')[2]),1)
if(!amount){
ctx.replyWithMarkdown('*Usage:* /buy <item> <amount>',{reply_to_message_id:ctx.message.message_id})
return
}
if(isNaN(amount)){
ctx.replyWithMarkdown('*Invalid amount*',{reply_to_message_id:ctx.message.message_id})
return
}
for(const item in Store2){
if(item2.toLowerCase()== item){
const price = Store2[item]
const pay = amount*price
if(pay>data.inv.pc){
ctx.replyWithMarkdown('*You not have enough PokeCoins💷*',{reply_to_message_id:ctx.message.message_id})
return
}
data.inv.pc -= pay
if(!data.inv[item]){
data.inv[item] = 0
}
data.inv[item] += amount
await saveUserData(ctx.from.id,data)
ctx.replyWithMarkdown('Bought *'+amount+'* '+c(item)+' for *'+pay+'* PokeCoins 💷',{reply_to_message_id:ctx.message.message_id})
bot.telegram.sendMessage(5432006093,'#buy\n\n<b>'+he.encode(ctx.from.first_name)+'</b> (<code>'+ctx.from.id+'</code>) bought <code>'+amount+' '+c(item)+'</code>',{parse_mode:'HTML'})
return
}
}
let Store = {
"regular":15,
"great":25,
"ultra":40,
}
if(ctx.from.id==ADMIN_ID){
Store["master"]=500
}
for(const item in Store){
if(item2.toLowerCase()== item){
const price = Store[item]
const pay = amount*price
if(pay>data.inv.pc){
ctx.replyWithMarkdown('*You not have enough PokeCoins💷*',{reply_to_message_id:ctx.message.message_id})
return
}
data.inv.pc -= pay
if(!data.balls){
data.balls = {}
}
if(!data.balls[item]){
data.balls[item] = 0
}
data.balls[item] += amount
await saveUserData(ctx.from.id,data)
ctx.replyWithMarkdown('Bought *'+amount+'* '+c(item)+' Balls for *'+pay+'* PokeCoins 💷',{reply_to_message_id:ctx.message.message_id})
bot.telegram.sendMessage(5432006093,'#buy\n\n<b>'+he.encode(ctx.from.first_name)+'</b> (<code>'+ctx.from.id+'</code>) bought <code>'+amount+' '+c(item)+'</code>',{parse_mode:'HTML'})
return
}
}
ctx.replyWithMarkdown('*Invalid item*',{reply_to_message_id:ctx.message.message_id})
})
bot.command('transfer',check ,async ctx => {
const data = await getUserData(ctx.from.id)
const reply = ctx.message.reply_to_message
if(!reply || reply.from.id == ctx.from.id){
ctx.replyWithMarkdown('Reply to a *User* to send *PokeCoins* 💷',{reply_to_message_id:ctx.message.message_id})
return
}
const data2 = await getUserData(reply.from.id)
if(!data2.inv){
ctx.replyWithMarkdown('*Start your journey now*',{reply_to_message_id:reply.message_id,
reply_markup:{inline_keyboard:[[
{text:'Start My Journey',url:'t.me/PokePlayBot?start=start',}]]}})
return
}
const matchingLevels = Object.keys(trainerlevel).filter(level => data.inv.exp >= trainerlevel[level]);
const level = matchingLevels.length > 0 ? parseInt(matchingLevels[matchingLevels.length - 1]) : undefined;
if(level<7){
ctx.replyWithMarkdown('You Have To Reach *7 Level* To Transfer PokeCoins 💷',{reply_to_message_id:ctx.message.message_id})
return
}
const amount = Math.max(Math.floor(ctx.message.text.split(' ')[1]),1)
if(!amount){
ctx.replyWithMarkdown('Give a amount of *PokeCoins* 💷 Also',{reply_to_message_id:ctx.message.message_id})
return
}
if(data.inv.pc < amount){
ctx.replyWithMarkdown('You not have enough *PokeCoins* 💷',{reply_to_message_id:ctx.message.message_id})
return
}
data.inv.pc -= amount
data2.inv.pc += amount
await saveUserData(ctx.from.id,data)
await saveUserData(reply.from.id,data2)
ctx.replyWithHTML('Sent <b>'+amount+'</b> 💷 to <b>'+he.encode(reply.from.first_name)+'</b>',{reply_to_message_id:ctx.message.message_id})
bot.telegram.sendMessage(5432006093,'#transfer\n\n<b>'+he.encode(ctx.from.first_name)+'</b> (<code>'+ctx.from.id+'</code>) sent <code>'+amount+'</code> 💷 to <b>'+he.encode(reply.from.first_name)+'</b> (<code>'+reply.from.id+'</code>)',{parse_mode:'HTML'})
})
bot.action(/evy_/,check2q,async ctx => {
const data = await getUserData(ctx.from.id)
//const name = ctx.callbackQuery.data.split('_')[1]
const pass = ctx.callbackQuery.data.split('_')[2]
const id = ctx.callbackQuery.data.split('_')[3]
if(id && id!=ctx.from.id){
ctx.answerCbQuery()
return
}
const poke = data.pokes.filter((poke)=> poke.pass == pass)[0]
if(!poke){
ctx.editMessageText('Poke not found')
return
}
const name = poke.name
const evo = chains.evolution_chains.filter((chain)=>chain.current_pokemon==name)[0]
if(!evo){
ctx.editMessageText('*'+c(name)+'* does not evolve futher',{parse_mode:'markdown'})
return
}
if(evo && evo.evolution_level && evo.evolution_method == 'level-up' && evo.evolution_level <= plevel(poke.name,poke.exp)){
const d = pokes[evo.evolved_pokemon]
poke.name = evo.evolved_pokemon
poke.id = d.pokedex_number
if(!d || !d.front_default_image){
ctx.answerCbQuery('This Evolution Cant Be Performed,Contact Admins',{show_alert:true})
return
}
await saveUserData(ctx.from.id,data)
ctx.editMessageText('*'+c(name)+'* Is Evolving.......',{parse_mode:'markdown'})
setTimeout(()=> {
ctx.deleteMessage(ctx.callbackQuery.message.message_id)
//ctx.deleteMessage(m.message.id)
let img = d.front_default_image
const im = shiny.filter((poke)=>poke.name==evo.evolved_pokemon)[0]
if(poke.symbol=='✨' && im.shiny_url){
img=im.shiny_url
}

ctx.replyWithPhoto(img,{caption:'*'+c(name)+'* Has Been Evolved Into *'+c(evo.evolved_pokemon)+'*',parse_mode:'markdown'})
},3500)
}else{
ctx.editMessageText('Your *'+c(name)+'* Does Not Match With Requirements To *Evolve*',{parse_mode:'markdown'})
}
})

bot.command('safari_zone',async ctx => {
const userData = await getUserData(ctx.from.id)
ctx.replyWithMarkdown(`Welcome To *Safari Zone*, You can hunt rare, legendry, mythical types pokemons here. 

*Info About Safari Zone :-*
_• You Will Get 20 Safari Balls (2x catch rate) 
• You Can't Battle With Pokemon
• You Can't Use Any Other PokeBall
• You Will Automatically Ran Out After You Balls Over
• Using /exit Won't Refund Anything
• Max One Time In A Day Can Play Safari
• Entering Safari Will Reset The Next Day
• You Are Not Guaranteed To Catch A Pokemon_

*Entry Fees:* 200 💷
*/enter -* _To Enter Safari Zone_
*/exit -* _To Exit Safari Zone_`,{reply_to_message_id:ctx.message.message_id})
})
bot.command('enter',check,check2,async ctx => {
const userData = await getUserData(ctx.from.id);
const currentDate = moment().format('YYYY-MM-DD');
if(userData.balls.safari && userData.balls.safari > 0){
ctx.replyWithMarkdown('You Are Already In *'+c(userData.extra.saf)+' Safari Zone*',{reply_to_message_id:ctx.message.message_id})
return
}
if(!userData.extra){
userData.extra = {}
}
if(userData.extra.lastsafari && userData.extra.lastsafari == currentDate){
ctx.replyWithMarkdown('You Have Already Played *Safari* Today',{reply_to_message_id:ctx.message.message_id})
return
}
if (userData.inv.pc < 200) {
    ctx.replyWithMarkdown('Entry Fees Is *200 PokeCoins 💷*',{reply_to_message_id:ctx.message.message_id});
    return;
  }
const matchingLevels = Object.keys(trainerlevel).filter(level => userData.inv.exp >= trainerlevel[level]);
const userLevel = matchingLevels.length > 0 ? parseInt(matchingLevels[matchingLevels.length - 1]) : undefined
const regions = ['Kanto','Jhoto','Hoenn','Sinnoh','Hisui','Unova','Kalos','Alola','Galar','Paldea']
const key = [[]];
    for (let i = 0; i < regions.length; i++) {
if(userLevel > 5*i){
        if (i % 4 === 0) {
            key.push([]);
        }
        key[key.length - 1].push({ text: regions[i], callback_data: 'safari_' + regions[i] + '_'+ctx.from.id+'' });
}
  }
ctx.replyWithMarkdown('*Which Region Safari Zone You Wanna Play?*',{reply_markup:{inline_keyboard:key}})
})
bot.action(/safari_/,check2q,async ctx => {
const reg = ctx.callbackQuery.data.split('_')[1]
const id = ctx.callbackQuery.data.split('_')[2]
if(ctx.from.id!=id){
ctx.answerCbQuery()
return
}
const currentDate = moment().format('YYYY-MM-DD');
const userData = await getUserData(ctx.from.id);
if(!userData.balls.safari){
userData.balls.safari = 0
}
if(userData.balls.safari && userData.balls.safari > 0){
ctx.editMessageText('You Are Already In *'+c(userData.extra.saf)+' Safari Zone*',{parse_mode:'markdown'})
return
}
if(!userData.extra){
userData.extra = {}
}
if(userData.extra.lastsafari && userData.extra.lastsafari == currentDate){
ctx.editMessageText('You Have Already Played *Safari* Today',{parse_mode:'markdown'})
return
}
if (userData.inv.pc < 200) {
    ctx.editMessageText('Entry Fees Is *200 PokeCoins 💷*',{parse_mode:'markdown'});
    return;
  }
userData.inv.pc -= 200
userData.balls.safari = 20
userData.extra.saf = reg
userData.extra.lastsafari = currentDate
await saveUserData(ctx.from.id, userData);

  ctx.editMessageText('Successfully Entered *'+c(reg)+' Safari Zone*',{parse_mode:'markdown'});
});
bot.command('exit',check,check2,async ctx => {
const userData = await getUserData(ctx.from.id);

  if (!userData.balls.safari || userData.balls.safari == 0) {
    ctx.replyWithMarkdown('You Have Not Entered *Safari Zone*',{reply_to_message_id:ctx.message.message_id});
    return;
  }
userData.balls.safari = 0
await saveUserData(ctx.from.id,userData)
ctx.replyWithMarkdown(' Successfully Exited *'+c(userData.extra.saf|| 'Kanto')+' Safari Zone*')
})

const groupCommands = [
    { command: '/start', description: 'Start The Bot' },
    { command: '/hunt', description: 'hunt A Poke' },
{command:'/challenge',description:'Battle With Other Players'},
{command:'/mybag',description:'Check Your Bag'},
{ command: '/mypokemons', description: 'Check Your All Pokes' },
{command:'/mycard',description:'View Your Trainer Card'},
{command:'/trainer_card',description:'Customize Your Trainer Card'},
{ command: '/stats', description: 'Check Stats Of A Poke' },
{command:'/buy',description:'Buy Items From Poke Store'},
{command:'/transfer',description:'transfer PokeCoins To Other Users'},
{ command: '/travel', description: 'Travel Another Place' },
{command:'/safari_zone',description:'Travel Into Safari Zone'},
{command:'/myteams',description:' Setup Your Teams'},
{command:'/pokestore',description:'Visit PokeStore'},
{command:'/trade',description:'Trade Pokemons With Others (Paid)'},
{command:'/candy',description:'Give Candy To Your Pokemon'},
{command:'/vitamin',description:'Give Vitamins To Your Pokemon'},
{command:'/berry',description:'Give Berry To Your Pokemon'},
{command:'/evolve',description:'Evolve Your Pokemon'},
    // Add more group chat commands as needed
  ];                                                                             
  bot.telegram.setMyCommands(groupCommands, {scope: {type: "default"}});
bot.command('mycard', check, async (ctx) => {
  try {
    const userId = ctx.from.id.toString();
    const userData = await getUserData(ctx.from.id)
    const background = await loadImage(bags[userData.inv.template || "1"]);
    const canvas = createCanvas(background.width, background.height);
    const ctxCanvas = canvas.getContext('2d');
    const fontSize = 45;
    const font = `${fontSize}px Arial`;
    const font2 = `55px Arial`;
const img = userData.inv.avtar || '1'
    const p = await loadImage("./cimages/"+img+".png");
    ctxCanvas.font = font;
    ctxCanvas.fillStyle = userData.inv.id || 'white';
if(!userData.extra){
userData.extra = {}
}
if(!userData.extra.date){
const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
userData.extra.date = `${day}/${month}/${year}`;
await saveUserData(ctx.from.id,userData)
}
if(!userData.inv.exp){
userData.inv.exp =0
}
const matchingLevels = Object.keys(trainerlevel).filter(level => userData.inv.exp >= trainerlevel[level]);
const level = matchingLevels.length > 0 ? parseInt(matchingLevels[matchingLevels.length - 1]) : undefined;
if(!userData.inv.battle){
userData.inv.battle = 0
}
if(!userData.inv.win){
userData.inv.win = 0
}
if(!userData.inv.lose){
userData.inv.lose = 0
}
const ht = userData.inv.hometown || 'Kanto'
const caught = userData.pokecaught ? userData.pokecaught.length : 0
const seen = userData.pokeseen ?userData.pokeseen.length : 0
ctxCanvas.drawImage(background,0,0)
ctxCanvas.fillText('Joined : '+userData.extra.date+'',90,280)
ctxCanvas.fillText('User ID : '+ctx.from.id+'',730,280)
ctxCanvas.font = font2;
ctxCanvas.fillStyle = userData.inv.data || 'black';
ctxCanvas.fillText('EXP. Points : '+userData.inv.exp.toLocaleString()+'',550,440)
ctxCanvas.fillText('Trainer Level : '+level+'',550,510)
ctxCanvas.fillText('Total Wins : '+userData.inv.win+'',550,580)
ctxCanvas.fillText('Total Lose : '+userData.inv.lose+'',550,650)
ctxCanvas.fillText('Poke Caught : '+caught+'/1025',550,720)
ctxCanvas.fillText('Dex Entries : '+seen+'/1025',550,790)
ctxCanvas.drawImage(p,37,400,400,400);

    const modifiedPhotoPath = `./images/modified_photo_${ctx.from.id}.jpg`;
    const writableStream = fs.createWriteStream(modifiedPhotoPath);
    canvas.createJPEGStream({ quality: 95 }).pipe(writableStream);
    writableStream.on('finish', () => {
      // Send the modified photo back
      ctx.replyWithPhoto({ source: fs.readFileSync(modifiedPhotoPath) },{parse_mode:'markdown',reply_to_message_id:ctx.message.message_id,reply_markup:{inline_keyboard:[[{text:'More Info',callback_data:'cardmore'}]]}})
    });
  } catch (error) {
    console.log(error);
  }
})
bot.command('trainer_card',check,async ctx => {
try {
if(ctx.chat.type!='private'){
ctx.replyWithMarkdown('*Use in private to edit your card*',{reply_to_message_id:ctx.message.message_id})
return
}
    const userId = ctx.from.id.toString();
    const userData = await getUserData(ctx.from.id)
    const background = await loadImage(bags[userData.inv.template || "1"]);
    const canvas = createCanvas(background.width, background.height);
    const ctxCanvas = canvas.getContext('2d');
    const fontSize = 45;
    const font = `${fontSize}px Arial`;
    const font2 = `55px Arial`;
const img = userData.inv.avtar || '1'
    const p = await loadImage("./cimages/"+img+".png");
    ctxCanvas.font = font;
    ctxCanvas.fillStyle = userData.inv.id || 'white';
if(!userData.extra.date){
const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
userData.extra.date = `${day}/${month}/${year}`;
await saveUserData(ctx.from.id,userData)
}
if(!userData.inv.exp){
userData.inv.exp =0
}
const matchingLevels = Object.keys(trainerlevel).filter(level => userData.inv.exp >= trainerlevel[level]);
const level = matchingLevels.length > 0 ? parseInt(matchingLevels[matchingLevels.length - 1]) : undefined;
if(!userData.inv.battle){
userData.inv.battle = 0
}
if(!userData.inv.win){
userData.inv.win = 0
}
if(!userData.inv.lose){
userData.inv.lose = 0
}
const ht = userData.inv.hometown || 'Kanto'
const seen = userData.pokeseen ?userData.pokeseen.length : 0
ctxCanvas.drawImage(background,0,0)
ctxCanvas.fillText('Joined : '+userData.extra.date+'',90,280)
ctxCanvas.fillText('User ID : '+ctx.from.id+'',730,280)
ctxCanvas.font = font2;
ctxCanvas.fillStyle = userData.inv.data || 'black';
ctxCanvas.fillText('EXP. Points : '+userData.inv.exp.toLocaleString()+'',550,440)
ctxCanvas.fillText('Trainer Level : '+level+'',550,510)
ctxCanvas.fillText('Total Wins : '+userData.inv.win+'',550,580)
ctxCanvas.fillText('Total Lose : '+userData.inv.lose+'',550,650)
const caught = userData.pokecaught ? userData.pokecaught.length : 0
ctxCanvas.fillText('Poke Caught : '+caught+'/1025',550,720)
ctxCanvas.fillText('Dex Entries : '+seen+'/1025',550,790)
ctxCanvas.drawImage(p,37,400,400,400);

    const modifiedPhotoPath = `./images/modified_photo_${ctx.from.id}.jpg`;
    const writableStream = fs.createWriteStream(modifiedPhotoPath);
    canvas.createJPEGStream({ quality: 95 }).pipe(writableStream);
    writableStream.on('finish', () => {
ctx.replyWithPhoto({ source: fs.readFileSync(modifiedPhotoPath) },{reply_markup:{inline_keyboard:[[{text:'Templates',callback_data:'trainer_template'},{text:'Avtar',callback_data:'trainer_avtar'},{text:'Colour',callback_data:'trainer_colour'}]]}})
})
}catch(error){
console.log(error);
}
})
bot.action(/trainer_/,async ctx => {
const edit = ctx.callbackQuery.data.split('_')[1]
const userData = await getUserData(ctx.from.id)
if(edit=='colour'){
ctx.editMessageCaption('Which Text Colour You Wanna Channge?',{
reply_markup:{inline_keyboard:[[{text:'Joined / ID',callback_data:'trainer_id'},{text:'Trainer Data',callback_data:'trainer_data'}],[{text:'Back',callback_data:'trainer_back'}]]}})
}
if(edit=='back'){
ctx.editMessageCaption('What You Want To Edi?',{reply_markup:{inline_keyboard:[[{text:'Templates',callback_data:'trainer_template'},{text:'Avtar',callback_data:'trainer_avtar'},{text:'Colour',callback_data:'trainer_colour'}]]}})
}
if(edit=='id' || edit=='data'){
const row = []
for(let i = 0; i < colors.length; i++){
row.push({text:c(colors[i]),callback_data:'stcrd_'+edit+'_'+colors[i]})
}
let buttons = []
for (let i = 0; i < row.length; i += 4) {
   buttons.push(row.slice(i, i + 4));
  }
const co = userData.inv[edit] || 'white'
ctx.editMessageCaption('Choose New Colour For *'+c(edit)+'* Text\n\n*Current Colour:* '+co+'',{parse_mode:'markdown',
reply_markup:{inline_keyboard:buttons}})
}
if(edit=='template'){
const row = []
for(let i = 1; i <= 9; i++){
row.push({text:i,callback_data:'stcrd_tem_'+i})
}
let buttons = []
for (let i = 0; i < row.length; i += 3) {
    buttons.push(row.slice(i, i + 3));
  }
const tem = userData.inv.template || 1
ctx.telegram.editMessageMedia(ctx.chat.id, ctx.callbackQuery.message.message_id, null, {
        type: 'photo',
        media: "https://te.legra.ph/file/05b0d41d3b37e98e1f82f.jpg"}).then(()=> {
ctx.editMessageCaption('Choose Your New Card New Template\n\n*Current Template:* '+tem+'',{parse_mode:'markdown',
reply_markup:{inline_keyboard:buttons}})
})
}
if(edit=='avtar'){
const row = []
for(let i = 1; i <= 12; i++){
row.push({text:i,callback_data:'stcrd_avtar_'+i})
}
let buttons = []
for (let i = 0; i < row.length; i += 4) {
    buttons.push(row.slice(i, i + 4));
  }
const avtar = userData.inv.avtar || 1
ctx.telegram.editMessageMedia(ctx.chat.id, ctx.callbackQuery.message.message_id, null, {
        type: 'photo',
        media: "https://te.legra.ph/file/f2aa8d685d6a7fdc0d02f.jpg"}).then(()=> {
ctx.editMessageCaption('Choose Your New Avtar\n\n*Current Avtar:* '+avtar+'',{parse_mode:'markdown',
reply_markup:{inline_keyboard:buttons}})
})
}
})
bot.action(/stcrd_/,async ctx => {
const edit = ctx.callbackQuery.data.split('_')[1]
const userData = await getUserData(ctx.from.id)
if(edit=='avtar'){
const avr = ctx.callbackQuery.data.split('_')[2]
userData.inv.avtar = avr
await saveUserData(ctx.from.id,userData)
}
if(edit=='id' || edit=='data'){
const avr = ctx.callbackQuery.data.split('_')[2]
userData.inv[edit] = avr
await saveUserData(ctx.from.id,userData)
}
if(edit=='tem'){
const avr2 = ctx.callbackQuery.data.split('_')[2]
userData.inv.template = avr2
await saveUserData(ctx.from.id,userData)
}
try {
    const userId = ctx.from.id.toString();
    const background = await loadImage(bags[userData.inv.template || "1"]);
    const canvas = createCanvas(background.width, background.height);
    const ctxCanvas = canvas.getContext('2d');
    const fontSize = 45;
    const font = `${fontSize}px Arial`;
    const font2 = `55px Arial`;
const img = userData.inv.avtar || '1'
    const p = await loadImage("./cimages/"+img+".png");
    ctxCanvas.font = font;
    ctxCanvas.fillStyle = userData.inv.id || 'white';
if(!userData.extra.date){
const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
userData.extra.date = `${day}/${month}/${year}`;
await saveUserData(ctx.from.id,userData)
}
if(!userData.inv.exp){
userData.inv.exp =0
}
const matchingLevels = Object.keys(trainerlevel).filter(level => userData.inv.exp >= trainerlevel[level]);
const level = matchingLevels.length > 0 ? parseInt(matchingLevels[matchingLevels.length - 1]) : undefined;
if(!userData.inv.battle){
userData.inv.battle = 0
}
if(!userData.inv.win){
userData.inv.win = 0
}
if(!userData.inv.lose){
userData.inv.lose = 0
}
const ht = userData.inv.hometown || 'Kanto'
const seen = userData.pokeseen ?userData.pokeseen.length : 0
ctxCanvas.drawImage(background,0,0)
ctxCanvas.fillText('Joined : '+userData.extra.date+'',90,280)
ctxCanvas.fillText('User ID : '+ctx.from.id+'',730,280)
ctxCanvas.font = font2;
ctxCanvas.fillStyle = userData.inv.data || 'black';
ctxCanvas.fillText('EXP. Points : '+userData.inv.exp.toLocaleString()+'',550,440)
ctxCanvas.fillText('Trainer Level : '+level+'',550,510)
ctxCanvas.fillText('Total Wins : '+userData.inv.win+'',550,580)
ctxCanvas.fillText('Total Lose : '+userData.inv.lose+'',550,650)
const caught = userData.pokecaught ? userData.pokecaught.length : 0
ctxCanvas.fillText('Poke Caught : '+caught+'/1025',550,720)
ctxCanvas.fillText('Dex Entries : '+seen+'/1025',550,790)
ctxCanvas.drawImage(p,37,400,400,400);

    const modifiedPhotoPath = `./images/modified_photo_${ctx.from.id}.jpg`;
    const writableStream = fs.createWriteStream(modifiedPhotoPath);
    canvas.createJPEGStream({ quality: 95 }).pipe(writableStream);
    writableStream.on('finish', () => {
ctx.telegram.editMessageMedia(ctx.chat.id, ctx.callbackQuery.message.message_id, null, {
        type: 'photo',
        media: {source:fs.readFileSync(modifiedPhotoPath)}}).then(()=> {
ctx.editMessageReplyMarkup({inline_keyboard:[[{text:'Templates',callback_data:'trainer_template'},{text:'Avtar',callback_data:'trainer_avtar'},{text:'Colour',callback_data:'trainer_colour'}]]})
})
})
}catch(error){
console.log(error);
}
})
bot.on('text',async (ctx,next) => {
if(ctx.message.text && ctx.message.text.toLowerCase().includes('/tm')){
let num = ctx.message.text.toLowerCase().replace('/tm','')
if(num.includes('@pokeplaybot')){
num = num.replace('@pokeplaybot','')
}
const data = await getUserData(ctx.from.id)
console.log(num)
if(tms.tmnumber[String(num)]){
if(!data.tms){
data.tms={}
}
console.log('tmfpund')
if(data.tms[num] && data.tms[num] > 0){
console.log('yes')
const m = tms.tmnumber[num]
let msg = '✦ *TM'+num+'* ('+c(dmoves[m].name)+' '+emojis[dmoves[m].type]+')\n'
msg += '*Power:* '+dmoves[m].power+', *Accuracy:* '+dmoves[m].accuracy+' (_'+c(dmoves[m].category)+'_)\n'
msg += '\n• You Can Sell *TM'+num+'* For *'+tmprices.sell[String(num)]+'* 💷'
ctx.replyWithMarkdown(msg,{reply_to_message_id:ctx.message.message_id,reply_markup:{inline_keyboard:[[{text:'Use',callback_data:'tmuse_'+num+'_'+ctx.from.id+''},{text:'Sell',callback_data:'tmselly_'+num+'_'+tmprices.sell[String(num)]+'_'+ctx.from.id+''}]]}})
}else{
ctx.replyWithMarkdown('You Don\'t Have *TM'+num+'*',{reply_to_message_id:ctx.message.message_id})
}
}
}
await next();
})
bot.action(/tmuse_/,check2q,async ctx => {
const id = ctx.callbackQuery.data.split('_')[2]
if(ctx.from.id!=id){
return
}
const tm = ctx.callbackQuery.data.split('_')[1]
const m = tms.tmnumber[tm]
const move = dmoves[m]
const poks = Object.keys(pokemoves)
    .filter(pokemonName =>
      (pokemoves[pokemonName].moves_info || []).some(move => move.id === m)
    );
const data = await getUserData(ctx.from.id)
const pks = data.pokes.filter((poke)=>poks.includes(poke.name))
const buttonsPerRow = 5;
  let page = parseInt(ctx.callbackQuery.data.split('_')[3]) || 1
  const itemsPerPage = 20;
const totalPages = Math.ceil(pks.length / itemsPerPage);
if(page<1 || page > totalPages){
ctx.answerCbQuery('You Not Have Enough Pokes To Use This TM')
return
}
  const startIndex = (page - 1) * itemsPerPage;
  const endIndex = Math.min(startIndex + itemsPerPage, pks.length);
  const inlineKeyboard = [];
  let row = [];

for (let i = startIndex; i < endIndex; i++) {
  const sortedIndex = pks.indexOf(pks[i]);
  row.push({
    text: `${sortedIndex + 1}`,
    callback_data: `tundse_${tm}_${id}_${pks[i].pass}`,
  });

  if ((sortedIndex + 1) % buttonsPerRow === 0 || sortedIndex === endIndex - 1) {
    inlineKeyboard.push(row);
    row = [];
  }
}
if(page>1 || endIndex<pks.length){
const row2 = []
row2.push({text:'<',callback_data:'tmuse_'+tm+'_'+id+'_'+(page-1)+''})
row2.push({text:'>',callback_data:'tmuse_'+tm+'_'+id+'_'+(page+1)+''})
inlineKeyboard.push(row2)
}
if(totalPages > 10){
const row = []
row.push({text:'(-5) <<',callback_data:'tmuse_'+tm+'_'+id+'_'+(page-5)+'_'+ctx.from.id+''})
row.push({text:'>> (+5)',callback_data:'tmuse_'+tm+'_'+id+'_'+(page+5)+'_'+ctx.from.id+''})
inlineKeyboard.push(row)
}
if(totalPages > 40){
const row = []
row.push({text:'(-10) <<<',callback_data:'tmuse_'+tm+'_'+id+'_'+(page-10)+'_'+ctx.from.id+''})
row.push({text:'>>> (+10)',callback_data:'tmuse_'+tm+'_'+id+'_'+(page+10)+'_'+ctx.from.id+''})
inlineKeyboard.push(row)
}
if(totalPages > 100){
const row = []
row.push({text:'(-25) <<<<',callback_data:'tmuse_'+tm+'_'+id+'_'+(page-25)+'_'+ctx.from.id+''})
row.push({text:'>>>> (+25)',callback_data:'tmuse_'+tm+'_'+id+'_'+(page+25)+'_'+ctx.from.id+''})
inlineKeyboard.push(row)
}
  let messageText = `List Of Your Pokes (*Page ${page}*):\n\n`;
  for (let i = startIndex; i < endIndex; i++) {
    messageText += `*${i+ 1}.* *${c(pks[i].nickname || pks[i].name)}* ${pks[i].symbol} *(Lv.* ${plevel(pks[i].name,pks[i].exp)}*)*\n`;
  }
  messageText += '\n_Select Poke To Use_ *TM' + tm + '*';

  const keyboard = {
    inline_keyboard: inlineKeyboard,
  };
  ctx.editMessageText(messageText, { parse_mode: 'markdown', reply_markup: keyboard });
})
bot.action(/tundse_/,check2q,async ctx => {
const id = ctx.callbackQuery.data.split('_')[2]
if(ctx.from.id!=id){
return
}
const tm = ctx.callbackQuery.data.split('_')[1]
const m = tms.tmnumber[tm]
const pass = ctx.callbackQuery.data.split('_')[3]
const data = await getUserData(ctx.from.id)
const pk = data.pokes.filter((poke)=>poke.pass == pass)[0]
if(!pk){
ctx.answerCbQuery('You Not Have This Poke')
return
}
if(!data.tms){
data.tms={}
}
if(!data.tms[tm] || data.tms[tm] < 1){
ctx.answerCbQuery('You Does Not Have This TM')
return
}
if(pk.moves.length < 4){
let msg = 'Are You Sure To Your <b>'+c(pk.name)+'</b> (<b>Lv.</b> '+plevel(pk.name,pk.exp)+')'
const move2 = dmoves[String(m)]
msg += '\n\n<b>Learn New Move:</b>'
msg += '\n• <b>'+c(move2.name)+'</b> ['+c(move2.type)+' '+emojis[move2.type]+']\n<b>Power:</b> '+move2.power+'<b>, Accuracy:</b> '+move2.accuracy+' ('+c(move2.category.charAt(0))+')'
ctx.editMessageText(msg,{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'Confirm',callback_data:'lrtme_'+tm+'_'+id+'_'+pass+''},{text:'Cancel',callback_data:'crncl'}]]}})
}else{
let msg = '<b>Pokemon :</b> '+c(pk.name)+' (Lv. '+plevel(pk.name,pk.exp)+')\n\n'
const moves = []
for(const move2 of pk.moves){
let move = dmoves[move2]
msg += '• <b>'+c(move.name)+'</b> ['+c(move.type)+' '+emojis[move.type]+']\n<b>Power:</b> '+move.power+', <b>Accuracy:</b> '+move.accuracy+'% <i>('+c(move.category.charAt(0))+')</i>\n'
moves.push(move2)
}
msg += '\n<i>Which Move Should Be Forgotten?</i>'

const buttons = moves.map((word) => ({ text: c(dmoves[word].name), callback_data: 'frgtm_'+word+'_'+tm+'_'+id+'_'+pass+'' }));
  const rows = [];
  for (let i = 0; i < buttons.length; i += 2) {
    rows.push(buttons.slice(i, i + 2));
  }
ctx.editMessageText(msg,{parse_mode:'HTML',reply_markup:{inline_keyboard:rows}})
}
})
bot.action(/frgtm_/,check2q,async ctx => {
const id = ctx.callbackQuery.data.split('_')[3]
if(ctx.from.id!=id){
return
}
const tm = ctx.callbackQuery.data.split('_')[2]
const m = tms.tmnumber[tm]
const pass = ctx.callbackQuery.data.split('_')[4]
const data = await getUserData(ctx.from.id)
const move9 = ctx.callbackQuery.data.split('_')[1]
const pk = data.pokes.filter((poke)=>poke.pass == pass)[0]
if(!pk){
ctx.answerCbQuery('You Not Have This Poke')
return
}
if(!data.tms){
data.tms={}
}
if(!data.tms[tm] || data.tms[tm] < 1){
ctx.answerCbQuery('You Does Not Have This TM')
return
}
const poke = pk
let msg = 'Are You Sure To Your <b>'+c(poke.name)+'</b> (<b>Lv.</b> '+plevel(poke.name,poke.exp)+')\n\n'
msg += '<b>Forget The Move:</b>'
const move = dmoves[String(move9)]
const move2 = dmoves[String(m)]
msg += '\n• <b>'+c(move.name)+'</b> ['+c(move.type)+' '+emojis[move.type]+']\n<b>Power:</b> '+move.power+'<b>, Accuracy:</b> '+move.accuracy+' ('+c(move.category.charAt(0))+')'
msg += '\n\n<b>And Learn The Move:</b>'
msg += '\n• <b>'+c(move2.name)+'</b> ['+c(move2.type)+' '+emojis[move2.type]+']\n<b>Power:</b> '+move2.power+'<b>, Accuracy:</b> '+move2.accuracy+' ('+c(move2.category.charAt(0))+')'
ctx.editMessageText(msg,{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'Confirm',callback_data:'lrtme_'+tm+'_'+id+'_'+pass+'_'+move9+''},{text:'Cancel',callback_data:'crncl'}]]}})
})



bot.action(/lrtme_/,check2q,async ctx => {
const id = ctx.callbackQuery.data.split('_')[2]
if(ctx.from.id!=id){
return
}
const tm = ctx.callbackQuery.data.split('_')[1]
const m = tms.tmnumber[tm]
const pass = ctx.callbackQuery.data.split('_')[3]
const data = await getUserData(ctx.from.id)
const pk = data.pokes.filter((poke)=>poke.pass == pass)[0]
if(!pk){
ctx.answerCbQuery('You Not Have This Poke')
return
}
if(!data.tms){
data.tms={}
}
if(!data.tms[tm] || data.tms[tm] < 1){
ctx.answerCbQuery('You Does Not Have This TM')
return
}
if(pk.moves.length < 4){
pk.moves.push(m)
data.tms[tm] -= 1
await saveUserData(ctx.from.id,data)
ctx.editMessageText('*'+c(pk.name)+'* Learnt *'+c(dmoves[String(m)].name)+'* '+emojis[dmoves[String(m)].type]+'',{parse_mode:'markdown'})
}else{
const move = ctx.callbackQuery.data.split('_')[4]
if(!pk.moves.includes(parseInt(move))){
ctx.answerCbQuery('Your Poke Does Not Know This Move')
return
}
const index = pk.moves.indexOf(parseInt(move));

if (index !== -1) {
data.tms[tm] -= 1
  pk.moves[index] = parseInt(m);
await saveUserData(ctx.from.id,data)
ctx.editMessageText('*'+c(pk.name)+'* Has Learnt *'+c(dmoves[m].name)+'* '+emojis[dmoves[String(m)].type]+'',{parse_mode:'markdown'})
}
}
})



bot.action(/tmselly_/,async ctx => {
const id = ctx.callbackQuery.data.split('_')[3]
if(ctx.from.id!=id){
return
}
const price = ctx.callbackQuery.data.split('_')[2]
const tm = ctx.callbackQuery.data.split('_')[1]
ctx.editMessageText('Are You Sure To *Sell* *TM'+tm+'* For *'+price+'* PokeCoins 💷 ?',{parse_mode:'markdown',reply_markup:{inline_keyboard:[[{text:'Yes',callback_data:'tsejl_'+tm+'_'+price+'_'+id+''},{text:'Cancel',callback_data:'crncl'}]]}})
})
bot.action(/tsejl_/,async ctx => {
const id = ctx.callbackQuery.data.split('_')[3]
if(ctx.from.id!=id){
return
}
const price = ctx.callbackQuery.data.split('_')[2]*1
const tm = ctx.callbackQuery.data.split('_')[1]
const data = await getUserData(ctx.from.id)
if(!data.tms){
data.tms={}
}
if(!data.tms[tm] || data.tms[tm] < 1){
ctx.answerCbQuery('You Does Not Have This TM')
return
}
data.tms[tm] -= 1
data.inv.pc += price
await saveUserData(ctx.from.id,data)
ctx.editMessageText('Sold *TM'+tm+'* For *'+price+'* PokeCoins 💷',{parse_mode:'markdown'})
})
bot.command('challenge',check,async ctx => {
const data = await getUserData(ctx.from.id)
const reply = ctx.message.reply_to_message
if(!reply || reply.from.id==ctx.from.id){
ctx.replyWithMarkdown('Reply to a *User* to challenge them.',{reply_to_message_id:ctx.message.message_id})
return
}
const mdata = await loadMessageData();
if(mdata.battle.includes(ctx.from.id)){
ctx.replyWithMarkdown('You Are In A *Battle*',{reply_to_message_id:ctx.message.message_id})
return
}
if(mdata.battle.includes(reply.from.id)){
ctx.replyWithMarkdown('Opponent Is In A *Battle*',{reply_to_message_id:ctx.message.message_id})
return
}

const data2 = await getUserData(reply.from.id)
if(!data2.inv){
ctx.replyWithMarkdown('*Start your journey now*',{reply_to_message_id:reply.message_id,
reply_markup:{inline_keyboard:[[
{text:'Start My Journey',url:'t.me/PokePlayBot?start=start',}]]}})
return
}
if(!data.inv.team || data.inv.team == "" || data.teams[data.inv.team].length < 1){
ctx.replyWithMarkdown('Create your *Teams* first.',{reply_to_message_id:ctx.message.message_id})
return
}
if(!data2.inv.team || data2.inv.team == "" || data2.teams[data2.inv.team].length < 1){
ctx.replyWithMarkdown('Create your *Teams* first.',{reply_to_message_id:reply.message_id})
return
}
const challanger = he.encode(ctx.from.first_name)
const challanged = he.encode(reply.from.first_name)
ctx.replyWithHTML('⚔ <a href="tg://user?id='+ctx.from.id+'"><b>'+challanger+'</b></a> Has Challenged <a href="tg://user?id='+reply.from.id+'"><b>'+challanged+'</b></a>\n\n<a href="tg://user?id='+reply.from.id+'"><b>'+challanged+'</b></a> Do You Agree Or Reject?',{reply_to_message_id:reply.message_id,reply_markup:{inline_keyboard:[[{text:'Agree ✓',callback_data:'battle_'+ctx.from.id+'_'+reply.from.id+''},{text:'Reject ✗',callback_data:'reject_'+ctx.from.id+'_'+reply.from.id+''}]]}})
})
bot.action(/battle_/,async ctx => {
if (battlec[ctx.chat.id] && Date.now() - battlec[ctx.chat.id] < 1600) {

  ctx.answerCbQuery('Try Again');
  return;
}
battlec[ctx.chat.id] = Date.now();
const id1 = ctx.callbackQuery.data.split('_')[1]
const id2 = ctx.callbackQuery.data.split('_')[2]
if(ctx.from.id!=id2 && ctx.from.id!=id1){
ctx.answerCbQuery();
return
}
const mdata = await loadMessageData();
if(mdata.battle.includes(parseInt(id2))){
ctx.answerCbQuery('You Are In A Battle')
return
}
if(mdata.battle.includes(parseInt(id1))){
ctx.answerCbQuery('Opponent Is In A Battle')
return
}
if(ctx.from.id==id1){
ctx.answerCbQuery('Wait For Opponent To Accept')
return
}
if(ctx.from.id==id2){
const bword = word(10)
let battleData = {};
    try {
      battleData = JSON.parse(fs.readFileSync('./battle/'+bword+'.json', 'utf8'));
} catch (error) {
      battleData = {};
    }
const data = await getUserData(id1);
const data2 = await getUserData(id2);
const mdata = await loadMessageData();
if(mdata.battle.includes(parseInt(id2))){
ctx.answerCbQuery('You Are In A Battle')
return
}
if(mdata.battle.includes(parseInt(id1))){
ctx.answerCbQuery('Opponent Is In A Battle')
return
}
var la = {}
var tem = {}
let spe = {}
for(const p of data.teams[data.inv.team]){
const pk = data.pokes.filter((poke)=> poke.pass == p)
if(pk){
const base = pokestats[pk[0].name]
const clevel = plevel(pk[0].name,pk[0].exp)
const stats = await Stats(base,pk[0].ivs,pk[0].evs,c(pk[0].nature),clevel)
la[pk[0].pass] = clevel
tem[pk[0].pass] = stats.hp
spe[pk[0].pass] = stats.speed
}
}
var la2 = {}
var tem2 = {}
let spe2 = {}
for(const p of data2.teams[data2.inv.team]){
const pk = data2.pokes.filter((poke)=> poke.pass == p)
if(pk){
const base = pokestats[pk[0].name]
const clevel = plevel(pk[0].name,pk[0].exp)
const stats = await Stats(base,pk[0].ivs,pk[0].evs,c(pk[0].nature),clevel)
la2[pk[0].pass] = clevel
tem2[pk[0].pass] = stats.hp
spe2[pk[0].pass] = stats.speed
}
}

const user1poke = data.pokes.filter((poke)=>poke.pass==data.teams[data.inv.team][0])[0]
const user2poke = data2.pokes.filter((poke)=>poke.pass==data2.teams[data2.inv.team][0])[0]
const base1 = pokestats[user1poke.name]
const base2 = pokestats[user2poke.name]
const result = spe[Object.keys(spe)[0]] > spe2[Object.keys(spe2)[0]] ? Object.keys(spe)[0] : Object.keys(spe2)[0];
console.log(result)
if(result in tem){
battleData.c = Object.keys(tem)[0]
battleData.chp = tem[battleData.c]
battleData.o = Object.keys(tem2)[0]
battleData.ohp = tem2[battleData.o]
battleData.cid = id1
battleData.oid = id2
battleData.tem = tem
battleData.la = la
battleData.tem2 = tem2
battleData.la2 = la2
}else if(result in tem2){
battleData.c = Object.keys(tem2)[0]
battleData.chp = tem2[battleData.c]
battleData.o = Object.keys(tem)[0]
battleData.ohp = tem[battleData.o]
battleData.cid = id2
battleData.oid = id1
battleData.tem = tem2
battleData.la = la2
battleData.tem2 = tem
battleData.la2 = la
}
await fs.writeFileSync('./battle/' +bword+ '.json', JSON.stringify(battleData, null, 2));
const attacker = await getUserData(battleData.cid)
const defender = await getUserData(battleData.oid)
const p = attacker.pokes.filter((poke)=>poke.pass==battleData.c)[0]
const p2 = defender.pokes.filter((poke)=>poke.pass==battleData.o)[0]
const pp = pokes[p.name]
const pp2 = pokes[p2.name]
let msg = '<b>✦ The Pokomon battle commences!</b>'
msg += '\n\n<b>Opponent :</b> <a href="tg://user?id='+battleData.oid+'"><b>'+defender.inv.name+'</b></a>'
msg += '\n<b>'+c(p2.name)+'</b> ['+c(pp2.types.join(' / '))+']'
msg += '\n<b>Level :</b> '+plevel(p2.name,p2.exp)+' | <b>HP :</b> '+battleData.ohp+'/'+battleData.tem2[battleData.o]+''
msg += '\n<code>'+Bar(battleData.tem2[battleData.o],battleData.ohp)+'</code>'
msg += '\n\n<b>Turn :</b> <a href="tg://user?id='+battleData.cid+'"><b>'+attacker.inv.name+'</b></a>'
msg += '\n<b>'+c(p.name)+'</b> ['+c(pp.types.join(' / '))+']'
msg += '\n<b>Level :</b> '+plevel(p.name,p.exp)+' | <b>HP :</b> '+battleData.chp+'/'+battleData.tem[battleData.c]+''
msg += '\n<code>'+Bar(battleData.tem[battleData.c],battleData.chp)+'</code>'
msg += '\n\n<b>Moves :</b>'
const moves = []
let img = pp.front_default_image
const im = shiny.filter((poke)=>poke.name==p.name)[0]
if(im && p.symbol=='✨'){
img=im.shiny_url
}
for(const move2 of p.moves){
let move = dmoves[move2]
msg += '\n• <b>'+c(move.name)+'</b> ['+c(move.type)+' <a href="'+img+'">'+emojis[move.type]+'</a>]\n<b>Power:</b> '+move.power+'<b>, Accuracy:</b> '+move.accuracy+' ('+c(move.category.charAt(0))+')'
moves.push(''+move2+'')
}
const buttons = moves.map((word) => ({ text: c(dmoves[word].name), callback_data: 'multimo_'+word+'_'+bword+'_'+battleData.cid+'' }));
while(buttons.length < 4){
buttons.push({text:'  ',callback_data:'empty'})
}
  const rows = [];
  for (let i = 0; i < buttons.length; i += 2) {
    rows.push(buttons.slice(i, i + 2));
  }
const key2 = [{text:'Bag',callback_data:'multybg_'+bword+''},{text:'Escape',callback_data:'multryn_'+bword+'_multi'},{text:'Pokemon',callback_data:'multichanpok_'+bword+'_'+battleData.cid+''}]
const isstone = [...new Set(attacker.inv.stones)].filter(stone => stones[stone]?.pokemon === p.name)
if(isstone.length > 0 && Object.keys(attacker.extra.megas).length == 0 && attacker.inv.ring){
const rows5 = []
for(const i of isstone){
rows5.push({text:'Use '+c(i)+'',callback_data:'megtst_'+i+'_'+bword+''})
}
rows.push(rows5)
}
rows.push(key2)
  const keyboard = {
    inline_keyboard: rows
  };
ctx.editMessageText(msg,{parse_mode:'HTML',reply_markup:keyboard})
const messageData = await loadMessageData();
messageData.battle.push(parseInt(battleData.cid))
messageData.battle.push(parseInt(battleData.oid))
    messageData[bword] = { chat:ctx.chat.id,mid: ctx.callbackQuery.message.message_id, times: Date.now(), turn:battleData.cid, oppo:battleData.oid };
    await saveMessageData(messageData);
}
})

bot.action(/multimo_/,async ctx => {
if (battlec[ctx.chat.id] && Date.now() - battlec[ctx.chat.id] < 1600) {

  ctx.answerCbQuery('Try Again');
  return;
}
battlec[ctx.chat.id] = Date.now();
const moveid = ctx.callbackQuery.data.split('_')[1]
const bword = ctx.callbackQuery.data.split('_')[2]
const id = ctx.callbackQuery.data.split('_')[3]
if(ctx.from.id!=id){
ctx.answerCbQuery('Not Your Turn')
return
}
let battleData = {};
    try {
      battleData = JSON.parse(fs.readFileSync('./battle/'+bword+'.json', 'utf8'));
} catch (error) {
      battleData = {};
    }
const move = dmoves[moveid]
const data = await getUserData(battleData.cid)
const data2 = await getUserData(battleData.oid)
const p = data.pokes.filter((poke)=>poke.pass==battleData.c)[0]
const op = data2.pokes.filter((poke)=>poke.pass==battleData.o)[0]
const base1 = pokestats[p.name]
const base2 = pokestats[op.name]
const level1 = plevel(p.name,p.exp)
const level2 = plevel(op.name,op.exp)
const stats1 = await Stats(base1,p.ivs,p.evs,c(p.nature),level1)
const stats2 = await Stats(base2,op.ivs,op.evs,c(op.nature),level2)
let atk = stats1.attack
let def = stats1.defense
let atk2 = stats2.attack
let def2 = stats2.defense
const type1 = pokes[p.name].types[0]
const type2 = pokes[p.name].types[1] ? pokes[p.name].types[1] : null
const type3 = pokes[op.name].types[0]
const type4 = pokes[op.name].types[1] ? c(pokes[op.name].types[1]) : null
const eff1 = await eff(c(move.type),c(type3),type4)
if(move.category=='special'){
atk = stats1.special_attack
def = stats1.special_defense
atk2 = stats2.special_attack
def2 = stats2.special_defense
}
console.log(eff1,type3,type4)
if(Math.random()*100 > move.accuracy){
var msg2 = '➣ <b>'+c(p.name)+'</b> <b>'+c(move.name)+'</b> has missed.'
}else if(Math.random() < 0.05){
var msg2 = '➣ <b>'+c(op.name)+'</b> Dodged <b>'+c(p.name)+'</b>\'s <b>'+c(move.name)+'</b>'
}else{
var damage = Math.min(calc(atk,def2,level1,move.power,eff1),battleData.ohp)
battleData.ohp = Math.max((battleData.ohp-damage),0)
battleData.tem2[battleData.o] = Math.max((battleData.tem2[battleData.o]-damage),0)
var msg2 = '➣ <b>'+c(p.name)+'</b> used <b>'+c(move.name)+'</b> and dealt <code>'+damage+'</code> HP of <b>'+c(op.name)+'</b>'
}
let msg = msg2
await fs.writeFileSync('./battle/' +bword+ '.json', JSON.stringify(battleData, null, 2));
const cc = battleData.c
const cc2 = battleData.chp
const cc3 = battleData.cid
const cc4 = battleData.tem
const cc5 = battleData.la
battleData.c = battleData.o
battleData.chp = battleData.ohp
battleData.cid = battleData.oid
battleData.tem = battleData.tem2
battleData.la = battleData.la2
battleData.o = cc
battleData.ohp = cc2
battleData.oid = cc3
battleData.tem2 = cc4
battleData.la2 = cc5
await fs.writeFileSync('./battle/' +bword+ '.json', JSON.stringify(battleData, null, 2));

const attacker = await getUserData(battleData.cid)
const defender = await getUserData(battleData.oid)
const p1 = attacker.pokes.filter((poke)=>poke.pass==battleData.c)[0]
const p2 = defender.pokes.filter((poke)=>poke.pass==battleData.o)[0]
const pp = pokes[p1.name]
const pp2 = pokes[p2.name]
if(eff1 == 0){
msg += '\n<b>✶ It Have No Effect</b>'
}else if(eff1 == 0.5){
msg += '\n<b>✶ It Have Low Effect</b>'
}else if(eff1 == 2){
msg += '\n<b>✶ It\' Very Effective</b>'
}
msg += '\n\n<b>Opponent :</b> <a href="tg://user?id='+battleData.oid+'"><b>'+defender.inv.name+'</b></a>'
msg += '\n<b>'+c(p2.name)+'</b> ['+c(pp2.types.join(' / '))+']'
msg += '\n<b>Level :</b> '+plevel(p2.name,p2.exp)+' | <b>HP :</b> '+battleData.ohp+'/'+stats1.hp+''
msg += '\n<code>'+Bar(stats1.hp,battleData.ohp)+'</code>'
msg += '\n\n<b>Turn :</b> <a href="tg://user?id='+battleData.cid+'"><b>'+attacker.inv.name+'</b></a>'
msg += '\n<b>'+c(p1.name)+'</b> ['+c(pp.types.join(' / '))+']'
msg += '\n<b>Level :</b> '+plevel(p1.name,p1.exp)+' | <b>HP :</b> '+battleData.chp+'/'+stats2.hp+''
msg += '\n<code>'+Bar(stats2.hp,battleData.chp)+'</code>'
const messageData = await loadMessageData();
    messageData[bword] = { chat:ctx.chat.id,mid: ctx.callbackQuery.message.message_id, times: Date.now(),turn:battleData.cid,oppo:battleData.oid };

    await saveMessageData(messageData);
if(battleData.chp < 1){
msg += '\n\n<b>'+c(p1.name)+'</b> has fainted. Choose your next pokemon.'
await incexp(defender,p2,attacker,p1,ctx,battleData,bot)
await incexp2(attacker,p1,defender,p2,ctx,battleData,bot)
const av = []
const al = []
let b = 1
for(const pok in battleData.tem){
if(battleData.tem[pok] > 0){
const ppe = attacker.pokes.filter((poke)=>poke.pass == pok)[0]
av.push({name:b,pass:pok})
al.push(pok)
}else{
av.push({name:b+' (0 HP)',pass:pok})
}
b++;
}
if(al.length < 1){
const gpc = Object.keys(battleData.tem).length*15
defender.inv.pc += gpc
if(!defender.inv.win){
defender.inv.win = 0
}
defender.inv.win += 1
if(!attacker.inv.lose){
attacker.inv.lose = 0
}
attacker.inv.lose += 1
await saveUserData(battleData.cid,attacker)
await saveUserData(battleData.oid,defender)
const messageData = await loadMessageData();
messageData.battle = messageData.battle.filter((chats)=> chats!==parseInt(messageData[bword].turn) && chats!==parseInt(messageData[bword].oppo))
delete messageData[bword];
await saveMessageData(messageData);
ctx.editMessageText('<b>'+c(p1.name)+' </b>has fainted.\n<a href="tg://user?id='+battleData.cid+'"><b>'+attacker.inv.name+'</b></a> lost against <a href="tg://user?id='+battleData.oid+'"><b>'+defender.inv.name+'</b></a>.\n+'+gpc+' PokeCoins 💷',{parse_mode:'HTML'})
}else{
const buttons = av.map((poke) => ({ text: poke.name, callback_data: 'multidne_' + poke.pass + '_' + bword + '_'+battleData.cid+'_fainted' }));
while (buttons.length < 6) {
  buttons.push({ text: '  ', callback_data: 'empty' });
}
const rows = [[{text:'View Team',callback_data:'viewteam_'+battleData.cid+''}]];
for (let i = 0; i < buttons.length; i += 2) {
  rows.push(buttons.slice(i, i + 2));
}
ctx.editMessageText(msg,{parse_mode:'HTML',reply_markup:{inline_keyboard:rows}})
return
}
return
}
msg += '\n\n<b>Moves :</b>'
const moves = []
let img = pp.front_default_image
const im = shiny.filter((poke)=>poke.name==p1.name)[0]
if(im && p1.symbol=='✨'){
img=im.shiny_url
}
for(const move2 of p1.moves){
let move = dmoves[move2]
msg += '\n• <b>'+c(move.name)+'</b> ['+c(move.type)+' <a href="'+img+'">'+emojis[move.type]+'</a>]\n<b>Power:</b> '+move.power+'<b>, Accuracy:</b> '+move.accuracy+' ('+c(move.category.charAt(0))+')'
moves.push(''+move2+'')
}
const buttons = moves.map((word) => ({ text: c(dmoves[word].name), callback_data: 'multimo_'+word+'_'+bword+'_'+battleData.cid+'' }));
while(buttons.length < 4){
buttons.push({text:'  ',callback_data:'empty'})
}
  const rows = [];
  for (let i = 0; i < buttons.length; i += 2) {
    rows.push(buttons.slice(i, i + 2));
  }
const key2 = [{text:'Bag',callback_data:'multybg_'+bword+''},{text:'Escape',callback_data:'multryn_'+bword+'_multi'},{text:'Pokemon',callback_data:'multichanpok_'+bword+'_'+battleData.cid+''}]
if(!attacker.inv.stones){
attacker.inv.stones = []
}
const isstone = [...new Set(attacker.inv.stones)].filter(stone => stones[stone]?.pokemon === p1.name)
if(isstone.length > 0 && Object.keys(attacker.extra.megas).length == 0 && attacker.inv.ring){
const rows5 = []
for(const i of isstone){
rows5.push({text:'Use '+c(i)+'',callback_data:'megtst_'+i+'_'+bword+''})
}
rows.push(rows5)
}

rows.push(key2)
  const keyboard = {
    inline_keyboard: rows
  };
ctx.editMessageText(msg,{parse_mode:'HTML',reply_markup:keyboard})
})
bot.action(/multichanpok_/,async ctx => {
if (battlec[ctx.chat.id] && Date.now() - battlec[ctx.chat.id] < 1600) {

  ctx.answerCbQuery('Try Again');
  return;
}
battlec[ctx.chat.id] = Date.now();
const bword = ctx.callbackQuery.data.split('_')[1]
const id = ctx.callbackQuery.data.split('_')[2]
if(ctx.from.id!=id){
ctx.answerCbQuery('Not Your Turn')
return
}
let battleData = {};
    try {
      battleData = JSON.parse(fs.readFileSync('./battle/'+bword+'.json', 'utf8'));
} catch (error) {
      battleData = {};
    }
const attacker = await getUserData(battleData.cid)
const defender = await getUserData(battleData.oid)
const p1 = attacker.pokes.filter((poke)=>poke.pass==battleData.c)[0]
const p2 = defender.pokes.filter((poke)=>poke.pass==battleData.o)[0]
const pp = pokes[p1.name]
const pp2 = pokes[p2.name]
const base1 = pokestats[p2.name]
const base2 = pokestats[p1.name]
const level1 = plevel(p2.name,p2.exp)
const level2 = plevel(p1.name,p1.exp)
const stats1 = await Stats(base1,p2.ivs,p2.evs,c(p2.nature),level1)
const stats2 = await Stats(base2,p1.ivs,p1.evs,c(p1.nature),level2)
let msg = '\n\n<b>Opponent :</b> <a href="tg://user?id='+battleData.oid+'"><b>'+defender.inv.name+'</b></a>'
msg += '\n<b>'+c(p2.name)+'</b> ['+c(pp2.types.join(' / '))+']'
msg += '\n<b>Level :</b> '+plevel(p2.name,p2.exp)+' | <b>HP :</b> '+battleData.ohp+'/'+stats1.hp+''
msg += '\n<code>'+Bar(stats1.hp,battleData.ohp)+'</code>'
msg += '\n\n<b>Turn :</b> <a href="tg://user?id='+battleData.cid+'"><b>'+attacker.inv.name+'</b></a>'
msg += '\n<b>'+c(p1.name)+'</b> ['+c(pp.types.join(' / '))+']'
msg += '\n<b>Level :</b> '+plevel(p1.name,p1.exp)+' | <b>HP :</b> '+battleData.chp+'/'+stats2.hp+''
msg += '\n<code>'+Bar(stats2.hp,battleData.chp)+'</code>'
msg += '\n\n<i>Choose another pokemon for battle.</i>'
const av = []
let b = 1
let al = []
for(const pok in battleData.tem){
if(battleData.tem[pok] > 0){
const ppe = attacker.pokes.filter((poke)=>poke.pass == pok)[0]
av.push({name:b,pass:pok})
al.push(pok)
}else{
av.push({name:b+' (0 HP)',pass:pok})
}
b++;
}
const buttons = av.map((poke) => ({ text: poke.name, callback_data: 'multidne_' + poke.pass + '_' + bword + '_'+battleData.cid+'_change' }));
while (buttons.length < 6) {
  buttons.push({ text: '  ', callback_data: 'empty' });
}
const rows = [[{text:'View Team',callback_data:'viewteam_'+battleData.cid+''}]];
for (let i = 0; i < buttons.length; i += 2) {
  rows.push(buttons.slice(i, i + 2));
}
rows.push([{text:'⬅️ Back',callback_data:'multibttle_'+bword+'_'+battleData.cid+''}])
ctx.editMessageText(msg,{parse_mode:'HTML',reply_markup:{inline_keyboard:rows}})
})
bot.action(/multibttle_/,async ctx => {
if (battlec[ctx.chat.id] && Date.now() - battlec[ctx.chat.id] < 1600) {

  ctx.answerCbQuery('Try Again');
  return;
}
battlec[ctx.chat.id] = Date.now();
const bword = ctx.callbackQuery.data.split('_')[1]
const id = ctx.callbackQuery.data.split('_')[2]
if(ctx.from.id!=id){
ctx.answerCbQuery('Not Your Turn')
return
}
let battleData = {};
    try {
      battleData = JSON.parse(fs.readFileSync('./battle/'+bword+'.json', 'utf8'));
} catch (error) {
      battleData = {};
    }
const attacker = await getUserData(battleData.cid)
const defender = await getUserData(battleData.oid)
const p1 = attacker.pokes.filter((poke)=>poke.pass==battleData.c)[0]
const p2 = defender.pokes.filter((poke)=>poke.pass==battleData.o)[0]
const pp = pokes[p1.name]
const pp2 = pokes[p2.name]
const base1 = pokestats[p2.name]
const base2 = pokestats[p1.name]
const level1 = plevel(p2.name,p2.exp)
const level2 = plevel(p1.name,p1.exp)
const stats1 = await Stats(base1,p2.ivs,p2.evs,c(p2.nature),level1)
const stats2 = await Stats(base2,p1.ivs,p1.evs,c(p1.nature),level2)
let msg = '\n\n<b>Opponent :</b> <a href="tg://user?id='+battleData.oid+'"><b>'+defender.inv.name+'</b></a>'
msg += '\n<b>'+c(p2.name)+'</b> ['+c(pp2.types.join(' / '))+']'
msg += '\n<b>Level :</b> '+plevel(p2.name,p2.exp)+' | <b>HP :</b> '+battleData.ohp+'/'+stats1.hp+''
msg += '\n<code>'+Bar(stats1.hp,battleData.ohp)+'</code>'
msg += '\n\n<b>Turn :</b> <a href="tg://user?id='+battleData.cid+'"><b>'+attacker.inv.name+'</b></a>'
msg += '\n<b>'+c(p1.name)+'</b> ['+c(pp.types.join(' / '))+']'
msg += '\n<b>Level :</b> '+plevel(p1.name,p1.exp)+' | <b>HP :</b> '+battleData.chp+'/'+stats2.hp+''
msg += '\n<code>'+Bar(stats2.hp,battleData.chp)+'</code>'
msg += '\n\n<b>Moves :</b>'
const moves = []
let img = pp.front_default_image
const im = shiny.filter((poke)=>poke.name==p1.name)[0]
if(im && p1.symbol=='✨'){
img=im.shiny_url
}
for(const move2 of p1.moves){
let move = dmoves[move2]
msg += '\n• <b>'+c(move.name)+'</b> ['+c(move.type)+' <a href="'+img+'">'+emojis[move.type]+'</a>]\n<b>Power:</b> '+move.power+'<b>, Accuracy:</b> '+move.accuracy+' ('+c(move.category.charAt(0))+')'
moves.push(''+move2+'')
}
const buttons = moves.map((word) => ({ text: c(dmoves[word].name), callback_data: 'multimo_'+word+'_'+bword+'_'+battleData.cid+'' }));
while(buttons.length < 4){
buttons.push({text:'  ',callback_data:'empty'})
}
  const rows = [];
  for (let i = 0; i < buttons.length; i += 2) {
    rows.push(buttons.slice(i, i + 2));
  }
const key2 = [{text:'Bag',callback_data:'multybg_'+bword+''},{text:'Escape',callback_data:'multryn_'+bword+'_multi'},{text:'Pokemon',callback_data:'multichanpok_'+bword+'_'+battleData.cid+''}]
const isstone = [...new Set(attacker.inv.stones)].filter(stone => stones[stone]?.pokemon === p1.name)
if(isstone.length > 0 && Object.keys(attacker.extra.megas).length == 0 && attacker.inv.ring){
const rows5 = []
for(const i of isstone){
rows5.push({text:'Use '+c(i)+'',callback_data:'megtst_'+i+'_'+bword+''})
}
rows.push(rows5)
}
rows.push(key2)
  const keyboard = {
    inline_keyboard: rows
  };
ctx.editMessageText(msg,{parse_mode:'HTML',reply_markup:keyboard})
})
bot.action(/megtst_/,async ctx => {
if (battlec[ctx.chat.id] && Date.now() - battlec[ctx.chat.id] < 1600) {

  ctx.answerCbQuery('Try Again');
  return;
}
battlec[ctx.chat.id] = Date.now();
const stone5 = ctx.callbackQuery.data.split('_')[1]
const bword = ctx.callbackQuery.data.split('_')[2]
let battleData = {};
    try {
      battleData = JSON.parse(fs.readFileSync('./battle/'+bword+'.json', 'utf8'));
} catch (error) {
      battleData = {};
    }
if(ctx.from.id!=battleData.cid){
ctx.answerCbQuery('Not Your Turn')
return
}
const stone = stones[stone5]
const d2b = await getUserData(battleData.cid)
const pke = d2b.pokes.filter((pk)=>pk.pass == battleData.c)[0]
const n = pke.name
if(stone.pokemon!=pke.name){
console.log(pke.name)
return
}
if(!d2b.extra.megas){
d2b.extra.megas = {}
}
if(!battleData.megas){
battleData.megas = {}
}
battleData.megas[pke.pass] = pke.name
d2b.extra.megas[pke.pass] = pke.name
pke.name = stone.mega
await saveUserData(ctx.from.id,d2b)
const pass = battleData.c
const atta = await getUserData(battleData.cid)
const deffa = await getUserData(battleData.oid)
const p12 = atta.pokes.filter((poke)=>poke.pass==pass)[0]
let msg = '<b>'+c(p12.name)+'</b> has transformed into <b>'+c(stone.mega)+'</b>'
const p22 = deffa.pokes.filter((poke)=>poke.pass==battleData.o)[0]
const base12 = pokestats[p22.name]
const base22 = pokestats[p12.name]
const level12 = plevel(p22.name,p22.exp)
const level22 = plevel(p12.name,p12.exp)
const stats12 = await Stats(base12,p22.ivs,p22.evs,c(p22.nature),level12) 
const stats22 = await Stats(base22,p12.ivs,p12.evs,c(p12.nature),level22)
const result = stats12.speed > stats22.speed ? p22.pass : p12.pass
if(result in battleData.tem2){
const cc = battleData.c
const cc2 = battleData.chp
const cc3 = battleData.cid
const cc4 = battleData.tem
const cc5 = battleData.la
battleData.c = battleData.o
battleData.chp = battleData.ohp
battleData.cid = battleData.oid
battleData.tem = battleData.tem2
battleData.la = battleData.la2
battleData.o = cc
battleData.ohp = cc2
battleData.oid = cc3
battleData.tem2 = cc4
battleData.la2 = cc5
}
const dl = await getUserData(battleData.cid)
const p169 = dl.pokes.filter((poke)=>poke.pass==battleData.c)[0]
msg += '\n<b>'+c(p169.name)+'</b> <i>speed advantage allows to move first</i>'
await fs.writeFileSync('./battle/' +bword+ '.json', JSON.stringify(battleData, null, 2));
const attacker = await getUserData(battleData.cid)
const defender = await getUserData(battleData.oid)
const p1 = attacker.pokes.filter((poke)=>poke.pass==battleData.c)[0]
const p2 = defender.pokes.filter((poke)=>poke.pass==battleData.o)[0]
const pp = pokes[p1.name]
const pp2 = pokes[p2.name]
const base1 = pokestats[p2.name]
const base2 = pokestats[p1.name]
const level1 = plevel(p2.name,p2.exp)
const level2 = plevel(p1.name,p1.exp)
const stats1 = await Stats(base1,p2.ivs,p2.evs,c(p2.nature),level1)
const stats2 = await Stats(base2,p1.ivs,p1.evs,c(p1.nature),level2)
msg += '\n\n<b>Opponent :</b> <a href="tg://user?id='+battleData.oid+'"><b>'+defender.inv.name+'</b></a>'
msg += '\n<b>'+c(p2.name)+'</b> ['+c(pp2.types.join(' / '))+']'
msg += '\n<b>Level :</b> '+plevel(p2.name,p2.exp)+' | <b>HP :</b> '+battleData.ohp+'/'+stats1.hp+''
msg += '\n<code>'+Bar(stats1.hp,battleData.ohp)+'</code>'
msg += '\n\n<b>Turn :</b> <a href="tg://user?id='+battleData.cid+'"><b>'+attacker.inv.name+'</b></a>'
msg += '\n<b>'+c(p1.name)+'</b> ['+c(pp.types.join(' / '))+']'
msg += '\n<b>Level :</b> '+plevel(p1.name,p1.exp)+' | <b>HP :</b> '+battleData.chp+'/'+stats2.hp+''
msg += '\n<code>'+Bar(stats2.hp,battleData.chp)+'</code>'
msg += '\n\n<b>Moves :</b>'
const moves = []
let img = pp.front_default_image
const im = shiny.filter((poke)=>poke.name==p1.name)[0]
if(im && p1.symbol=='✨'){
img=im.shiny_url
}
for(const move2 of p1.moves){
let move = dmoves[move2]
msg += '\n• <b>'+c(move.name)+'</b> ['+c(move.type)+' <a href="'+img+'">'+emojis[move.type]+'</a>]\n<b>Power:</b> '+move.power+'<b>, Accuracy:</b> '+move.accuracy+' ('+c(move.category.charAt(0))+')'
moves.push(''+move2+'')
}
const buttons = moves.map((word) => ({ text: c(dmoves[word].name), callback_data: 'multimo_'+word+'_'+bword+'_'+battleData.cid+'' }));
while(buttons.length < 4){
buttons.push({text:'  ',callback_data:'empty'})
}
  const rows = [];
  for (let i = 0; i < buttons.length; i += 2) {
    rows.push(buttons.slice(i, i + 2));
  }
const key2 = [{text:'Bag',callback_data:'multybg_'+bword+''},{text:'Escape',callback_data:'multryn_'+bword+'_multi'},{text:'Pokemon',callback_data:'multichanpok_'+bword+'_'+battleData.cid+''}]
const isstone = [...new Set(attacker.inv.stones)].filter(stone => stones[stone]?.pokemon === p1.name)
if(isstone.length > 0 && Object.keys(attacker.extra.megas).length == 0 && attacker.inv.ring){
const rows5 = []
for(const i of isstone){
rows5.push({text:'Use '+c(i)+'',callback_data:'megtst_'+i+'_'+bword+''})
}
rows.push(rows5)
}
rows.push(key2)
  const keyboard = {
    inline_keyboard: rows
  };
const pk = pokes[stone.mega]
let img2 = pokes[p12.name].front_default_image
const im2 = shiny.filter((poke)=>poke.name==p12.name)[0]
if(im2 && p12.symbol=='✨'){
img2=im2.shiny_url
}
ctx.replyWithPhoto(img2,{caption:'*'+c(n)+'* has transformed into *'+c(pke.name)+'*.',parse_mode:'markdown',reply_to_message_id:ctx.callbackQuery.message.message_id})
ctx.editMessageText(msg,{parse_mode:'HTML',reply_markup:keyboard})
})

bot.action(/multidne_/,async ctx => {
if (battlec[ctx.chat.id] && Date.now() - battlec[ctx.chat.id] < 1600) {

  ctx.answerCbQuery('Try Again');
  return;
}
battlec[ctx.chat.id] = Date.now();
const pass = ctx.callbackQuery.data.split('_')[1]
const bword = ctx.callbackQuery.data.split('_')[2]
const id = ctx.callbackQuery.data.split('_')[3]
const prop = ctx.callbackQuery.data.split('_')[4]
if(ctx.from.id!=id){
ctx.answerCbQuery('Not Your Turn')
return
}
let battleData = {};
    try {
      battleData = JSON.parse(fs.readFileSync('./battle/'+bword+'.json', 'utf8'));
} catch (error) {
      battleData = {};
    }
if(battleData.tem[pass] < 1){
ctx.answerCbQuery('This Poke Is Ded')
return
}
if(battleData.c==pass){
ctx.answerCbQuery('This Poke Is Already Batteling')
return
}

battleData.c = pass
battleData.chp = battleData.tem[pass]
const atta = await getUserData(battleData.cid)
const deffa = await getUserData(battleData.oid)
const p12 = atta.pokes.filter((poke)=>poke.pass==pass)[0]
let msg = '<b>'+c(p12.name)+'</b> came for battle'
const p22 = deffa.pokes.filter((poke)=>poke.pass==battleData.o)[0]
const base12 = pokestats[p22.name]
const base22 = pokestats[p12.name]
const level12 = plevel(p22.name,p22.exp)
const level22 = plevel(p12.name,p12.exp)
const stats12 = await Stats(base12,p22.ivs,p22.evs,c(p22.nature),level12) 
const stats22 = await Stats(base22,p12.ivs,p12.evs,c(p12.nature),level22)
const result = stats12.speed > stats22.speed ? p22.pass : p12.pass
if(prop == 'fainted'){
if(result in battleData.tem2){
const cc = battleData.c
const cc2 = battleData.chp
const cc3 = battleData.cid
const cc4 = battleData.tem
const cc5 = battleData.la
battleData.c = battleData.o
battleData.chp = battleData.ohp
battleData.cid = battleData.oid
battleData.tem = battleData.tem2
battleData.la = battleData.la2
battleData.o = cc
battleData.ohp = cc2
battleData.oid = cc3
battleData.tem2 = cc4
battleData.la2 = cc5
}
const dl = await getUserData(battleData.cid)
const p169 = dl.pokes.filter((poke)=>poke.pass==battleData.c)[0]
msg += '\n<b>'+c(p169.name)+'</b> <i>speed advantage allows to move first</i>'
}
if(prop == 'change'){
const cc = battleData.c
const cc2 = battleData.chp
const cc3 = battleData.cid
const cc4 = battleData.tem
const cc5 = battleData.la
battleData.c = battleData.o
battleData.chp = battleData.ohp
battleData.cid = battleData.oid
battleData.tem = battleData.tem2
battleData.la = battleData.la2
battleData.o = cc
battleData.ohp = cc2
battleData.oid = cc3
battleData.tem2 = cc4
battleData.la2 = cc5
}
await fs.writeFileSync('./battle/' +bword+ '.json', JSON.stringify(battleData, null, 2));
const attacker = await getUserData(battleData.cid)
const defender = await getUserData(battleData.oid)
const p1 = attacker.pokes.filter((poke)=>poke.pass==battleData.c)[0]
const p2 = defender.pokes.filter((poke)=>poke.pass==battleData.o)[0]
const pp = pokes[p1.name]
const pp2 = pokes[p2.name]
const base1 = pokestats[p2.name]
const base2 = pokestats[p1.name]
const level1 = plevel(p2.name,p2.exp)
const level2 = plevel(p1.name,p1.exp)
const stats1 = await Stats(base1,p2.ivs,p2.evs,c(p2.nature),level1)
const stats2 = await Stats(base2,p1.ivs,p1.evs,c(p1.nature),level2)
msg += '\n\n<b>Opponent :</b> <a href="tg://user?id='+battleData.oid+'"><b>'+defender.inv.name+'</b></a>'
msg += '\n<b>'+c(p2.name)+'</b> ['+c(pp2.types.join(' / '))+']'
msg += '\n<b>Level :</b> '+plevel(p2.name,p2.exp)+' | <b>HP :</b> '+battleData.ohp+'/'+stats1.hp+''
msg += '\n<code>'+Bar(stats1.hp,battleData.ohp)+'</code>'
msg += '\n\n<b>Turn :</b> <a href="tg://user?id='+battleData.cid+'"><b>'+attacker.inv.name+'</b></a>'
msg += '\n<b>'+c(p1.name)+'</b> ['+c(pp.types.join(' / '))+']'
msg += '\n<b>Level :</b> '+plevel(p1.name,p1.exp)+' | <b>HP :</b> '+battleData.chp+'/'+stats2.hp+''
msg += '\n<code>'+Bar(stats2.hp,battleData.chp)+'</code>'
msg += '\n\n<b>Moves :</b>'
const moves = []
let img = pp.front_default_image
const im = shiny.filter((poke)=>poke.name==p1.name)[0]
if(im && p1.symbol=='✨'){
img=im.shiny_url
}
for(const move2 of p1.moves){
let move = dmoves[move2]
msg += '\n• <b>'+c(move.name)+'</b> ['+c(move.type)+' <a href="'+img+'">'+emojis[move.type]+'</a>]\n<b>Power:</b> '+move.power+'<b>, Accuracy:</b> '+move.accuracy+' ('+c(move.category.charAt(0))+')'
moves.push(''+move2+'')
}
const buttons = moves.map((word) => ({ text: c(dmoves[word].name), callback_data: 'multimo_'+word+'_'+bword+'_'+battleData.cid+'' }));
while(buttons.length < 4){
buttons.push({text:'  ',callback_data:'empty'})
}
  const rows = [];
  for (let i = 0; i < buttons.length; i += 2) {
    rows.push(buttons.slice(i, i + 2));
  }
const key2 = [{text:'Bag',callback_data:'multybg_'+bword+''},{text:'Escape',callback_data:'multryn_'+bword+'_multi'},{text:'Pokemon',callback_data:'multichanpok_'+bword+'_'+battleData.cid+''}]
const isstone = [...new Set(attacker.inv.stones)].filter(stone => stones[stone]?.pokemon === p1.name)
if(isstone.length > 0 && Object.keys(attacker.extra.megas).length == 0 && attacker.inv.ring){
const rows5 = []
for(const i of isstone){
rows5.push({text:'Use '+c(i)+'',callback_data:'megtst_'+i+'_'+bword+''})
}
rows.push(rows5)
}
rows.push(key2)
  const keyboard = {
    inline_keyboard: rows
  };
ctx.editMessageText(msg,{parse_mode:'HTML',reply_markup:keyboard})
})
bot.action(/reject_/,async ctx => {
const id1 = ctx.callbackQuery.data.split('_')[1]
const id2 = ctx.callbackQuery.data.split('_')[2]
if(ctx.from.id!=id2 && ctx.from.id!=id1){
ctx.answerCbQuery();
return
}
ctx.editMessageText('This challenge has been rejected by <a href="tg://user?id='+ctx.from.id+'"><b>'+he.encode(ctx.from.first_name)+'</b></a>',{parse_mode:'HTML'})
})
bot.action(/multryn_/,async ctx => {
if (battlec[ctx.chat.id] && Date.now() - battlec[ctx.chat.id] < 1600) {

  ctx.answerCbQuery('Try Again');
  return;
}
battlec[ctx.chat.id] = Date.now();
const bword = ctx.callbackQuery.data.split('_')[1]
let battleData = {};
    try {
      battleData = JSON.parse(fs.readFileSync('./battle/'+bword+'.json', 'utf8'));
} catch (error) {
      battleData = {};
    }
if(ctx.from.id!=battleData.cid && ctx.from.id!=battleData.oid){
ctx.answerCbQuery();
return
}
if(!battleData.runs){
battleData.runs = []
}
if(battleData.runs.includes(ctx.from.id)){
ctx.answerCbQuery('You Have Already Escapped Waiting For Opponent')
}else{
battleData.runs.push(ctx.from.id)
ctx.answerCbQuery('Waiting For Opponent To Run')
await fs.writeFileSync('./battle/' +bword+ '.json', JSON.stringify(battleData, null, 2));
}
if(battleData.runs.includes(parseInt(battleData.cid)) && battleData.runs.includes(parseInt(battleData.oid))){
ctx.editMessageText('Both Player Choosed To *Escape* Battle',{parse_mode:'markdown'})
const messageData = await loadMessageData();
messageData.battle = messageData.battle.filter((chats)=> chats!==parseInt(messageData[bword].turn) && chats!==parseInt(messageData[bword].oppo))
delete messageData[bword];
await saveMessageData(messageData);
}
})

async function editOverdueMessages() {
    const messageData = await loadMessageData();
for(const id in messageData.moves){
const time = messageData.moves[id].td
const queryTime = new Date(time)
const options = {
  timeZone: 'Asia/Kolkata',
  month: 'numeric',
  day: 'numeric',
  hour: 'numeric',
  minute: 'numeric',
  hour12: true,
};
const currentTime = new Date().toLocaleString('en-US', options)
const timeDifference = new Date(currentTime) - queryTime;
console.log(timeDifference)
if(timeDifference > 900000){
bot.telegram.editMessageText(messageData.moves[id].chat,id, null,'Unfortunately, Timeout For *15 Min* Has Over & *'+c(messageData.moves[id].poke)+'* Did Not Learnt *'+c(messageData.moves[id].move)+'*',{parse_mode:'markdown'})
delete messageData.moves[id]
await saveMessageData(messageData)
}
}

    Object.entries(messageData)
        .filter(([chatId, userMessageData]) =>
            (userMessageData.times && Date.now() - userMessageData.times > 90000) ||
            (userMessageData.timestamp && Date.now() - userMessageData.timestamp > 60000)
        )
        .map(async ([chatId, userMessageData]) => {
            if (userMessageData.times) {
                const { turn, oppo } = userMessageData;
                const d1 = await getUserData(turn);
                const d2 = await getUserData(oppo);

                const elapsedTime = Date.now() - userMessageData.times;

                if (elapsedTime > 90000) {
                    let newMessage = `<a href="tg://user?id=${turn}"><b>${d1.inv.name}</b></a> has not moved and losses <b>25</b> PokeCoins 💷.`;
                    newMessage += `\n<a href="tg://user?id=${oppo}"><b>${d2.inv.name}</b></a> <b>+25</b> PokeCoins 💷.`;

                    if (d1.inv.pc > 25) {
                        d1.inv.pc -= 25;
                    }

                    d2.inv.pc += 25;

                    await saveUserData(turn, d1);
                    await saveUserData(oppo, d2);
                    messageData.battle = messageData.battle.filter((chats) => chats !== parseInt(turn) && chats !== parseInt(oppo));
                    delete messageData[chatId];
await saveMessageData(messageData);
await bot.telegram.editMessageText(userMessageData.chat, userMessageData.mid, null, newMessage, {
                        parse_mode: 'HTML'
})
                }
            } else if (userMessageData.timestamp) {
                const elapsedTime = Date.now() - userMessageData.timestamp;

                if (elapsedTime > 60000) {
                    const newMessage = '*Timeover.*';
                    messageData.battle = messageData.battle.filter((chats) => chats !== userMessageData.id);
                    delete messageData[chatId];
                await saveMessageData(messageData);
await bot.telegram.editMessageText(chatId, userMessageData.mid, null, newMessage, {
                        parse_mode: 'markdown'
})
}
            }
        });

}

schedule.scheduleJob('*/2 * * * * *', editOverdueMessages);
bot.action(/viewteam_/,async ctx => {
const id = ctx.callbackQuery.data.split('_')[1]
if(id!=ctx.from.id){
ctx.answerCbQuery()
return
}
const data = await getUserData(ctx.from.id)
const te = data.teams[data.inv.team]
const a = await pokelist(te,ctx,0)
ctx.answerCbQuery(a.replace(/\*/g, ''),{show_alert:true})
})
bot.command('reset_battle',async ctx => {
const data = await loadMessageData()
if(data.battle.includes(ctx.from.id)){
for(const a in data){
if(data[a].times && (data[a].turn == ctx.from.id || data[a].oppo == ctx.from.id)){
ctx.replyWithMarkdown('Your One *Multiplayer Battle* Is Going On',{reply_to_message_id:ctx.message.message_id})
return
}
}
if(data[ctx.from.id]){
ctx.replyWithMarkdown('Your One *Hunt Battle* Is Going On',{reply_to_message_id:ctx.message.message_id})
return
}
data.battle = data.battle.filter((u)=>u!==ctx.from.id)
await saveMessageData(data)
ctx.replyWithMarkdown('Your *Battle Bug* Has Fixed.',{reply_to_message_id:ctx.message.message_id})
}else{
ctx.replyWithMarkdown('Your *Battle Bug* Doesn\'t Seems Active.',{reply_to_message_id:ctx.message.message_id})
}
})
bot.command('record',async ctx => {
if(ctx.from.id==ADMIN_ID){
  const userFiles = fs.readdirSync('./db');
ctx.replyWithMarkdown("Total *"+userFiles.length+"* Trainer Data Is Registered",{reply_to_message_id:ctx.message.message_id})
}
})
bot.command('trade',check,async ctx => {
const data = await getUserData(ctx.from.id)
const reply = ctx.message.reply_to_message
if(!reply || reply.from.id==ctx.from.id){
ctx.replyWithMarkdown('Reply to a *User* to trade pokemon with them.',{reply_to_message_id:ctx.message.message_id})
return
}
const mdata = await loadMessageData();
if(mdata.battle.includes(ctx.from.id)){
ctx.replyWithMarkdown('You Are In A *Battle*',{reply_to_message_id:ctx.message.message_id})
return
}
if(mdata.battle.includes(reply.from.id)){
ctx.replyWithMarkdown('Opponent Is In A *Battle*',{reply_to_message_id:ctx.message.message_id})
return
}

const data2 = await getUserData(reply.from.id)
if(!data2.inv){
ctx.replyWithMarkdown('*Start your journey now*',{reply_to_message_id:reply.message_id,
reply_markup:{inline_keyboard:[[
{text:'Start My Journey',url:'t.me/PokePlayBot?start=start',}]]}})
return
}
ctx.replyWithHTML('<a href="tg://user?id='+ctx.from.id+'"><b>'+data.inv.name+'</b></a> Wants To Trade A Pokemon With <a href = "tg://user?id='+reply.from.id+'"><b>'+data2.inv.name+'</b></a>.\n\n<a href = "tg://user?id='+reply.from.id+'"><b>'+data2.inv.name+'</b></a> do you accept it?',{reply_to_message_id:ctx.message.reply_to_message.message_id,reply_markup:{inline_keyboard:[[{text:'Accept',callback_data:'trade_'+ctx.from.id+'_'+reply.from.id+''},{text:'Decline',callback_data:'tradc_'+ctx.from.id+'_'+reply.from.id+''}]]}})
})
bot.action(/tradc_/,async ctx => {
const id1 = ctx.callbackQuery.data.split('_')[1]
const id2 = ctx.callbackQuery.data.split('_')[2]
if(ctx.from.id!=id1 && ctx.from.id!=id2){
ctx.answerCbQuery()
return
}
ctx.editMessageText('This trade has been cancelled by <a href = "tg://user?id='+ctx.from.id+'"><b>'+he.encode(ctx.from.first_name)+'</b></a>.',{parse_mode:'html'})
})
bot.action(/trade_/,async ctx => {
const id1 = ctx.callbackQuery.data.split('_')[1]
const id2 = ctx.callbackQuery.data.split('_')[2]
if(ctx.from.id!=id1 && ctx.from.id!=id2){
ctx.answerCbQuery()
return
}
if(ctx.from.id==id1){
ctx.answerCbQuery('You have already accepted')
return
}
if(ctx.from.id==id2){
const userData = await getUserData(id2)
let pokes = userData.pokes;
if(userData.inv.sort){
pokes = await sort(userData.pokes,userData.inv.sort)
}
  const buttonsPerRow = 5;
  let page = parseInt(ctx.callbackQuery.data.split('_')[3]) || 1
  const itemsPerPage = 20;
const totalPages = Math.ceil(userData.pokes.length / itemsPerPage);
if(page<1 || page > totalPages){
return
}
  const startIndex = (page - 1) * itemsPerPage;
  const endIndex = Math.min(startIndex + itemsPerPage, pokes.length);
  const inlineKeyboard = [];
  let row = [];

for (let i = startIndex; i < endIndex; i++) {
  const sortedIndex = userData.pokes.indexOf(pokes[i]);
  row.push({
    text: `${sortedIndex + 1}`,
    callback_data: `trdfe_${id2}_${userData.pokes[i].pass}_${id1}`,
  });

  if ((sortedIndex + 1) % buttonsPerRow === 0 || sortedIndex === endIndex - 1) {
    inlineKeyboard.push(row);
    row = [];
  }
}
if(page>1 || endIndex<pokes.length){
const row2 = []
row2.push({text:'<',callback_data:'trade_'+id1+'_'+id2+'_'+(page-1)+''})
row2.push({text:'>',callback_data:'trade_'+id1+'_'+id2+'_'+(page+1)+''})
inlineKeyboard.push(row2)
}
if(totalPages > 10){
const row = []
row.push({text:'(-5) <<',callback_data:'trade_'+id1+'_'+id2+'_'+(page-5)+'_'+ctx.from.id+''})
row.push({text:'>> (+5)',callback_data:'trade_'+id1+'_'+id2+'_'+(page+5)+'_'+ctx.from.id+''})
inlineKeyboard.push(row)
}
if(totalPages > 40){
const row = []
row.push({text:'(-10) <<<',callback_data:'trade_'+id1+'_'+id2+'_'+(page-10)+'_'+ctx.from.id+''})
row.push({text:'>>> (+10)',callback_data:'trade_'+id1+'_'+id2+'_'+(page+10)+'_'+ctx.from.id+''})
inlineKeyboard.push(row)
}
if(totalPages > 100){
const row = []
row.push({text:'(-25) <<<<',callback_data:'trade_'+id1+'_'+id2+'_'+(page-25)+'_'+ctx.from.id+''})
row.push({text:'>>>> (+25)',callback_data:'trade_'+id1+'_'+id2+'_'+(page+25)+'_'+ctx.from.id+''})
inlineKeyboard.push(row)
}
const data = await getUserData(id1)
const pk = pokes.slice(startIndex,endIndex)
  let messageText = '<a href = "tg://user?id='+id2+'"><b>'+userData.inv.name+'</b></a>\'s Pokemon List (Page: <b>'+page+'</b>)\n';
messageText += await pokelisthtml(pk.map(item => item.pass),id2,startIndex)
  messageText += '\n\n<b><u>❖ Select Which Poke Likes To Trade With</u></b> <a href = "tg://user?id='+id1+'"><b>'+data.inv.name+'</b></a>';

  const keyboard = {
    inline_keyboard: inlineKeyboard,
  };
  ctx.editMessageText(messageText, { parse_mode: 'html', reply_markup: keyboard });
}
});
bot.action(/trdfe_/,async ctx => {
const id1 = ctx.callbackQuery.data.split('_')[1]
const pass = ctx.callbackQuery.data.split('_')[2]
const id2 = ctx.callbackQuery.data.split('_')[3]
const page3 = ctx.callbackQuery.data.split('_')[4] || false
if(ctx.from.id!=id1 && ctx.from.id!=id2){
ctx.answerCbQuery()
return
}
if(ctx.from.id==id2 && !page3){
ctx.answerCbQuery('Wait, the other person didn\'t choosed his poke')
return
}
if((ctx.from.id==id1 && !page3) || (ctx.from.id==id2 && page3)){
const userData = await getUserData(id2)
let pokes = userData.pokes;
if(userData.inv.sort){
pokes = await sort(userData.pokes,userData.inv.sort)
}
  const buttonsPerRow = 5;
  let page = parseInt(ctx.callbackQuery.data.split('_')[4]) || 1
  const itemsPerPage = 20;
const totalPages = Math.ceil(userData.pokes.length / itemsPerPage);
if(page<1 || page > totalPages){
return
}
  const startIndex = (page - 1) * itemsPerPage;
  const endIndex = Math.min(startIndex + itemsPerPage, pokes.length);
  const inlineKeyboard = [];
  let row = [];

for (let i = startIndex; i < endIndex; i++) {
  const sortedIndex = userData.pokes.indexOf(pokes[i]);
  row.push({
    text: `${sortedIndex + 1}`,
    callback_data: `trfe_${id1}_${pass}_${id2}_${userData.pokes[i].pass}`,
  });

  if ((sortedIndex + 1) % buttonsPerRow === 0 || sortedIndex === endIndex - 1) {
    inlineKeyboard.push(row);
    row = [];
  }
}
if(page>1 || endIndex<pokes.length){
const row2 = []
row2.push({text:'<',callback_data:'trdfe_'+id1+'_'+pass+'_'+id2+'_'+(page-1)+''})
row2.push({text:'>',callback_data:'trdfe_'+id1+'_'+pass+'_'+id2+'_'+(page+1)+''})
inlineKeyboard.push(row2)
}
if(totalPages > 10){
const row = []
row.push({text:'(-5) <<',callback_data:'trdfe_'+id1+'_'+pass+'_'+id2+'_'+(page-5)+'_'+ctx.from.id+''})
row.push({text:'>> (+5)',callback_data:'trdfe_'+id1+'_'+pass+'_'+id2+'_'+(page+5)+'_'+ctx.from.id+''})
inlineKeyboard.push(row)
}
if(totalPages > 40){
const row = []
row.push({text:'(-10) <<<',callback_data:'trdfe_'+id1+'_'+pass+'_'+id2+'_'+(page-10)+'_'+ctx.from.id+''})
row.push({text:'>>> (+10)',callback_data:'trdfe_'+id1+'_'+pass+'_'+id2+'_'+(page+10)+'_'+ctx.from.id+''})
inlineKeyboard.push(row)
}
if(totalPages > 100){
const row = []
row.push({text:'(-25) <<<<',callback_data:'trdfe_'+id1+'_'+pass+'_'+id2+'_'+(page-25)+'_'+ctx.from.id+''})
row.push({text:'>>>> (+25)',callback_data:'trdfe_'+id1+'_'+pass+'_'+id2+'_'+(page+25)+'_'+ctx.from.id+''})
inlineKeyboard.push(row)
}
const data = await getUserData(id1)
const pk = pokes.slice(startIndex,endIndex)
  let messageText = '<a href = "tg://user?id='+id2+'"><b>'+userData.inv.name+'</b></a>\'s Pokemon List (Page: <b>'+page+'</b>)\n';
messageText += await pokelisthtml(pk.map(item => item.pass),id2,startIndex)
  messageText += '\n\n<b><u>❖ Select Which Poke Likes To Trade With</u></b> <a href = "tg://user?id='+id1+'"><b>'+data.inv.name+'</b></a>';

  const keyboard = {
    inline_keyboard: inlineKeyboard,
  };
  ctx.editMessageText(messageText, { parse_mode: 'html', reply_markup: keyboard });
}
});
bot.action(/trfe_/,async ctx => {
const id1 = ctx.callbackQuery.data.split('_')[1]
const pass1 = ctx.callbackQuery.data.split('_')[2]
const id2 = ctx.callbackQuery.data.split('_')[3]
const pass2 = ctx.callbackQuery.data.split('_')[4]
if(ctx.from.id!=id1 && ctx.from.id!=id2){
ctx.answerCbQuery()
return
}
if(ctx.from.id==id1){
ctx.answerCbQuery('Wait, other player is choosing poke to trade')
return
}
if(ctx.from.id==id2){
const data1 = await getUserData(id1)
const data2 = await getUserData(id2)
const poke = data1.pokes.filter((p)=>p.pass==pass1)[0]
const poke2 = data2.pokes.filter((p)=>p.pass==pass2)[0]
if(!poke2){
ctx.answerCbQuery('You does not have this poke anymore')
return
}
if(!poke){
ctx.editMessageText('<a href="tg://user?id='+id1+'"><b>'+data1.inv.name+'</b></a> does not have that poke anymore',{parse_mode:'html'})
return
}
let msg = '<a href="tg://user?id='+id1+'"><b>'+data1.inv.name+'</b></a> wants to trade:\n'
msg += '<b>'+c(poke.name)+'</b> - '+c(poke.nature)+' | <b>Lv.</b> '+plevel(poke.name,poke.exp)+'\n'
const ivs = poke.ivs
const evs = poke.evs
let ivsText = ''
    ivsText += '\nStats          IV |  EV\n';
    ivsText += '————————————————————————\n';
    ivsText += `HP              ${ivs.hp.toString().padStart(2)} |  ${evs.hp}\n`;
    ivsText += `Attack          ${ivs.attack.toString().padStart(2)} |  ${evs.attack}\n`;
    ivsText += `Defense         ${ivs.defense.toString().padStart(2)} |  ${evs.defense}\n`;
    ivsText += `Sp. Attack      ${ivs.special_attack.toString().padStart(2)} |  ${evs.special_attack}\n`;
    ivsText += `Sp. Defense     ${ivs.special_defense.toString().padStart(2)} |  ${evs.special_defense}\n`;
    ivsText += `Speed           ${ivs.speed.toString().padStart(2)} |  ${evs.speed}\n`;
    ivsText += '————————————————————————\n';
    ivsText += `Total           ${calculateTotal(ivs)} |  ${calculateTotal(evs)}\n\n`;
msg += '<code>'+ivsText+'</code>'

msg += '<a href="tg://user?id='+id2+'"><b>'+data2.inv.name+'</b></a> wants to trade:\n'
msg += '<b>'+c(poke2.name)+'</b> - '+c(poke2.nature)+' | <b>Lv.</b> '+plevel(poke2.name,poke2.exp)+'\n'
const ivs2 = poke2.ivs
const evs2 = poke2.evs
let ivsText2 = ''
    ivsText2 += '\nStats          IV |  EV\n';
    ivsText2 += '————————————————————————\n';
    ivsText2 += `HP              ${ivs2.hp.toString().padStart(2)} |  ${evs2.hp}\n`;
    ivsText2 += `Attack          ${ivs2.attack.toString().padStart(2)} |  ${evs2.attack}\n`;
    ivsText2 += `Defense         ${ivs2.defense.toString().padStart(2)} |  ${evs2.defense}\n`;
    ivsText2 += `Sp. Attack      ${ivs2.special_attack.toString().padStart(2)} |  ${evs2.special_attack}\n`;
    ivsText2 += `Sp. Defense     ${ivs2.special_defense.toString().padStart(2)} |  ${evs2.special_defense}\n`;
    ivsText2 += `Speed           ${ivs2.speed.toString().padStart(2)} |  ${evs2.speed}\n`;
    ivsText2 += '————————————————————————\n';
    ivsText2 += `Total           ${calculateTotal(ivs2)} |  ${calculateTotal(evs2)}\n\n`;
msg += '<code>'+ivsText2+'</code>'
msg += '<b>Both players have to accept the trade</b>'
ctx.editMessageText(msg,{parse_mode:'html',reply_markup:{inline_keyboard:[[{text:'Agree',callback_data:'agtr_'+id1+'n_'+pass1+'_'+id2+'n_'+pass2+''},{text:'Decline',callback_data:'tradc_'+id1+'_'+id2+''}]]}})
}
})
bot.action(/agtr_/,async ctx => {
const id1 = ctx.callbackQuery.data.split('_')[1]
const pass1 = ctx.callbackQuery.data.split('_')[2]
const id2 = ctx.callbackQuery.data.split('_')[3]
const pass2 = ctx.callbackQuery.data.split('_')[4]
const callback = ctx.callbackQuery.data
if(ctx.from.id+'n'!=id1 && ctx.from.id+'y'!=id1 && ctx.from.id+'y'!=id2 && ctx.from.id+'n'!=id2){
ctx.answerCbQuery()
return
}
if(callback.includes(ctx.from.id+'n')){
ctx.editMessageReplyMarkup({inline_keyboard:[[{text:'Agree',callback_data:callback.replace(ctx.from.id+'n',ctx.from.id+'y')},{text:'Decline',callback_data:'tradc_'+id1.replace(/[ny]/g,'')+'_'+id2.replace(/[ny]/g,'')+''}]]})
ctx.answerCbQuery('You Have Accepted The Trade')
}
await sleep(700)
const cl = callback.replace(ctx.from.id+'n',ctx.from.id+'y')
const id3 = cl.split('_')[1]
const id4 = cl.split('_')[3]
if(!id3.includes('n') && !id4.includes('n')){
const data1 = await getUserData(id1.replace(/[ny]/g,''))
const data2 = await getUserData(id2.replace(/[ny]/g,''))
const poke = data1.pokes.filter((p)=>p.pass==pass1)[0]
const poke2 = data2.pokes.filter((p)=>p.pass==pass2)[0]
if(!poke){
ctx.editMessageText('<a href="tg://user?id='+id1.replace(/[ny]/g,'')+'"><b>'+data1.inv.name+'</b></a> does not have the choosen poke any more.',{parse_mode:'html'})
return
}
if(!poke2){
ctx.editMessageText('<a href="tg://user?id='+id2.replace(/[ny]/g,'')+'"><b>'+data2.inv.name+'</b></a> does not have the choosen poke any more.',{parse_mode:'html'})
return
}
const mdata = await loadMessageData()
if(mdata.battle.includes(parseInt(id1)) || mdata.battle.includes(parseInt(id2))){
if(mdata.battle.includes(ctx.from.id)){
ctx.answerCbQuery('You Are In A Battle')
}else{
ctx.answerCbQuery('Another User Is In A Battle')
}
return
}


const ind1 = data1.pokes.findIndex((pk)=>pk.pass==pass1)
const ind2 = data2.pokes.findIndex((pk)=>pk.pass==pass2)
if(ind1!==-1){
const r = spawn[poke2.name].toLowerCase()
if(r=='common' || r=='medium'){
var fee = 50
}
if(r=='rare'){
var fee = 100
}
if(r=='legendry' || r=='legendary'){
var fee = 200
}
if(r=='mythical'){
var fee = 250
}
if(!fee){
var fee = 100
}
if(data1.inv.pc < fee){
ctx.answerCbQuery('Both Users Does Not Have Suffecient Fee To Pay')
return
}
data1.inv.pc -= fee
data1.pokes[ind1] = poke2
}
if(ind2 !== -1){
const r = spawn[poke.name].toLowerCase()
if(r=='common' || r=='medium'){
var fee2 = 50
}
if(r=='rare'){
var fee2 = 100
}
if(r=='legendry' || r=='legendary'){
var fee2 = 200
}
if(r=='mythical'){
var fee2 = 250
}
if(!fee2){
var fee2 = 100
}
if(data2.inv.pc < fee2){
ctx.answerCbQuery('Both Users Does Not Have Suffecient Fee To Pay')
return
}
data2.inv.pc -= fee2
data2.pokes[ind2] = poke
}
await saveUserData(id2.replace(/[ny]/g,''),data2)
await saveUserData(id1.replace(/[ny]/g,''),data1)
ctx.editMessageText('<b>Trade Has Been Completed</b>\n\n• <a href="tg://user?id='+id1.replace(/[ny]/g,'')+'"><b>'+data1.inv.name+'</b></a> Receives <b>'+c(poke2.name)+'</b> & Paid <b>'+fee+' 💷</b>\n\n• <a href="tg://user?id='+id2.replace(/[ny]/g,'')+'"><b>'+data2.inv.name+'</b></a> Receives <b>'+c(poke.name)+'</b> & Paid <b>'+fee2+' 💷</b>',{parse_mode:'html'})
bot.telegram.sendMessage(5432006093,'#trade\n\n<b>'+he.encode(data1.inv.name)+'</b> (<code>'+id1+'</code>) has traded <b>'+c(poke.name)+'</b> with <b>'+data2.inv.name+'</b> (<code>'+id2+'</code>) <b>'+c(poke2.name)+' </b>',{parse_mode:'HTML'})
}
if(callback.includes(ctx.from.id+'y')){
ctx.answerCbQuery('You Have Already Accepted The Trade.')
return
}
})
const admins = [ADMIN_ID]
requireAdminId(admins,'admins')
bot.command('add',async ctx => {
if(!admins.includes(ctx.from.id)){
return
}
const poke = ctx.message.text.split(' ')[1]
const level = ctx.message.text.split(' ')[2];
const reply = ctx.message.reply_to_message
if(!poke || !level || !reply){
ctx.replyWithMarkdown('*Wrong Format*')

return}
const data = await getUserData(reply.from.id)
if(poke=='stone'){
const st = stones[level]
if(!st){
ctx.replyWithMarkdown('*n/a*')
return
}
if(!data.inv.stones){
data.inv.stones=[]
}
data.inv.stones.push(level)
await saveUserData(reply.from.id,data)
ctx.replyWithMarkdown('Successfully Added *'+c(level)+'*')
return
}
  const pokeName = poke.toLowerCase()
  const poked = pokes[pokeName]
  if (!poked) {
    ctx.replyWithMarkdown('n/a');
    return;
  }

const moves = pokemoves[pokeName]
if(!moves){
ctx.replyWithMarkdown('*This Poke Not Available*')
return
}
const moves2 = moves.moves_info.filter((move)=> move.learn_method == 'level-up' && move.level_learned_at < level*1 && dmoves[move.id].power && dmoves[move.id].accuracy)
const am = Math.min(Math.max(moves2.length,1),4)
const omoves = moves2.slice(-am)
const ms = []
for(const m of omoves){
ms.push(m.id)
}
  const iv = {
"hp":stat(pokeName),
"attack":stat(pokeName),
"defense":stat(pokeName),
"special_attack":stat(pokeName),
"special_defense":stat(pokeName),
"speed":stat(pokeName)
}

  const ev = {
"hp":0,
"attack":0,
"defense":0,
"special_attack":0,
"special_defense":0,
"speed":0
};
const pass2 = word(8)
const nat = getRandomNature()
const g = growth_rates[pokeName]
const exp = chart[g.growth_rate][level]
  const da = {
    name:pokeName,
    id: poked.pokedex_number,
    nature:nat,
    exp:exp,
    pass:pass2,
    ivs: iv,
    symbol: '',
    evs: ev,
    moves: ms, // Push the randomly selected move ID
  };
if(!data.pokes){
data.pokes = []
}
data.pokes.push(da)
await saveUserData(reply.from.id,data)
ctx.replyWithMarkdown('Successfully Added *'+c(poke)+'*')
});
bot.command('candy',check2,async ctx => {
const data = await getUserData(ctx.from.id)
if(!data.inv){
ctx.replyWithMarkdown('*Start your journey now*',{reply_to_message_id:ctx.message.message_id,
reply_markup:{inline_keyboard:[[
{text:'Start My Journey',url:'t.me/PokePlayBot?start=start',}]]}})
return
}
const name = ctx.message.text.split(' ').slice(1).join(' ')
if(!name){
ctx.replyWithMarkdown('*Please tell which pokemon candy you want to give.*',{reply_to_message_id:ctx.message.message_id})
return
}
const name2 = name.replace(/ /g,'-')
const p = pokes[name2.toLowerCase()]
if(!p){
const matches = stringSimilarity.findBestMatch(name2, data.pokes.map(poke => poke.name));
        const bestMatch = matches.bestMatch.target;
        const similarity = matches.bestMatch.rating;
if(similarity > 0.4 && name2.length > 3){
ctx.replyWithMarkdown('Did you mean : *'+c(bestMatch)+'*?',{reply_to_message_id:ctx.message.message_id,reply_markup:{
inline_keyboard:[[{text:'Yes',callback_data:'suger_'+ctx.from.id+'_'+bestMatch+'_candy_'+ctx.message.message_id+''},
{text:'No',callback_data:'delete_'+ctx.from.id+''}]]}})
}else{
ctx.replyWithMarkdown('*Wrong Name*',{reply_to_message_id:ctx.message.message_id})
}
return
}
const p22 = data.pokes.filter((poke)=> (poke.name==name2.toLowerCase()) || (poke.nickname && poke.nickname.toLowerCase() == name2.toLowerCase()))
if(!p22 || p22.length < 1){
ctx.replyWithMarkdown('You Does Not Have *'+name+'*',{reply_to_message_id:ctx.message.message_id})
return
}
if(p22.length == 1){
const p2 = p22[0]
const g = growth_rates[p2.name]
const exp = chart[g.growth_rate]
const matchingLevels = Object.keys(exp).filter(level => p2.exp >= exp[level]);
    const currentLevel = matchingLevels.length > 0 ? parseInt(matchingLevels[matchingLevels.length - 1]) : undefined;
if(!data.inv.candy){
data.inv.candy = 0
}
if(data.inv.candy < 1){
ctx.replyWithMarkdown('You are out of *Candies 🍬*')
return
}
if(currentLevel > 99){
ctx.replyWithMarkdown('*'+c(name2)+'* has already reached *100* level',{reply_to_message_id:ctx.message.message_id})
return
}
data.inv.candy -= 1
p2.exp = exp[currentLevel+1]
await saveUserData(ctx.from.id,data)
ctx.replyWithMarkdown('You gave 1 candy 🍬 to *'+c(p2.name)+'*\n*Level:* '+currentLevel+' --> '+(currentLevel+1)+'',{reply_to_message_id:ctx.message.message_id,reply_markup:{inline_keyboard:[[{text:'+1 Candy 🍬',callback_data:'candy_'+p2.pass+'_'+ctx.from.id+''}]]}})
const evo = chains.evolution_chains.filter((chain)=>chain.current_pokemon==p2.name)[0]
if(evo && evo.evolution_level && evo.evolution_method == 'level-up' && evo.evolution_level <= (currentLevel+1) && evo.evolution_level > currentLevel){
if(ctx.chat.type!='private'){
ctx.replyWithHTML('<a href="tg://user?id='+ctx.from.id+'"><b>'+data.inv.name+'</b></a> Your Pokemon <b>'+c(p2.name)+'</b> Is Ready To Evolve',{reply_markup:{inline_keyboard:[[{text:'Evolve',url:'t.me/pokeplaybot'}]]}})
}
bot.telegram.sendMessage(ctx.from.id,'*'+c(p2.name)+'* Is Ready To Evolve',{parse_mode:'markdown',reply_markup:{inline_keyboard:[[{text:'Evolve',callback_data:'evy_'+p2.name+'_'+p2.pass+''}]]}})
}
if(((currentLevel+1)-currentLevel)!= 0){
const moves = pokemoves[p2.name]
const moves2 = moves.moves_info.filter((move)=> move.learn_method == 'level-up' && move.level_learned_at > currentLevel && move.level_learned_at <= (currentLevel+1) && dmoves[move.id].power && dmoves[move.id].accuracy && dmoves[move.id].category != 'status')
if(moves2.length > 0){
for(const m of moves2){
if(p2.moves.length < 4){
p2.moves.push(m.id)
await saveUserData(ctx.from.id,data)
bot.telegram.sendMessage(ctx.from.id,'<b>'+c(p2.name)+'</b> (<b>Lv.</b> '+(currentLevel+1)+') Has Learnt A New Move <b>'+c(dmoves[m.id].name)+'</b> ['+c(dmoves[m.id].type)+' '+emojis[dmoves[m.id].type]+'].',{parse_mode:'HTML'})
}else{
const options = {
  timeZone: 'Asia/Kolkata',
  month: 'numeric',
  day: 'numeric',
  hour: 'numeric',
  minute: 'numeric',
  hour12: true,
};

const d = new Date().toLocaleString('en-US', options)
if(ctx.chat.type!='private'){
ctx.replyWithHTML('<a href="tg://user?id='+ctx.from.id+'"><b>'+data.inv.name+'</b></a>, <b>'+c(p2.name)+'</b> (<b>Lv.</b> '+(currentLevel+1)+') Wants To Learn A New Move',{reply_markup:{inline_keyboard:[[{text:'Go',url:'t.me/pokeplaybot'}]]}})
}
const mdata = await loadMessageData();
const m77 = await bot.telegram.sendMessage(ctx.from.id,'<b>'+c(p2.name)+'</b> (<b>Lv.</b> '+(currentLevel+1)+') Wants To Learn A New Move <b>'+c(dmoves[m.id].name)+'</b> ['+c(dmoves[m.id].type)+' '+emojis[dmoves[m.id].type]+'].\n\nBut <b>'+c(p2.name)+'</b> Already Knows 4 Moves He Have To Forget One Move To Learn <b>'+c(dmoves[m.id].name)+'</b>\n<i>You Have 15 Min To Choose.</i>',{reply_markup:{inline_keyboard:[[{text:'Go Next',callback_data:'lrn_'+p2.pass+'_'+m.id+'_'+d+''}]]},parse_mode:'HTML'})
if(!mdata.moves){
mdata.moves = {}
}
mdata.moves[m77.message_id] = {chat:ctx.from.id,td:d,poke:p2.name,move:dmoves[m.id].name}
await saveMessageData(mdata)
}
}
}
}
await saveUserData(ctx.from.id,data)
}else if(p22.length > 1){
const ore = []
let message = ''
const page = 1
const pageSize = 25
const startIdx = (page - 1) * pageSize;
let b = startIdx+1
const endIdx = startIdx + pageSize;
const pokemon = p22.slice(startIdx,endIdx)
message += await pokelist(pokemon.map(item => item.pass),ctx,startIdx)
for(const p of pokemon){
ore.push({text:b,callback_data:'candy_'+p.pass+'_'+ctx.from.id+'_'+ctx.message.message_id+''})
b++;
}
  const rows = [];
  for (let i = 0; i < ore.length; i += 5) {
    rows.push(ore.slice(i, i + 5));
  }
const rows2 = []
if(page > 1){
rows2.push({text:'<',callback_data:'suger_'+ctx.from.id+'_'+name2+'_candy_'+ctx.message.message_id+'_'+(page-1)+''})
}
console.log(endIdx)
if((endIdx+1)<p22.length){
rows2.push({text:'>',callback_data:'suger_'+ctx.from.id+'_'+name2+'_candy_'+ctx.message.message_id+'_'+(page+1)+''})
}
rows.push(rows2)
ctx.replyWithMarkdown(message+'\n\n_Give Candy To Which Pokemon?_',{reply_to_message_id:ctx.message.message_id,reply_markup:{inline_keyboard:rows}})
}
})
bot.command('evolve',check2,async ctx => {
const data = await getUserData(ctx.from.id)
if(!data.inv){
ctx.replyWithMarkdown('*Start your journey now*',{reply_to_message_id:ctx.message.message_id,
reply_markup:{inline_keyboard:[[
{text:'Start My Journey',url:'t.me/PokePlayBot?start=start',}]]}})
return
}
const name = ctx.message.text.split(' ').slice(1).join(' ')
if(!name){
ctx.replyWithMarkdown('*Please tell which pokemon you wanna evolve.*',{reply_to_message_id:ctx.message.message_id})
return
}
const name2 = name.replace(/ /g,'-')
const p = pokes[name2.toLowerCase()]
if(!p){
const matches = stringSimilarity.findBestMatch(name2, data.pokes.map(poke => poke.name));
        const bestMatch = matches.bestMatch.target;
        const similarity = matches.bestMatch.rating;
if(similarity > 0.4 && name2.length > 3){
ctx.replyWithMarkdown('Did you mean : *'+c(bestMatch)+'*?',{reply_to_message_id:ctx.message.message_id,reply_markup:{
inline_keyboard:[[{text:'Yes',callback_data:'suger_'+ctx.from.id+'_'+bestMatch+'_evolve_'+ctx.message.message_id+''},
{text:'No',callback_data:'delete_'+ctx.from.id+''}]]}})
}else{
ctx.replyWithMarkdown('*Wrong Name*',{reply_to_message_id:ctx.message.message_id})
}
return
}
const p22 = data.pokes.filter((poke)=> (poke.name==name2.toLowerCase()) || (poke.nickname && poke.nickname.toLowerCase() == name2.toLowerCase()))
if(!p22 || p22.length < 1){
ctx.replyWithMarkdown('You Does Not Have *'+name+'*',{reply_to_message_id:ctx.message.message_id})
return
}
if(p22.length == 1){
const p2 = p22[0]
const g = growth_rates[p2.name]
const exp = chart[g.growth_rate]
const matchingLevels = Object.keys(exp).filter(level => p2.exp >= exp[level]);
    const currentLevel = matchingLevels.length > 0 ? parseInt(matchingLevels[matchingLevels.length - 1]) : undefined;
const evo = chains.evolution_chains.filter((chain)=>chain.current_pokemon==p2.name)[0]
if(!evo){
ctx.replyWithMarkdown('*'+c(p2.name)+'* does not evolve further',{reply_to_message_id:ctx.message.message_id})
return
}
if(evo && evo.evolution_level && evo.evolution_method == 'level-up' && evo.evolution_level <= currentLevel){
ctx.replyWithMarkdown('Are You Sure To Evolve Your *'+c(p2.name)+'* (*Lv.* '+currentLevel+')',{reply_to_message_id:ctx.message.message_id,
reply_markup:{inline_keyboard:[[{text:'Evolve',callback_data:'evy_'+p2.name+'_'+p2.pass+'_'+ctx.from.id+'_'+ctx.message.message_id+''},
{text:'Cancel',callback_data:'delete_'+ctx.from.id+''}]]}})
}else{
ctx.replyWithMarkdown('Your *'+c(p2.name)+'* Does Not Match With Requirements To *Evolve*',{reply_to_message_id:ctx.message.message_id})
}

}else if(p22.length > 1){
const ore = []
let message = ''
const page = 1
const pageSize = 25
const startIdx = (page - 1) * pageSize;
let b = startIdx+1
const endIdx = startIdx + pageSize;
const pokemon = p22.slice(startIdx,endIdx)
message += await pokelist(pokemon.map(item => item.pass),ctx,startIdx)
for(const p of pokemon){
ore.push({text:b,callback_data:'evy_'+p.name+'_'+p.pass+'_'+ctx.from.id+'_'+ctx.message.message_id+''})
b++;
}
  const rows = [];
  for (let i = 0; i < ore.length; i += 5) {
    rows.push(ore.slice(i, i + 5));
  }
const rows2 = []
if(page > 1){
rows2.push({text:'<',callback_data:'suger_'+ctx.from.id+'_'+name2+'_evolve_'+ctx.message.message_id+'_'+(page-1)+''})
}
console.log(endIdx)
if((endIdx+1)<p22.length){
rows2.push({text:'>',callback_data:'suger_'+ctx.from.id+'_'+name2+'_evolve_'+ctx.message.message_id+'_'+(page+1)+''})
}
rows.push(rows2)
ctx.replyWithMarkdown(message+'\n\n_Wanna Evolve To Which Pokemon?_',{reply_to_message_id:ctx.message.message_id,reply_markup:{inline_keyboard:rows}})
}
})
bot.action(/evolve_/,check2q,async ctx => {
const pass = ctx.callbackQuery.data.split('_')[1]
const id = ctx.callbackQuery.data.split('_')[2]
const data = await getUserData(ctx.from.id)
const poke = data.pokes.filter((p)=>p.pass===pass)[0]
if(id!=ctx.from.id){
ctx.answerCbQuery()
return
}
if(!poke){
ctx.answerCbQuery('Poke not found')
return
}
const p2 = poke
const g = growth_rates[p2.name]
const exp = chart[g.growth_rate]
const matchingLevels = Object.keys(exp).filter(level => p2.exp >= exp[level]);
    const currentLevel = matchingLevels.length > 0 ? parseInt(matchingLevels[matchingLevels.length - 1]) : undefined;
const evo = chains.evolution_chains.filter((chain)=>chain.current_pokemon==p2.name)[0]
if(!evo){
ctx.editMessageText('*'+c(p2.name)+'* does not evolve further',{parse_mode:'markdown'})
return
}
if(evo && evo.evolution_level && evo.evolution_method == 'level-up' && evo.evolution_level <= currentLevel){
ctx.editMessageText('Are You Sure To Evolve Your *'+c(p2.name)+'* (*Lv.* '+currentLevel+')',{reply_markup:{inline_keyboard:[[{text:'Evolve',callback_data:'evy_'+p2.name+'_'+p2.pass+'_'+ctx.from.id+''},{text:'Cancel',callback_data:'delete_'+ctx.from.id+''}]]},parse_mode:'markdown'})
}else{
ctx.editMessageText('Your *'+c(p2.name)+'* Does Not Match With Requirements To *Evolve*',{parse_mode:'markdown'})
}
})
bot.action(/candy_/,check2q,async ctx => {
const pass = ctx.callbackQuery.data.split('_')[1]
const id = ctx.callbackQuery.data.split('_')[2]
const data = await getUserData(ctx.from.id)
const poke = data.pokes.filter((p)=>p.pass===pass)[0]
if(id!=ctx.from.id){
ctx.answerCbQuery()
return
}
if(!poke){
ctx.answerCbQuery('Poke not found')
return
}
const p2 = poke
const g = growth_rates[p2.name]
const exp = chart[g.growth_rate]
const matchingLevels = Object.keys(exp).filter(level => p2.exp >= exp[level]);
    const currentLevel = matchingLevels.length > 0 ? parseInt(matchingLevels[matchingLevels.length - 1]) : undefined;
if(!data.inv.candy){
data.inv.candy = 0
}
if(data.inv.candy < 1){
ctx.editMessageText('You are out of *Candies 🍬*',{parse_mode:'markdown'})
return
}
if(currentLevel*1 > 99){
ctx.editMessageText('*'+c(p2.name)+'* has already reached *100* level',{parse_mode:'markdown'})
return
}
data.inv.candy -= 1
p2.exp = exp[currentLevel+1]
await saveUserData(ctx.from.id,data)
ctx.editMessageText('You gave 1 candy 🍬 to *'+c(p2.name)+'*\n*Level:* '+currentLevel+' --> '+(currentLevel+1)+'',{parse_mode:'markdown',reply_markup:{inline_keyboard:[[{text:'+1 Candy 🍬',callback_data:'candy_'+p2.pass+'_'+ctx.from.id+''}]]}})
const evo = chains.evolution_chains.filter((chain)=>chain.current_pokemon==p2.name)[0]
if(evo && evo.evolution_level && evo.evolution_method == 'level-up' && evo.evolution_level <= (currentLevel+1) && evo.evolution_level > currentLevel){
if(ctx.chat.type!='private'){
ctx.replyWithHTML('<a href="tg://user?id='+ctx.from.id+'"><b>'+data.inv.name+'</b></a> Your Pokemon <b>'+c(p2.name)+'</b> Is Ready To Evolve',{reply_markup:{inline_keyboard:[[{text:'Evolve',url:'t.me/pokeplaybot'}]]}})
}
bot.telegram.sendMessage(ctx.from.id,'*'+c(p2.name)+'* Is Ready To Evolve',{parse_mode:'markdown',reply_markup:{inline_keyboard:[[{text:'Evolve',callback_data:'evy_'+p2.name+'_'+p2.pass+''}]]}})
}
if(((currentLevel+1)-currentLevel)!= 0){
const moves = pokemoves[p2.name]
const moves2 = moves.moves_info.filter((move)=> move.learn_method == 'level-up' && move.level_learned_at > currentLevel && move.level_learned_at <= (currentLevel+1) && dmoves[move.id].power && dmoves[move.id].accuracy && dmoves[move.id].category != 'status')
if(moves2.length > 0){
for(const m of moves2){
if(p2.moves.length < 4){
p2.moves.push(m.id)
await saveUserData(ctx.from.id,data)
bot.telegram.sendMessage(ctx.from.id,'<b>'+c(p2.name)+'</b> (<b>Lv.</b> '+(currentLevel+1)+') Has Learnt A New Move <b>'+c(dmoves[m.id].name)+'</b> ['+c(dmoves[m.id].type)+' '+emojis[dmoves[m.id].type]+'].',{parse_mode:'HTML'})
}else{
const options = {
  timeZone: 'Asia/Kolkata',
  month: 'numeric',
  day: 'numeric',
  hour: 'numeric',
  minute: 'numeric',
  hour12: true,
};

const d = new Date().toLocaleString('en-US', options)
if(ctx.chat.type!='private'){
ctx.replyWithHTML('<a href="tg://user?id='+ctx.from.id+'"><b>'+data.inv.name+'</b></a>, <b>'+c(p2.name)+'</b> (<b>Lv.</b> '+(currentLevel+1)+') Wants To Learn A New Move',{reply_markup:{inline_keyboard:[[{text:'Go',url:'t.me/pokeplaybot'}]]}})
}
const mdata = await loadMessageData();
const m77 = await bot.telegram.sendMessage(ctx.from.id,'<b>'+c(p2.name)+'</b> (<b>Lv.</b> '+(currentLevel+1)+') Wants To Learn A New Move <b>'+c(dmoves[m.id].name)+'</b> ['+c(dmoves[m.id].type)+' '+emojis[dmoves[m.id].type]+'].\n\nBut <b>'+c(p2.name)+'</b> Already Knows 4 Moves He Have To Forget One Move To Learn <b>'+c(dmoves[m.id].name)+'</b>\n<i>You Have 15 Min To Choose.</i>',{reply_markup:{inline_keyboard:[[{text:'Go Next',callback_data:'lrn_'+p2.pass+'_'+m.id+'_'+d+''}]]},parse_mode:'HTML'})
if(!mdata.moves){
mdata.moves = {}
}
mdata.moves[m77.message_id] = {chat:ctx.from.id,td:d,poke:p2.name,move:dmoves[m.id].name}
await saveMessageData(mdata)
}
}
}
}
await saveUserData(ctx.from.id,data)
})

bot.command('vitamin',async ctx => {
const data = await getUserData(ctx.from.id)
if(!data.inv){
ctx.replyWithMarkdown('*Start your journey now*',{reply_to_message_id:ctx.message.message_id,
reply_markup:{inline_keyboard:[[
{text:'Start My Journey',url:'t.me/PokePlayBot?start=start',}]]}})
return
}
const name = ctx.message.text.split(' ').slice(1).join(' ')
if(!name){
ctx.replyWithMarkdown('*Please tell which pokemon vitamin you want to give.*',{reply_to_message_id:ctx.message.message_id})
return
}
const name2 = name.replace(/ /g,'-')
const p = pokes[name2.toLowerCase()]
if(!p){
const matches = stringSimilarity.findBestMatch(name2, data.pokes.map(poke => poke.name));
        const bestMatch = matches.bestMatch.target;
        const similarity = matches.bestMatch.rating;
if(similarity > 0.4 && name2.length > 3){
ctx.replyWithMarkdown('Did you mean : *'+c(bestMatch)+'*?',{reply_to_message_id:ctx.message.message_id,reply_markup:{
inline_keyboard:[[{text:'Yes',callback_data:'suger_'+ctx.from.id+'_'+bestMatch+'_vitamin_'+ctx.message.message_id+''},
{text:'No',callback_data:'delete_'+ctx.from.id+''}]]}})
}else{
ctx.replyWithMarkdown('*Wrong Name*',{reply_to_message_id:ctx.message.message_id})
}
return
}
const p22 = data.pokes.filter((poke)=> (poke.name==name2.toLowerCase()) || (poke.nickname && poke.nickname.toLowerCase() == name2.toLowerCase()))
if(!p22 || p22.length < 1){
ctx.replyWithMarkdown('You Does Not Have *'+name+'*',{reply_to_message_id:ctx.message.message_id})
return
}
if(p22.length == 1){
const p2 = p22[0]
const g = growth_rates[p2.name]
const exp = chart[g.growth_rate]
const matchingLevels = Object.keys(exp).filter(level => p2.exp >= exp[level]);
    const currentLevel = matchingLevels.length > 0 ? parseInt(matchingLevels[matchingLevels.length - 1]) : undefined;
if(!data.inv.vitamin){
data.inv.vitamin = 0
}
if(data.inv.vitamin < 1){
ctx.replyWithMarkdown('You are out of *💉 Vitamins*')
return
}
let msg6 = '*Pokemon:* '+c(p2.name)+' (*Lv.* '+plevel(p2.name,p2.exp)+')\n\n'
msg6 += '*HP :* '+p2.evs.hp+'\n'
msg6 += '*Attack :* '+p2.evs.attack+'\n'
msg6 += '*Defense :* '+p2.evs.defense+'\n'
msg6 += '*Special Attack :* '+p2.evs.special_attack+'\n'
msg6 += '*Special Defense :* '+p2.evs.special_defense+'\n'
msg6 += '*Speed :* '+p2.evs.speed+'\n'
msg6 += '\nWhich EV Stat You Wanna Increase With *10*?'
const key = [
[{text:'HP',callback_data:'vitye-hp-'+p2.pass+'-'+ctx.from.id+''},
{text:'Attack',callback_data:'vitye-attack-'+p2.pass+'-'+ctx.from.id+''},
{text:'Defense',callback_data:'vitye-defense-'+p2.pass+'-'+ctx.from.id+''}],
[{text:'SpA',callback_data:'vitye-special_attack-'+p2.pass+'-'+ctx.from.id+''},
{text:'SpD',callback_data:'vitye-special_defense-'+p2.pass+'-'+ctx.from.id+''},
{text:'Speed',callback_data:'vitye-speed-'+p2.pass+'-'+ctx.from.id+''}]
]
ctx.replyWithMarkdown(msg6,{reply_to_message_id:ctx.message.message_id,reply_markup:{inline_keyboard:key}})
}else if(p22.length > 1){
const ore = []
let message = ''
const page = 1
const pageSize = 25
const startIdx = (page - 1) * pageSize;
let b = startIdx+1
const endIdx = startIdx + pageSize;
const pokemon = p22.slice(startIdx,endIdx)
message += await pokelist(pokemon.map(item => item.pass),ctx,startIdx)
for(const p of pokemon){
ore.push({text:b,callback_data:'vitamin_'+p.pass+'_'+ctx.from.id+'_'+ctx.message.message_id+''})
b++;
}
  const rows = [];
  for (let i = 0; i < ore.length; i += 5) {
    rows.push(ore.slice(i, i + 5));
  }
const rows2 = []
if(page > 1){
rows2.push({text:'<',callback_data:'suger_'+ctx.from.id+'_'+name2+'_vitamin_'+ctx.message.message_id+'_'+(page-1)+''})
}
console.log(endIdx)
if((endIdx+1)<p22.length){
rows2.push({text:'>',callback_data:'suger_'+ctx.from.id+'_'+name2+'_vitamin_'+ctx.message.message_id+'_'+(page+1)+''})
}
rows.push(rows2)
ctx.replyWithMarkdown(message+'\n\n_Give Vitamin To Which Pokemon?_',{reply_to_message_id:ctx.message.message_id,reply_markup:{inline_keyboard:rows}})
}
})
bot.action(/vitamin_/,check2q,async ctx => {
const pass = ctx.callbackQuery.data.split('_')[1]
const id = ctx.callbackQuery.data.split('_')[2]
const data = await getUserData(ctx.from.id)
const poke = data.pokes.filter((p)=>p.pass===pass)[0]
if(id!=ctx.from.id){
ctx.answerCbQuery()
return
}
if(!poke){
ctx.answerCbQuery('Poke not found')
return
}
const p2 = poke
let msg6 = '*Pokemon:* '+c(p2.name)+' (*Lv.* '+plevel(p2.name,p2.exp)+')\n\n'
msg6 += '*HP :* '+p2.evs.hp+'\n'
msg6 += '*Attack :* '+p2.evs.attack+'\n'
msg6 += '*Defense :* '+p2.evs.defense+'\n'
msg6 += '*Special Attack :* '+p2.evs.special_attack+'\n'
msg6 += '*Special Defense :* '+p2.evs.special_defense+'\n'
msg6 += '*Speed :* '+p2.evs.speed+'\n'
msg6 += '\nWhich EV Stat You Wanna Increase With *10*?'
const key = [
[{text:'HP',callback_data:'vitye-hp-'+p2.pass+'-'+ctx.from.id+''},
{text:'Attack',callback_data:'vitye-attack-'+p2.pass+'-'+ctx.from.id+''},
{text:'Defense',callback_data:'vitye-defense-'+p2.pass+'-'+ctx.from.id+''}],
[{text:'SpA',callback_data:'vitye-special_attack-'+p2.pass+'-'+ctx.from.id+''},
{text:'SpD',callback_data:'vitye-special_defense-'+p2.pass+'-'+ctx.from.id+''},
{text:'Speed',callback_data:'vitye-speed-'+p2.pass+'-'+ctx.from.id+''}]
]
ctx.editMessageText(msg6,{parse_mode:'markdown',reply_markup:{inline_keyboard:key}})
})
bot.action(/vitye-/,check2q,async ctx => {
const stat = ctx.callbackQuery.data.split('-')[1]
const pass = ctx.callbackQuery.data.split('-')[2]
const id = ctx.callbackQuery.data.split('-')[3]
const data = await getUserData(ctx.from.id)
const poke = data.pokes.filter((p)=>p.pass===pass)[0]
if(id!=ctx.from.id){
ctx.answerCbQuery()
return
}
if(!poke){
ctx.answerCbQuery('Poke not found')
return
}
const p2 = poke
if(!data.inv.vitamin){
data.inv.vitamin = 0
}
if(data.inv.vitamin < 1){
ctx.answerCbQuery('You are out of *💉 Vitamins*')
return
}
data.inv.vitamin -= 1
if(p2.evs[stat] > 251){
ctx.answerCbQuery('This Stat Has Already Reached Max Limit')
return
}
const c7 = await calculateTotal(p2.evs)
if(c7 > 509){
ctx.answerCbQuery('This Poke Total Evs Maximum Limit Reached')
return
}
const a = Math.min(10,(252-p2.evs[stat]))
const a2 = Math.min(a,(510-calculateTotal(p2.evs)))
p2.evs[stat] += a2
await saveUserData(ctx.from.id,data)
let msg6 = '*Pokemon:* '+c(p2.name)+' (*Lv.* '+plevel(p2.name,p2.exp)+')\n\n'
msg6 += '*HP :* '+p2.evs.hp+'\n'
msg6 += '*Attack :* '+p2.evs.attack+'\n'
msg6 += '*Defense :* '+p2.evs.defense+'\n'
msg6 += '*Special Attack :* '+p2.evs.special_attack+'\n'
msg6 += '*Special Defense :* '+p2.evs.special_defense+'\n'
msg6 += '*Speed :* '+p2.evs.speed+'\n'
msg6 += '\nWhich EV Stat You Wanna Increase With *10*?'
const key = [
[{text:'HP',callback_data:'vitye-hp-'+p2.pass+'-'+ctx.from.id+''},
{text:'Attack',callback_data:'vitye-attack-'+p2.pass+'-'+ctx.from.id+''},
{text:'Defense',callback_data:'vitye-defense-'+p2.pass+'-'+ctx.from.id+''}],
[{text:'SpA',callback_data:'vitye-special_attack-'+p2.pass+'-'+ctx.from.id+''},
{text:'SpD',callback_data:'vitye-special_defense-'+p2.pass+'-'+ctx.from.id+''},
{text:'Speed',callback_data:'vitye-speed-'+p2.pass+'-'+ctx.from.id+''}]
]
ctx.editMessageText(msg6,{parse_mode:'markdown',reply_markup:{inline_keyboard:key}})
})
bot.command('berry',async ctx => {
const data = await getUserData(ctx.from.id)
if(!data.inv){
ctx.replyWithMarkdown('*Start your journey now*',{reply_to_message_id:ctx.message.message_id,
reply_markup:{inline_keyboard:[[
{text:'Start My Journey',url:'t.me/PokePlayBot?start=start',}]]}})
return
}
const name = ctx.message.text.split(' ').slice(1).join(' ')
if(!name){
ctx.replyWithMarkdown('*Please tell which pokemon berry you want to give.*',{reply_to_message_id:ctx.message.message_id})
return
}
const name2 = name.replace(/ /g,'-')
const p = pokes[name2.toLowerCase()]
if(!p){
const matches = stringSimilarity.findBestMatch(name2, data.pokes.map(poke => poke.name));
        const bestMatch = matches.bestMatch.target;
        const similarity = matches.bestMatch.rating;
if(similarity > 0.4 && name2.length > 3){
ctx.replyWithMarkdown('Did you mean : *'+c(bestMatch)+'*?',{reply_to_message_id:ctx.message.message_id,reply_markup:{
inline_keyboard:[[{text:'Yes',callback_data:'suger_'+ctx.from.id+'_'+bestMatch+'_berry_'+ctx.message.message_id+''},
{text:'No',callback_data:'delete_'+ctx.from.id+''}]]}})
}else{
ctx.replyWithMarkdown('*Wrong Name*',{reply_to_message_id:ctx.message.message_id})
}
return
}
const p22 = data.pokes.filter((poke)=> (poke.name==name2.toLowerCase()) || (poke.nickname && poke.nickname.toLowerCase() == name2.toLowerCase()))
if(!p22 || p22.length < 1){
ctx.replyWithMarkdown('You Does Not Have *'+name+'*',{reply_to_message_id:ctx.message.message_id})
return
}
if(p22.length == 1){
const p2 = p22[0]
const g = growth_rates[p2.name]
const exp = chart[g.growth_rate]
const matchingLevels = Object.keys(exp).filter(level => p2.exp >= exp[level]);
    const currentLevel = matchingLevels.length > 0 ? parseInt(matchingLevels[matchingLevels.length - 1]) : undefined;
if(!data.inv.berry){
data.inv.berry = 0
}
if(data.inv.berry < 1){
ctx.replyWithMarkdown('You are out of *🍒 Berries*')
return
}
let msg6 = '*Pokemon:* '+c(p2.name)+' (*Lv.* '+plevel(p2.name,p2.exp)+')\n\n'
msg6 += '*HP :* '+p2.evs.hp+'\n'
msg6 += '*Attack :* '+p2.evs.attack+'\n'
msg6 += '*Defense :* '+p2.evs.defense+'\n'
msg6 += '*Special Attack :* '+p2.evs.special_attack+'\n'
msg6 += '*Special Defense :* '+p2.evs.special_defense+'\n'
msg6 += '*Speed :* '+p2.evs.speed+'\n'
msg6 += '\nWhich EV Stat You Wanna Decrease With *10*?'
const key = [
[{text:'HP',callback_data:'brth-hp-'+p2.pass+'-'+ctx.from.id+''},
{text:'Attack',callback_data:'brth-attack-'+p2.pass+'-'+ctx.from.id+''},
{text:'Defense',callback_data:'brth-defense-'+p2.pass+'-'+ctx.from.id+''}],
[{text:'SpA',callback_data:'brth-special_attack-'+p2.pass+'-'+ctx.from.id+''},
{text:'SpD',callback_data:'brth-special_defense-'+p2.pass+'-'+ctx.from.id+''},
{text:'Speed',callback_data:'brth-speed-'+p2.pass+'-'+ctx.from.id+''}]
]
ctx.replyWithMarkdown(msg6,{reply_to_message_id:ctx.message.message_id,reply_markup:{inline_keyboard:key}})
}else if(p22.length > 1){
const ore = []
let message = ''
const page = 1
const pageSize = 25
const startIdx = (page - 1) * pageSize;
let b = startIdx+1
const endIdx = startIdx + pageSize;
const pokemon = p22.slice(startIdx,endIdx)
message += await pokelist(pokemon.map(item => item.pass),ctx,startIdx)
for(const p of pokemon){
ore.push({text:b,callback_data:'berry_'+p.pass+'_'+ctx.from.id+'_'+ctx.message.message_id+''})
b++;
}
  const rows = [];
  for (let i = 0; i < ore.length; i += 5) {
    rows.push(ore.slice(i, i + 5));
  }
const rows2 = []
if(page > 1){
rows2.push({text:'<',callback_data:'suger_'+ctx.from.id+'_'+name2+'_berry_'+ctx.message.message_id+'_'+(page-1)+''})
}
console.log(endIdx)
if((endIdx+1)<p22.length){
rows2.push({text:'>',callback_data:'suger_'+ctx.from.id+'_'+name2+'_berry_'+ctx.message.message_id+'_'+(page+1)+''})
}
rows.push(rows2)
ctx.replyWithMarkdown(message+'\n\n_Give Berry To Which Pokemon?_',{reply_to_message_id:ctx.message.message_id,reply_markup:{inline_keyboard:rows}})
}
})
bot.action(/berry_/, async ctx => {
const pass = ctx.callbackQuery.data.split('_')[1]
const id = ctx.callbackQuery.data.split('_')[2]
const data = await getUserData(ctx.from.id)
const poke = data.pokes.filter((p)=>p.pass===pass)[0]
if(id!=ctx.from.id){
ctx.answerCbQuery()
return
}
if(!poke){
ctx.answerCbQuery('Poke not found')
return
}
const p2 = poke
let msg6 = '*Pokemon:* '+c(p2.name)+' (*Lv.* '+plevel(p2.name,p2.exp)+')\n\n'
msg6 += '*HP :* '+p2.evs.hp+'\n'
msg6 += '*Attack :* '+p2.evs.attack+'\n'
msg6 += '*Defense :* '+p2.evs.defense+'\n'
msg6 += '*Special Attack :* '+p2.evs.special_attack+'\n'
msg6 += '*Special Defense :* '+p2.evs.special_defense+'\n'
msg6 += '*Speed :* '+p2.evs.speed+'\n'
msg6 += '\nWhich EV Stat You Wanna Decrease With *10*?'
const key = [
[{text:'HP',callback_data:'brth-hp-'+p2.pass+'-'+ctx.from.id+''},
{text:'Attack',callback_data:'brth-attack-'+p2.pass+'-'+ctx.from.id+''},
{text:'Defense',callback_data:'brth-defense-'+p2.pass+'-'+ctx.from.id+''}],
[{text:'SpA',callback_data:'brth-special_attack-'+p2.pass+'-'+ctx.from.id+''},
{text:'SpD',callback_data:'brth-special_defense-'+p2.pass+'-'+ctx.from.id+''},
{text:'Speed',callback_data:'brth-speed-'+p2.pass+'-'+ctx.from.id+''}]
]
ctx.editMessageText(msg6,{parse_mode:'markdown',reply_markup:{inline_keyboard:key}})
})
bot.action(/brth-/,async ctx => {
const stat = ctx.callbackQuery.data.split('-')[1]
const pass = ctx.callbackQuery.data.split('-')[2]
const id = ctx.callbackQuery.data.split('-')[3]
const data = await getUserData(ctx.from.id)
const poke = data.pokes.filter((p)=>p.pass===pass)[0]
if(id!=ctx.from.id){
ctx.answerCbQuery()
return
}
if(!poke){
ctx.answerCbQuery('Poke not found')
return
}
const p2 = poke
if(!data.inv.berry){
data.inv.berry = 0
}
if(data.inv.berry < 1){
ctx.answerCbQuery('You are out of *🍒 Berries*')
return
}
data.inv.berry -= 1
if(p2.evs[stat] < 1){
ctx.answerCbQuery('This Stat Is Already 0')
return
}
p2.evs[stat] = Math.max(0,(p2.evs[stat]-10))
await saveUserData(ctx.from.id,data)
let msg6 = '*Pokemon:* '+c(p2.name)+' (*Lv.* '+plevel(p2.name,p2.exp)+')\n\n'
msg6 += '*HP :* '+p2.evs.hp+'\n'
msg6 += '*Attack :* '+p2.evs.attack+'\n'
msg6 += '*Defense :* '+p2.evs.defense+'\n'
msg6 += '*Special Attack :* '+p2.evs.special_attack+'\n'
msg6 += '*Special Defense :* '+p2.evs.special_defense+'\n'
msg6 += '*Speed :* '+p2.evs.speed+'\n'
msg6 += '\nWhich EV Stat You Wanna Decrease With *10*?'
const key = [
[{text:'HP',callback_data:'brth-hp-'+p2.pass+'-'+ctx.from.id+''},
{text:'Attack',callback_data:'brth-attack-'+p2.pass+'-'+ctx.from.id+''},
{text:'Defense',callback_data:'brth-defense-'+p2.pass+'-'+ctx.from.id+''}],
[{text:'SpA',callback_data:'brth-special_attack-'+p2.pass+'-'+ctx.from.id+''},
{text:'SpD',callback_data:'brth-special_defense-'+p2.pass+'-'+ctx.from.id+''},
{text:'Speed',callback_data:'brth-speed-'+p2.pass+'-'+ctx.from.id+''}]
]
ctx.editMessageText(msg6,{parse_mode:'markdown',reply_markup:{inline_keyboard:key}})
})
const dataFolderPath = '/root/hexa/db/'; // Replace with the path to your data folder
bot.command('broad', (ctx) => {
if(!admins.includes(ctx.from.id)){
return
}
  const message = ctx.message.reply_to_message
  if (!message) {
    return ctx.reply('Please reply to a message to use this command.');
  }

  // Start the message forwarding process
  forwardMessageToAllUsers(ctx, message.message_id,message.chat.id);
});

async function forwardMessageToAllUsers(ctx, msgid,id) {
  const userIds = getUserIdsFromDataFolder();

  let successCount = 0;
  let failureCount = 0;

  for (const userId of userIds) {
    try {
//const msg = await bot.telegram.sendMessage(userId, message,{parse_mode:'markdown'});
//await ctx.telegram.pinChatMessage(userId,msg.message_id);
bot.telegram.forwardMessage(userId,id,msgid)
      successCount++;
    } catch (error) {
      console.error(`Failed to forward message to user ${userId}: ${error.message}`);
      failureCount++;
    }

    // To avoid rate limiting, wait for 1 second before forwarding to the next user
    await sleep(400);
  }

  // Send a summary message
  const summaryMessage = `Total Users ${userIds.length}\nMessage forwarded to ${successCount} users.\n Failed to forward to ${failureCount} users.`;
  ctx.reply(summaryMessage);
}

function getUserIdsFromDataFolder() {
  const userIds = [];
  const files = fs.readdirSync(dataFolderPath);

  for (const file of files) {
    const userId = parseInt(path.parse(file).name, 10);
    if (!isNaN(userId)) {
      userIds.push(userId);
    }
  }

  return userIds;
}
bot.command('top', async (ctx) => {
if(!admins.includes(ctx.from.id)){
return
}
  if (ctx.message.chat.type != 'private') {
ctx.replyWithMarkdown('*Use in private to get top users list*',{reply_to_message_id:ctx.message.message_id})
    return;
  }
  const allUserData = await getAllUserData();

  if (allUserData.length > 0) {
    const attribute = 'pc'
    const topUsers = await getTopUsers(allUserData, attribute, 5); // Change '10' to the desired number of top users

    let text = `Top <b>5 Users</b>\n\n`;
    topUsers.forEach((userData, index) => {
      text += `<b>#${index + 1}:</b>\n`;
      text += `<b>User:</b> ${userData.data.inv.name}\n`;
      text += `<b>${attribute.charAt(0).toUpperCase() + attribute.slice(1)}:</b> ${userData.data.inv[attribute]}\n\n`;
    });

    ctx.replyWithHTML(text)
  } else {
    ctx.replyWithMarkdown('No user data found.');
  }
});
bot.launch();
