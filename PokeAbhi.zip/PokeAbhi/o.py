import json

# Generate JSON data with numbers and "c"
json_data = {str(i): "c" for i in range(1, 1026)}

# Specify the file path
file_path = "rarities.json"

# Save the JSON data to a file
with open(file_path, "w") as json_file:
    json.dump(json_data, json_file, indent=2)

print(f"JSON data has been saved to {file_path}")
