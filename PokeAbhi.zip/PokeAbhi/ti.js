// Function to calculate the number of times to catch a Pokémon
function calculateCatchingTimes(probability) {
  // Ensure probability is between 0 and 1
  if (probability < 0 || probability > 1) {
    return "Probability must be between 0 and 1";
  }

  // Calculate the number of times to catch (r)
  let r = 0;
  while (Math.pow(1 - probability, r) < 1) {
    r++;
  }

  return r;
}

// Example usage with a probability value
const probabilityValue = 872; // Replace with your desired probability
const result = calculateCatchingTimes(probabilityValue);
console.log(`Number of times to catch Pokémon: ${result}`);
