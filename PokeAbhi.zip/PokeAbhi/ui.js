const pokesData = {
    "Mudsdale": {
        "mudsdale1": {
            name: 'Mudsdale 1',
            gen: '7',
            artwork: 'https://img.pokemondb.net/artwork/large/mudsdale1.jpg',
            national: '750',
            type: { type1: 'Ground' },
            species: 'Draft Horse Pokémon',
            height: { si: '2.5 m', usc: '8′02″' },
            weight: { si: '920.0 kg', usc: '2028.3 lbs' },
            abilities: {
                ability1: 'Own Tempo',
                ability2: 'Stamina',
                hidden_ability: 'Inner Focus'
            }
        },
        "mudsdale2": {
            name: 'Mudsdale 2',
            gen: '7',
            artwork: 'https://img.pokemondb.net/artwork/large/mudsdale2.jpg',
            national: '751',
            type: { type1: 'Ground' },
            species: 'Draft Horse Pokémon',
            height: { si: '2.6 m', usc: '8′06″' },
            weight: { si: '950.0 kg', usc: '2094.4 lbs' },
            abilities: {
                ability1: 'Own Tempo',
                ability2: 'Stamina',
                hidden_ability: 'Inner Focus'
            }
        },
        // Add more Pokémon data as needed
    },
    "Mudsdale2": {
        // Data for Mudsdale2
    }
};

const firstPokemonData = Object.values(pokesData["Mudsdale"])[0];

console.log("First Pokémon Name:", firstPokemonData.name);
console.log("First Pokémon Artwork:", firstPokemonData.artwork);
