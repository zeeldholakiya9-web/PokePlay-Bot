import requests
import json

def get_pokemon_data():
    url = "https://pokeapi.co/api/v2/pokemon/"
    response = requests.get(url)
    data = response.json()
    return data['results']

def get_pokemon_details(pokemon_url):
    response = requests.get(pokemon_url)
    data = response.json()
    return data

def create_pokedex_json():
    pokemon_list = get_pokemon_data()[:1]
    pokedex = {}

    for pokemon in pokemon_list:
        pokemon_name = pokemon['name']
        pokemon_url = pokemon['url']
        
        # Fetch detailed data for each Pokemon
        pokemon_detail_data = get_pokemon_details(pokemon_url)

        # Extract relevant information
        pokedex[pokemon_name] = {
            "name": pokemon_name.capitalize(),
            "artwork": pokemon_detail_data['sprites']['other']['official-artwork']['front_default'],
            "base_stats": {
                "hp": pokemon_detail_data['stats'][0]['base_stat'],
                "atk": pokemon_detail_data['stats'][1]['base_stat'],
                "def": pokemon_detail_data['stats'][2]['base_stat'],
                "spa": pokemon_detail_data['stats'][3]['base_stat'],
                "spd": pokemon_detail_data['stats'][4]['base_stat'],
                "spe": pokemon_detail_data['stats'][5]['base_stat'],
                "total": sum(stat['base_stat'] for stat in pokemon_detail_data['stats'])
            },
            "min_stats": {
                "hp": pokemon_detail_data['stats'][0]['base_stat'],
                "atk": pokemon_detail_data['stats'][1]['base_stat'],
                "def": pokemon_detail_data['stats'][2]['base_stat'],
                "spa": pokemon_detail_data['stats'][3]['base_stat'],
                "spd": pokemon_detail_data['stats'][4]['base_stat'],
                "spe": pokemon_detail_data['stats'][5]['base_stat']
            },
            "max_stats": {
                "hp": pokemon_detail_data['stats'][0]['base_stat'],
                "atk": pokemon_detail_data['stats'][1]['base_stat'],
                "def": pokemon_detail_data['stats'][2]['base_stat'],
                "spa": pokemon_detail_data['stats'][3]['base_stat'],
                "spd": pokemon_detail_data['stats'][4]['base_stat'],
                "spe": pokemon_detail_data['stats'][5]['base_stat']
            },
            "evolutions": get_pokemon_evolutions(pokemon_detail_data['id']),
            "moveset": get_pokemon_moveset(pokemon_detail_data['moves'])
        }
        print(pokedex[pokemon_name])
    # Save the Pokedex to a JSON file
    with open('pokedex.json', 'w') as json_file:
        json.dump(pokedex, json_file, indent=2)

def get_pokemon_evolutions(pokemon_id):
    evolution_url = f"https://pokeapi.co/api/v2/evolution-chain/{pokemon_id}/"
    evolution_response = requests.get(evolution_url)
    evolution_data = evolution_response.json()

    evolutions = {
        "from": {
            "name": None,
            "method": None
        },
        "into": []
    }

    if 'chain' in evolution_data:
        evolve_chain = evolution_data['chain']

        if 'evolves_to' in evolve_chain and evolve_chain['evolves_to']:
            evolutions['from']['name'] = evolve_chain['species']['name'].capitalize()
            evolutions['from']['method'] = evolve_chain['evolves_to'][0]['evolution_details'][0]['trigger']['name']

            while evolve_chain['evolves_to']:
                evolutions['into'].append({
                    "name": evolve_chain['evolves_to'][0]['species']['name'].capitalize(),
                    "method": evolve_chain['evolves_to'][0]['evolution_details'][0]['trigger']['name']
                })
                evolve_chain = evolve_chain['evolves_to'][0]

    return evolutions

def get_pokemon_moveset(moves):
    moveset = {}
    for move in moves:
        move_url = move['move']['url']
        move_detail_response = requests.get(move_url)
        move_detail_data = move_detail_response.json()

        moveset[move['move']['name']] = {
            "name": move['move']['name'].capitalize(),
            "type": move_detail_data['type']['name'].capitalize(),
            "cat": move_detail_data['damage_class']['name'].capitalize(),
            "power": move_detail_data['power'],
            "acc": move_detail_data['accuracy'],
            "method": get_learning_method(move_detail_data['flavor_text_entries'])
        }

    return moveset

def get_learning_method(flavor_text_entries):
    # Extract learning method from flavor text entries
    for entry in flavor_text_entries:
        if entry['language']['name'] == 'en':
            if 'level' in entry['flavor_text']:
                return f"Level {entry['flavor_text'].split()[-1]}"
            elif 'tutor' in entry['flavor_text']:
                return "Tutor"
            elif 'machine' in entry['flavor_text']:
                return "TM"
            elif 'egg' in entry['flavor_text']:
                return "Egg"
            else:
                return "Unknown"

if __name__ == "__main__":
    create_pokedex_json()
