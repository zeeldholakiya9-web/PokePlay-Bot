const fs = require('fs')
const path = require('path')
const safari = JSON.parse(fs.readFileSync('safari.json', 'utf8'));
const spawn = JSON.parse(fs.readFileSync('pokemon_status_info.json', 'utf8'));
const userFiles = fs.readdirSync('./db');
function find() {
  const filesWithMatch = [];

  for (const file of userFiles) {
    const filePath = path.join('./db', file);

    // Check if it's a JSON file
    if (file.endsWith('.json')) {
      try {
        const userData = JSON.parse(fs.readFileSync(filePath, 'utf8'));

        if (userData && userData[0].data && userData[0].data.pokes) {
          for (const poke of userData[0].data.pokes) {
            if (spawn[poke.name].toLowerCase() == 'mythical' || spawn[poke.name].toLowerCase() == 'legendry' || spawn[poke.name].toLowerCase() == 'legendary') {
              let a = false
                for(const reg of Object.keys(safari)){
                  for(const nm of safari[reg]){
                  if(poke.name.includes(nm)){
                    a = true
                  }
}
}
                  if(!a && !poke.name.includes('pikachu')){
                    filesWithMatch.push(userData[0].data.inv.name +' '+file+' '+poke.name);
           }
          }
          }
        }
      } catch (error) {
        console.error(`Error reading or parsing ${file}: ${error}`);
      }
    }
  }

  return filesWithMatch;
}
const matchingFiles = find()
console.log('Total: '+matchingFiles.length+' pokes')
    matchingFiles.forEach((file) => {
      console.log(file);
    });
