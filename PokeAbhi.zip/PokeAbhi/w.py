import requests
import json

def get_pokemon_evolution_data(pokemon_id):
    url = f'https://pokeapi.co/api/v2/pokemon-species/{pokemon_id}/'
    response = requests.get(url)

    if response.status_code == 200:
        evolution_data = response.json()
        return evolution_data
    else:
        return None

def save_evolution_data_to_json(pokemon_id, evolution_data):
    file_name = f'pokemon_{pokemon_id}_evolution.json'
    with open(file_name, 'w') as json_file:
        json.dump(evolution_data, json_file, indent=2)
    print(f"Evolution data for Pokemon {pokemon_id} saved to {file_name}")

def download_evolution_data_for_all_pokemon():
    total_pokemon =8

    for pokemon_id in range(1, total_pokemon + 1):
        evolution_data = get_pokemon_evolution_data(pokemon_id)

        if evolution_data is not None:
            save_evolution_data_to_json(pokemon_id, evolution_data)
        else:
            print(f"Failed to retrieve evolution data for Pokemon {pokemon_id}")

if __name__ == "__main__":
    download_evolution_data_for_all_pokemon()
