import csv
import json

# Function to extract numerical part from TM values
def extract_tm_number(tm):
    return int(''.join(filter(str.isdigit, tm)))

# Function to determine buy and sell prices based on conditions
def determine_prices(power, accuracy):
    if power < 60:
        return 2000, 400
    elif 60 <= power < 75:
        if accuracy < 100:
            return 4000, 800
        else:
            return 5000, 1000
    elif 75 <= power < 100:
        if accuracy < 100:
            return 6500, 1300
        else:
            return 8000, 1600
    elif power == 100 and accuracy == 100:
        return 12500, 2500
    elif power > 100:
        if accuracy < 100:
            return 10000, 2000
        else:
            return 15000, 3000
    else:
        # Default values if conditions are not met
        return 0, 0

# Read data from CSV file
with open('output.csv', newline='') as csvfile:
    reader = csv.DictReader(csvfile)

    # Initialize buy and sell dictionaries
    buy_dict = {}
    sell_dict = {}

    # Process each row in the CSV
    for row in reader:
        tm_id = extract_tm_number(row['TM'])
        power = int(row['power'])
        accuracy = int(row['accuracy'])

        # Determine buy and sell prices based on conditions
        buy_price, sell_price = determine_prices(power, accuracy)

        # Update buy and sell dictionaries
        buy_dict[str(tm_id)] = buy_price
        sell_dict[str(tm_id)] = sell_price

# Create JSON structure
json_data = {'buy': buy_dict, 'sell': sell_dict}

# Convert to JSON and save to a file
with open('tm_prices.json', 'w') as json_file:
    json.dump(json_data, json_file, indent=2)

print("JSON data saved to 'tm_prices.json'.")
