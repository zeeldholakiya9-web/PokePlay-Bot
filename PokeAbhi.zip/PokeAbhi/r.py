import requests

def get_pokemon_data():
    api_url = 'https://pokeapi.co/api/v2/pokemon?limit=100'  # Adjust 'limit' as needed
    try:
        response = requests.get(api_url)
        data = response.json()
        return data['results']
    except requests.exceptions.RequestException as e:
        print(f"Error fetching Pokémon data: {e}")
        return None

def get_evolution_chain(pokemon_name):
    api_url = f'https://pokeapi.co/api/v2/pokemon-species/{pokemon_name}/'
    try:
        response = requests.get(api_url)
        data = response.json()
        evolution_chain_url = data['evolution_chain']['url']
        
        evolution_data = requests.get(evolution_chain_url).json()
        return evolution_data
    except requests.exceptions.RequestException as e:
        print(f"Error fetching evolution chain for {pokemon_name}: {e}")
        return None

def categorize_pokemon(evolution_stage, pokemon_list):
    return [pokemon['name'] for pokemon in pokemon_list if pokemon['evolution_stage'] == evolution_stage]

# Fetch Pokémon data from the API
pokemon_data = get_pokemon_data()

if pokemon_data:
    # Categorize Pokémon based on evolution stage
    first_evolution = categorize_pokemon(1, pokemon_data)
    second_evolution = categorize_pokemon(2, pokemon_data)
    third_evolution = categorize_pokemon(3, pokemon_data)
    no_evolution = categorize_pokemon(None, pokemon_data)

    print("First Evolution:", first_evolution)
    print("Second Evolution:", second_evolution)
    print("Third Evolution:", third_evolution)
    print("No Evolution:", no_evolution)
