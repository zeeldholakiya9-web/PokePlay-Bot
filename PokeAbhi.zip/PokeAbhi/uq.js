function captureChance(percentHp, captureRate, ballBonus = 10, statusBonus = 1, captureBonus = 10, captureModifier = 0) {
    let adjustedCaptureRate = Math.floor((captureRate * captureBonus) / 10 + captureModifier);
    adjustedCaptureRate = Math.max(1, Math.min(255, adjustedCaptureRate));

    let baseChance = Math.floor(adjustedCaptureRate * ballBonus / 10 * (1 - 2 / 3 * percentHp));
    baseChance = Math.floor(baseChance * statusBonus / 10);

    const isqrt = x => Math.floor(Math.sqrt(x));
    let shakeIndex = 1048560 / isqrt(isqrt(16711680 / baseChance));

    if (shakeIndex >= 65535) {
        return [1.0, 0.0, 0.0, 0.0, 0.0];
    }

    const p = shakeIndex / 65536;

    return [
        p ** 4,  // capture
        p ** 3 * (1 - p),
        p ** 2 * (1 - p),
        p ** 1 * (1 - p),
        (1 - p),
    ];
}

// Example usage:
const probabilities = captureChance(50, 150, 15, 1, 1, 1);
console.log(probabilities);
