const fs = require('fs')
const catch_rates = JSON.parse(fs.readFileSync('pokemon_rarity.json', 'utf8'));
for(const p in catch_rates){
if(catch_rates[p] < 10){
console.log(p)
}
}
