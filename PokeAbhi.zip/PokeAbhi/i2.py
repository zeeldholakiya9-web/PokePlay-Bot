import requests
import json

def get_shiny_pokemon_links():
    url = 'https://pokeapi.co/api/v2/pokemon?limit=1500'
    response = requests.get(url)

    if response.status_code == 200:
        data = response.json()
        pokemon_list = data['results']

        shiny_links = []

        for pokemon in pokemon_list:
            pokemon_url = pokemon['url']
            pokemon_data = requests.get(pokemon_url).json()
            
            # Adjust the 'front_shiny' attribute based on the PokeAPI response structure
            shiny_sprite_url = pokemon_data['sprites']['front_shiny']
            
            shiny_links.append(shiny_sprite_url)

        # Save links to a JSON file
        with open('shiny_pokemon_links.json', 'w') as json_file:
            json.dump(shiny_links, json_file, indent=2)

get_shiny_pokemon_links()
