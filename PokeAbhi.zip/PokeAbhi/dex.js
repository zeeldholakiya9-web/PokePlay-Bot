const fs = require('fs')
const catch_rates = JSON.parse(fs.readFileSync('pokemon_rarity.json', 'utf8'));
const stones = JSON.parse(fs.readFileSync('stones.json', 'utf8'));
const pokes = JSON.parse(fs.readFileSync('pokemon_info55_modified.json', 'utf8'));
const pokemoves = JSON.parse(fs.readFileSync('moveset_data_updated.json', 'utf8'));
const re = JSON.parse(fs.readFileSync('poke_rarity.json', 'utf8'));
const pokestats = JSON.parse(fs.readFileSync('pokemon_base_stats_info.json', 'utf8'));
const trainerlevel = JSON.parse(fs.readFileSync('levels.json', 'utf8'));
const tmprices = JSON.parse(fs.readFileSync('tm_prices.json', 'utf8'));
const tms = JSON.parse(fs.readFileSync('tms2.json', 'utf8'));
const forms = JSON.parse(fs.readFileSync('pokemon_data_updated.json', 'utf8'));
const shiny = JSON.parse(fs.readFileSync('shiny.json', 'utf8'));
const dmoves = JSON.parse(fs.readFileSync('moves_info.json', 'utf8'));
const spawn = JSON.parse(fs.readFileSync('pokemon_status_info.json', 'utf8'));
const expdata = JSON.parse(fs.readFileSync('pokemon_base_exp.json', 'utf8'));
const pokes2 = JSON.parse(fs.readFileSync('pokemon_info2.json', 'utf8'));
const chart = JSON.parse(fs.readFileSync('exp_chart.json', 'utf8'));
const chains = JSON.parse(fs.readFileSync('evolution_chains2.json', 'utf8'));
const growth_rates = JSON.parse(fs.readFileSync('pokemon_data.json', 'utf8'));
const { Telegraf } = require('telegraf')
const bot = new Telegraf('6922242197:AAFugzXfc-dO_hXqjCB1zpvQkkjrUQxPxlI')
const rdata = JSON.parse(fs.readFileSync('pokedex_data.json', 'utf8'));
const emojis = {
  "normal": "🔘",
  "fire": "🔥",
  "water": "💧",
  "electric": "⚡",
  "grass": "🌱",
  "ice": "❄️",
  "fighting": "🥊",
  "poison": "☠️",
  "ground": "🌍",
  "flying": "🦅",
  "psychic": "🧠",
  "bug": "🐛",
  "rock": "�",
  "ghost": "👻",
  "dragon": "🐲",
  "dark": "🌑",
  "steel": "🔩",
  "fairy": "🧚"
}
bot.command('pokedex',async ctx => {
const name = ctx.message.text.split(' ').slice(1).join(' ')
if(!name || !forms[name.replace(/ /g,'-').toLowerCase()]){
ctx.replyWithMarkdown('*Invalid Name.*',{reply_to_message_id:ctx.message.message_id})
return
}
const name2 = name.replace(/ /g,'-')
const p = forms[name2.toLowerCase()]
const poke = pokes[p[0].identifier]
if(!poke){
return
}
const key = [[{text:'Movesets',callback_data:'moves_'+p[0].identifier+''},{text:'Base Stats',callback_data:'stats_'+p[0].identifier+''}]]
let msg = ''
msg += '*'+c(name2)+'*'
if(p[0].form_identifier.length > 0){
msg += ' ('+c(p[0].form_identifier)+' Form)'
}
const r = []
for(const region in rdata){
if(rdata[region].includes(name2)){
r.push(c(' '+region))
}
}
const cat2 = spawn[p[0].identifier] ? spawn[p[0].identifier] : 'N/A'
const cat = (cat2=='legendry') ? 'legendary' : cat2
msg += '\n*Types:* '+c(poke.types.join(' / '))+''
msg += '\n*Category:* '+c(cat)+''
msg += '\n*Regions Found:* *[*'+r+'*]*'
if(p.length>0){
const row = []
row.push({text:'<',callback_data:'data_'+name2+'_-1_'+ctx.from.id+''})
row.push({text:'1/'+p.length+'',callback_data:'waste'})
row.push({text:'>',callback_data:'data_'+name2+'_1_'+ctx.from.id+''})
key.push(row)
}
ctx.replyWithPhoto(poke.front_default_image,{caption:msg,parse_mode:'markdown',reply_markup:{inline_keyboard:key}})
})
bot.action(/data_/,async ctx => {
const name = ctx.callbackQuery.data.split('_')[1]
const index = parseInt(ctx.callbackQuery.data.split('_')[2])
const id = ctx.callbackQuery.data.split('_')[3]
if(ctx.from.id!=id){
ctx.answerCbQuery()
return
}
if(index<0){
return
}
const name2 = name.replace(/ /g,'-')
const p = forms[name2.toLowerCase()]
if(index>(p.length+1)){
return
}
const poke = pokes[p[index].identifier]
if(!poke){
return
}
const key = [[{text:'Movesets',callback_data:'moves_'+p[index].identifier+''},{text:'Base Stats',callback_data:'stats_'+p[index].identifier+''}]]
let msg = ''
msg += '*'+c(name2)+'*'
if(p[index].form_identifier.length > 0){
msg += ' ('+c(p[index].form_identifier)+' Form)'
}
const r = []
for(const region in rdata){
if(rdata[region].includes(name2)){
r.push(c(' '+region))
}
}
const cat2 = spawn[p[index].identifier] ? spawn[p[index].identifier] : 'N/A'
const cat = (cat2=='legendry') ? 'legendary' : cat2
msg += '\n*Types:* '+c(poke.types.join(' / '))+''
msg += '\n*Category:* '+c(cat)+''
msg += '\n*Regions Found:* *[*'+r+'*]*'
if(p.length>0){
const row = []
row.push({text:'<',callback_data:'data_'+name2+'_'+(index-1)+'_'+ctx.from.id+''})
row.push({text:''+(index+1)+'/'+p.length+'',callback_data:'waste'})
row.push({text:'>',callback_data:'data_'+name2+'_'+(index+1)+'_'+ctx.from.id+''})
key.push(row)
}
await bot.telegram.editMessageMedia(
        ctx.chat.id,
        ctx.callbackQuery.message.message_id,
        null,
        {type:'photo',media:poke.front_default_image,caption:msg,parse_mode:'markdown',reply_markup:{inline_keyboard:key}})
})



function c(sentence) {
const a = sentence.replace(/\b\w/g, char => char.toUpperCase());
return a.replace(/-/g,' ')
}
bot.launch()
