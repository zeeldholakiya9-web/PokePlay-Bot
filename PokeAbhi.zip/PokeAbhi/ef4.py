import requests
import json

def fetch_effects():
    url = "https://pokeapi.co/api/v2/move/"
    response = requests.get(url)
    if response.status_code == 200:
        data = response.json()
        effects = {}
        for move_data in data["results"]:
            move_id = move_data["url"].split("/")[-2]
            move_name = move_data["name"]
            move_response = requests.get(move_data["url"])
            if move_response.status_code == 200:
                move_info = move_response.json()
                if move_info.get("effect_entries"):
                    effect_entries = move_info["effect_entries"]
                    for entry in effect_entries:
                        effect_id = entry["effect"]
                        effects[effect_id] = entry["short_effect"]
        return effects
    return None

def main():
    effects = fetch_effects()
    if effects:
        with open("effects.json", "w") as file:
            json.dump(effects, file, indent=2)
        print("Effects saved to effects.json")
    else:
        print("Failed to fetch effects.")

if __name__ == "__main__":
    main()
