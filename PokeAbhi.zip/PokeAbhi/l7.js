const u = []
const fs = require('fs');
const lvl = JSON.parse(fs.readFileSync('poke_level62.json', 'utf8'));
const dmoves = JSON.parse(fs.readFileSync('pokemon_data_updated.json', 'utf8'));
for(const a in dmoves){
for(const b of dmoves[a]){
if(!lvl[b.identifier] && !u.includes(dmoves[a][0].identifier)){
u.push(dmoves[a][0].identifier)
}
}
}
console.log(u)
