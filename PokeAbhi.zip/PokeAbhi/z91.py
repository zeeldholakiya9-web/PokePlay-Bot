import requests
import json

def get_pokemon_rarity():
    pokemon_rarity = {}

    url = "https://pokeapi.co/api/v2/pokemon-species/?limit=1501"  # Adjust limit based on your needs
    response = requests.get(url)

    if response.status_code == 200:
        data = response.json()
        for result in data['results']:
            pokemon_name = result['name']
            pokemon_url = result['url']
            pokemon_data = requests.get(pokemon_url).json()
            rarity = pokemon_data['capture_rate']
            pokemon_rarity[pokemon_name] = rarity

        with open("pokemon_rarity.json", "w") as json_file:
            json.dump(pokemon_rarity, json_file, indent=2)
        print("Pokemon rarity data saved to 'pokemon_rarity.json'")
    else:
        print(f"Error: {response.status_code}")

if __name__ == "__main__":
    get_pokemon_rarity()
