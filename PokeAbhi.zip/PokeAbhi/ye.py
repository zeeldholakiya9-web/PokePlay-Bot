import requests
import json

def download_move_tutors(region):
    url = f"https://pokeapi.co/api/v2/move-learn-method/{region}-tutor"
    response = requests.get(url)
    if response.status_code == 200:
        data = response.json()
        with open(f"{region}_move_tutors.json", "w") as outfile:
            json.dump(data, outfile, indent=4)
        print(f"{region} move tutors list downloaded successfully.")
    else:
        print(f"Failed to download {region} move tutors list.")

regions = ["kanto", "johto", "hoenn", "sinnoh", "unova", "kalos", "alola", "galar"]

for region in regions:
    download_move_tutors(region)
