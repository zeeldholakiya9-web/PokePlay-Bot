import json

# Load the JSON data from the file
with open('moveset_data.json', 'r') as file:
    data = json.load(file)

# Iterate through the Pokemon entries and update the values
for pokemon, moves_info in data.items():
    for move_info in moves_info['moves_info']:
        move_info['id'] = int(move_info['id'])
        move_info['level_learned_at'] = int(move_info['level_learned_at'])

# Save the updated data back to the file
with open('moveset_data_updated.json', 'w') as file:
    json.dump(data, file, indent=2)
