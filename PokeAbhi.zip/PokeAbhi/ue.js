import requests
import json

def download_pokemon_data(start_id, end_id):
    pokemon_data = {}

    for pokemon_id in range(start_id, end_id + 1):
        url = f"https://pokeapi.co/api/v2/pokemon/{pokemon_id}/"
        response = requests.get(url)

        if response.status_code == 200:
            data = response.json()

            name = data['name']
            types = [t['type']['name'] for t in data['types']]
            image_url = data['sprites']['other']['official-artwork']['front_default']

            pokemon_data[name] = {
                "name": name.capitalize(),
                "gen": str(data['generation']['name']),
                "artwork": image_url,
                "national": str(data['id']).zfill(3),
                "type": {"type1": types[0], "type2": types[1] if len(types) > 1 else None},
                "species": data['species']['name'],
                "height": {"si": f"{data['height'] / 10} m", "usc": f"{data['height'] * 3.281} ft"},
                "weight": {"si": f"{data['weight'] / 10} kg", "usc": f"{data['weight'] * 0.2205} lbs"},
                "abilities": {"ability1": data['abilities'][0]['ability']['name'],
                              "hidden_ability": data['abilities'][1]['ability']['name'] if len(data['abilities']) > 1 else None},
                "local": {"rby": str(data['id']).zfill(3), "gsc": str(data['id']),
                          "frlg": str(data['id']).zfill(3), "hgss": str(data['id']),
                          "xy": str(data['id']).zfill(3), "lgpe": str(data['id']).zfill(3)},
                "ev_yield": {"atk": data['stats'][1]['effort']},  # Assuming effort value for attack
                "catch_rate": {"value": str(data['base_experience']), "percent": f"{data['base_experience'] / 1000 * 100}%"},
                "base_friendship": {"value": str(data['base_experience']), "rating": "normal"},
                "base_exp": str(data['base_experience']),
                "growth_rate": data['growth_rate']['name'].replace('-', ' ').title(),
                "egg_groups": [group['name'] for group in data['egg_groups']],
                "gender": {"male": f"{data['gender_rate'] * 12.5}%", "female": f"{(8 - data['gender_rate']) * 12.5}%",
                           "genderless": data['gender_rate'] == -1},
                "egg_cycles": str(data['hatch_counter']),
                "hatch_times": f"{data['hatch_counter'] * 255}–{data['hatch_counter'] * 255 + 255} steps",
                "base_stats": {stat['stat']['name']: str(stat['base_stat']) for stat in data['stats']},
                "min_stats": {stat['stat']['name']: "0" for stat in data['stats']},
                "max_stats": {stat['stat']['name']: "255" for stat in data['stats']},
                "evolutions": {"from": {"name": None, "method": None},
                               "into": {"name": None, "method": None}},  # Add evolution details based on the example
            }

    with open("pokemon_data.json", "w") as json_file:
        json.dump(pokemon_data, json_file, indent=4)

# Example usage:
download_pokemon_data(891, 895)
