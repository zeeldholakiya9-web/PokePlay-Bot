import json

# Load the JSON data
with open('pokemon_moves_info2.json') as json_file:
    data = json.load(json_file)

# Extract unique learn methods for all Pokémon
all_learn_methods = set()
for pokemon in data.values():
    moves_info = pokemon.get('moves_info', [])
    learn_methods = set(move['learn_method'] for move in moves_info)
    all_learn_methods.update(learn_methods)

# Print the unique learn methods
print("Unique Learn Methods for All Pokémon:")
for method in all_learn_methods:
    print(method)
