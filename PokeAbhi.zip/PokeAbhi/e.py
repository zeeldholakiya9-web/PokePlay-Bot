import requests
import json

def get_pokemon_evolution_data(pokemon_id):
    url = f'https://example-pokemon-api.com/pokemon/{pokemon_id}/evolution'
    response = requests.get(url)

    if response.status_code == 200:
        evolution_data = response.json()
        return evolution_data
    else:
        return None

def save_evolution_data_to_json(pokemon_id, evolution_data):
    file_name = f'pokemon_{pokemon_id}_evolution.json'
    with open(file_name, 'w') as json_file:
        json.dump(evolution_data, json_file, indent=2)
    print(f"Evolution data for Pokemon {pokemon_id} saved to {file_name}")

def main():
    pokemon_ids = [1, 2, 3]  # Replace with the desired Pokemon IDs

    for pokemon_id in pokemon_ids:
        evolution_data = get_pokemon_evolution_data(pokemon_id)

        if evolution_data is not None:
            save_evolution_data_to_json(pokemon_id, evolution_data)
        else:
            print(f"Failed to retrieve evolution data for Pokemon {pokemon_id}")

if __name__ == "__main__":
    main()
