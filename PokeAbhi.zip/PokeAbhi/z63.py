import json

# Read data from the file
with open('pokemon_base_stats_info.json', 'r') as file:
    data = json.load(file)

# Calculate total stats for each Pokémon
total_stats = {pokemon: sum(stats.values()) for pokemon, stats in data.items()}

# Get the top 10 Pokémon based on total stats
top_10_pokemon = sorted(total_stats.items(), key=lambda x: x[1], reverse=True)[:10]

# Print the top 10 Pokémon
for pokemon, total_stat in top_10_pokemon:
    print(f"{pokemon}: {total_stat} total stats")
