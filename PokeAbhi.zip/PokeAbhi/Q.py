import requests
import json

def get_all_pokemon_region_data():
    api_url = "https://pokeapi.co/api/v2/pokemon/"
    response = requests.get(api_url, params={'limit': 10})

    if response.status_code == 200:
        data = response.json()
        results = data.get('results', [])

        pokemon_region_data = {}
        for result in results:
            pokemon_name = result['name']
            region = get_pokemon_region(pokemon_name)
            pokemon_region_data[pokemon_name] = {"region": region}

        return pokemon_region_data
    else:
        print("Failed to retrieve Pokémon data")

# Modify the get_pokemon_region function
def get_pokemon_region(pokemon_name):
    api_url = f"https://pokeapi.co/api/v2/pokemon/{pokemon_name.lower()}/"
    response = requests.get(api_url)

    if response.status_code == 200:
        data = response.json()
        location_area_encounters = data.get('location_area_encounters', [])

        if location_area_encounters:
            # Check if the encounter is a string or a dictionary
            first_encounter = location_area_encounters[0]
            if isinstance(first_encounter, dict):
                region_url = first_encounter.get('location_area', {}).get('url', '')
                return get_region_name(region_url)
            else:
                print(f"Unexpected encounter format for {pokemon_name}: {first_encounter}")
                print(f"Full encounter data: {location_area_encounters}")
                return None
        else:
            return None
    else:
        print(f"Failed to retrieve region for {pokemon_name}")

# ...

def get_region_name(region_url):
    response = requests.get(region_url)

    if response.status_code == 200:
        data = response.json()
        return data.get('name', None)
    else:
        print("Failed to retrieve region name")

# Example: Get region information for the first 1000 Pokémon and save to a JSON file
all_pokemon_region_data = get_all_pokemon_region_data()

# Save to JSON file
with open('pokemon_region_data.json', 'w') as json_file:
    json.dump(all_pokemon_region_data, json_file, indent=2)

print("Region data saved to pokemon_region_data.json")
