const fs = require('fs');

// Read the content of y.json file
const jsonData = fs.readFileSync('y.json', 'utf8');
const data = JSON.parse(jsonData);

// Iterate through each entry and add Min and Max labels consecutively
data.forEach(entry => {
    const keys = Object.keys(entry);
    let currentLabel;

    keys.forEach(key => {
        if (key.startsWith('Min')) {
            currentLabel = key;
            entry[`Min ${currentLabel.slice(3)}`] = entry[key];
            delete entry[key];
        } else if (key.startsWith('Max')) {
            entry[`Max ${currentLabel.slice(3)}`] = entry[key];
            delete entry[key];
        }
    });
});

// Write the updated data back to y.json file

console.log(data)
