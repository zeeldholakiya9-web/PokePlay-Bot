// Function to calculate current level
function calculateCurrentLevel(currentXP, baseXP, expModifier) {
    return Math.min(Math.floor(Math.log(currentXP / baseXP) / Math.log(expModifier)) + 1,75);
}

// Function to calculate required experience for the next level
function calculateRequiredXP(currentLevel, baseXP, expModifier) {
    return Math.min(Math.floor(baseXP * Math.pow(expModifier, currentLevel)),72345615);
}

// Example Usage:
const currentXP = 500; // Replace with the trainer's current experience points
const baseXP = 100;   // Set the base experience required for the first level
const expModifier = 1.2; // Set the experience modifier for the curve

const currentLevel = calculateCurrentLevel(currentXP, baseXP, expModifier);
const requiredXPForNextLevel = calculateRequiredXP(currentLevel, baseXP, expModifier);

console.log(`Current Level: ${currentLevel}`);
console.log(`Required XP for Next Level: ${requiredXPForNextLevel}`);
