const u = []
const fs = require('fs');
const lvl = JSON.parse(fs.readFileSync('moveset_data_updated2.json', 'utf8'));
const dmoves = JSON.parse(fs.readFileSync('pokemon_data_updated.json', 'utf8'));
for(const a in dmoves){
for(const b of dmoves[a]){
if(!lvl[b.identifier]){
u.push(b.identifier)
}
}
}
console.log(u)
