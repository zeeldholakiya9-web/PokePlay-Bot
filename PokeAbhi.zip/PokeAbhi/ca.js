// Function to calculate experience points needed for the next level (Slow growth rate)
function expToNextLevelSlow(currentLevel) {
    return Math.floor(4 * Math.pow(currentLevel, 3) / 5);
}

// Function to calculate experience points needed for the next level (Medium growth rate)
function expToNextLevelMedium(currentLevel) {
    return Math.floor(Math.pow(currentLevel, 3));
}

// Function to calculate experience points needed for the next level (Fast growth rate)
function expToNextLevelFast(currentLevel) {
    return Math.floor(4 * Math.pow(currentLevel, 3) / 5);
}

// Function to calculate experience points needed for the next level (Medium-Slow growth rate)
function expToNextLevelMediumSlow(currentLevel) {
    return Math.floor(1.2 * Math.pow(currentLevel, 3) - 15 * Math.pow(currentLevel, 2) + 100 * currentLevel - 140);
}

// Function to calculate experience points needed for the next level (Slow-Then-Very-Fast growth rate)
function expToNextLevelSlowThenVeryFast(currentLevel) {
    if (currentLevel < 50) {
        return Math.floor(2 * Math.pow(currentLevel, 3) / 3);
    } else {
        return Math.floor(1.2 * Math.pow(currentLevel, 3) - 15 * Math.pow(currentLevel, 2) + 100 * currentLevel - 140);
    }
}

// Function to calculate experience points needed for the next level (Fast-Then-Very-Slow growth rate)
function expToNextLevelFastThenVerySlow(currentLevel) {
    if (currentLevel < 50) {
        return Math.floor(4 * Math.pow(currentLevel, 3) / 5);
    } else {
        return Math.floor(1.2 * Math.pow(currentLevel, 3) - 15 * Math.pow(currentLevel, 2) + 100 * currentLevel - 140);
    }
}

// Example usage:
const currentLevel = 36; // Replace with the actual current level

console.log(`Slow Growth Rate: ${expToNextLevelSlow(currentLevel)}`);
console.log(`Medium Growth Rate: ${expToNextLevelMedium(currentLevel)}`);
console.log(`Fast Growth Rate: ${expToNextLevelFast(currentLevel)}`);
console.log(`Medium-Slow Growth Rate: ${expToNextLevelMediumSlow(currentLevel)}`);
console.log(`Slow-Then-Very-Fast Growth Rate: ${expToNextLevelSlowThenVeryFast(currentLevel)}`);
console.log(`Fast-Then-Very-Slow Growth Rate: ${expToNextLevelFastThenVerySlow(currentLevel)}`);
